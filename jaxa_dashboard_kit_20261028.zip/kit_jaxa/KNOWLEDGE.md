# ドメイン知識（増分収集・改修時に必読）

旧環境の CLAUDE.md・メモリから、JAXA・宇宙関連DBに関する部分を抜粋・整理したもの。

---

## 1. JAXA調達DB（jaxa_procurement.db）

- **DB**: `data/db/jaxa_procurement.db`（deployコピー: `jaxa_deploy/data/db/`）
- **テーブル**: contracts（36,153件 / FY2019–2024、2026-06時点）
- **ソースURL**: `https://stage.tksc.jaxa.jp/compe/zui/nendo/zui{YYYY}nendo.pdf`（年度別・随意契約等）
- **収集スクリプト**:
  - `collect_jaxa_fy2024.py` — FY2024収集（Excel/PDF混在ソース対応）
  - `collect_jaxa_multi_fy.py` — 年度指定収集（`python collect_jaxa_multi_fy.py 2023`）
  - いずれも `parsers/` パッケージ（同梱）に依存。プロジェクトルートから実行すること
- **Excelエクスポート**: `make_jaxa_excel.py`

## 2. 行政事業レビュー 宇宙関連（review_space.db）

### ⚠️ 最重要: payment-groups の年度オフセット

**作成年度 N のシートの payment-groups = N−1年度の実際の執行。**

rssystem.go.jp の `payment-groups` API は単年度フィルタではなく、
「前年度の支払実績」が当年度シートに記録されている構造になっている。

- FY2023シートの payment-groups → FY2022の実際の支払先
- FY2024シートの payment-groups → FY2023の実際の支払先（確認済み）
- FY2025シートの payment-groups → FY2024の実際の支払先

#### 取得スクリプト（`scripts/fetch_review_api.py`、2026-10-28〜）

- `review_space.db` の `fiscal_year` は**シート年度**（支出先 = その前年度の執行実績）。
  実執行年度で見たい場合は −1 して読む
- 一括CSV（`rssystem.go.jp/files/{year}/rs/*.zip`）はシート年度2024・2025しか配布されていない
  → API（`/api/projects/?fiscal_year=N` と `/projects/{UUID}/payment-groups/`・`/payment-edges/`）で FY2022〜2026 を取得
- 抽出: `sheet_type == "RS"`（レビューシート）かつ事業名に「宇宙」「衛星」「ロケット」（全府省庁）。
  KS=基金シート、SS=JAXA運営費交付金のセグメント別シート（支出先が重複）は除外
- API `project_number` = CSV `予算事業ID`（FY2024で旧CSV版と38事業・金額完全一致を確認）
- `budget_total` = `executed_amount` = 支出先ルートノード合計（CSV版と同じ定義）
- **FY2022/2023（旧システム移行分）**: ブロック名「--」・payment-edges なしで、再委託先も最上位に並ぶ。
  ルート合計が二重計上になるため、その事業は `previous_year_execution_amount` で置換（37事業）。
  支出先明細は階層なしのまま → この2年度の支出先ランキングは再委託分を含む
- API応答は `data/cache/review_api/` にキャッシュ（`--refresh` で再取得）

#### 補足

- payment-groups レスポンスの group/payment/contract 各レベルに
  `fiscal_year`・`contract_date`・`payment_date` は**一切含まれない**
- 行政事業レビューは**支払ベース**。契約ベースの調達DBと直接比較不可
  （多年度契約は契約年に全額計上 vs 支払は複数年分散）

## 3. 宇宙戦略基金（fund_jaxa.db）

- **DB**: `fund_jaxa/data/fund_jaxa.db`（deployコピー: `jaxa_deploy/data/fund_jaxa.db`）
- **テーブル**: themes（67–68件: 第一期24・第二期24・第三期19・その他）/
  theme_budgets / research_tasks / organizations
- **再構築順序（厳守）**: fetch → parse → supplement
  1. `fund_jaxa/scripts/fetch_fund_jaxa.py` — fund.jaxa.jp スクレイパー（メイン）
  2. `fund_jaxa/scripts/parse_cao_overview_pdfs.py` — 内閣府概要PDFから支援規模を抽出してDB補完
  3. `fund_jaxa/scripts/supplement_db.py` — インライン行・未公募第三期テーマの挿入
- **第三期テーマのID体系**:
  - fund.jaxa.jp掲載済み: theme3_1（総務省）、theme3_8（文科省）、theme3_19（経産省）
  - 未公募（provisional ID）: theme3_2〜5（総務省）、theme3_6〜14（文科省）、theme3_15〜18（経産省）
    → **IDは公募開始時に変わる可能性あり**
- **予算データの注意**:
  - subtheme（A/B/C）行の total_budget_okw は NULL が多い（per-case上限のみ）→ 正常
  - 親行（sub_theme=''）に total_budget_okw が入る構造
  - 概要PDFは NFKC 正規化が必要（⽀→支、︓→： 等の異体字が多用される）
- **research_tasks**: period dates（開始・終了）と organizations.sub_theme 列を持ち、
  ダッシュボードの按分計算（sub_theme-aware proration）が依存している

## 4. ダッシュボード（jaxa_deploy/）

- `app.py` — エントリポイント（3タブ: jaxa_dashboard / review_dashboard / fund_dashboard）
- 各ダッシュボードは `BASE_DIR / "data" / ...` の**相対パス**でDBを読む
  → `jaxa_deploy/` フォルダ丸ごとならどこに置いても動く
- `dashboard/` （旧環境のプロジェクトルート側）とは別物。**deploy配下が本番**
