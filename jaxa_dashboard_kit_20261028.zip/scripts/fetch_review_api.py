"""
行政事業レビュー 宇宙関連DB構築（rssystem.go.jp API版）

一括CSV（files/{year}/rs/*.zip）はシート年度2024・2025しか配布されていないため、
APIから FY2022〜FY2026 を取得し、fetch_review_csv.py と同一スキーマで
data/review_space.db を作り直す。

抽出条件: レビューシート（sheet_type=RS）のうち事業名に「宇宙」「衛星」「ロケット」を含む（全府省庁）
fiscal_year はシート年度（支出先は前年度の執行実績である点に注意）
budget_total = executed_amount = 支出先ルートノード合計（CSV版と同じ定義）

実行: python scripts/fetch_review_api.py [--refresh]
"""

import json
import sqlite3
import sys
import time
from collections import deque
from pathlib import Path

import requests

BASE_DIR = Path(__file__).parent.parent
DB_PATH = BASE_DIR / "data" / "review_space.db"
CACHE_DIR = BASE_DIR / "data" / "cache" / "review_api"

FISCAL_YEARS = [2022, 2023, 2024, 2025, 2026]
KEYWORDS = ["宇宙", "衛星", "ロケット"]

API_BASE = "https://rssystem.go.jp/api"
HEADERS = {
    "Accept": "application/json",
    "User-Agent": "Mozilla/5.0 (compatible; research-tool/1.0)",
    "Referer": "https://rssystem.go.jp/",
}

CONTRACT_METHOD_LABELS = {
    "subsidy": "補助金等交付",
    "management-expense-grant": "運営費交付金交付",
    "act-bearing-national-treasury-liabilities": "国庫債務負担行為等",
    "open-tendering-lowest-price": "一般競争契約（最低価格）",
    "open-tendering-comprehensive-evaluation": "一般競争契約（総合評価）",
    "selective-tendering-lowest-price": "指名競争契約（最低価格）",
    "selective-tendering-comprehensive-evaluation": "指名競争契約（総合評価）",
    "negotiated-contract-small-amount": "随意契約（少額）",
    "negotiated-contract-competitive-bidding": "随意契約（企画競争）",
    "negotiated-contract-public-offering": "随意契約（公募）",
    "negotiated-contract-unsuccessful": "随意契約（不落・不調）",
    "negotiated-contract-others": "随意契約（その他）",
    "others": "その他",
}

REFRESH = "--refresh" in sys.argv
unknown_methods: dict = {}
old_format_fixed: list = []


def api_get(path, params=None, cache_key=None, retries=3):
    cache_file = CACHE_DIR / f"{cache_key}.json" if cache_key else None
    if cache_file and cache_file.exists() and not REFRESH:
        return json.loads(cache_file.read_text(encoding="utf-8"))
    for attempt in range(retries):
        try:
            r = requests.get(f"{API_BASE}{path}", params=params, headers=HEADERS, timeout=60)
            if r.status_code == 404:
                return None
            r.raise_for_status()
            data = r.json()
            if cache_file:
                cache_file.parent.mkdir(parents=True, exist_ok=True)
                cache_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            time.sleep(0.3)
            return data
        except (requests.RequestException, ValueError) as exc:
            print(f"  [WARN] attempt {attempt + 1} {path}: {exc}")
            time.sleep(2 ** attempt)
    raise RuntimeError(f"API取得失敗: {path} {params}")


def list_projects(fy):
    results, page = [], 1
    while True:
        d = api_get("/projects/", {"fiscal_year": fy, "page": page, "page_size": 100},
                    cache_key=f"list_{fy}_p{page:03d}")
        results.extend(d.get("results", []))
        if not d.get("next"):
            break
        page += 1
    if results and results[0].get("fiscal_year") not in (fy, str(fy)):
        raise RuntimeError(f"fiscal_year フィルタが効いていない: FY{fy}")
    return results


def method_label(code, desc):
    if not code:
        return None
    label = CONTRACT_METHOD_LABELS.get(code)
    if label is None:
        unknown_methods[code] = unknown_methods.get(code, 0) + 1
        label = code
    return f"{label}（{desc}）" if desc else label


def uniq_join(values, sep):
    out = []
    for v in values:
        if v not in (None, "") and str(v) not in out:
            out.append(str(v))
    return sep.join(out) or None


def payment_fields(pm):
    contracts = pm.get("contracts") or []
    amount = pm.get("total_contract_amount")
    if amount is None:
        amount = sum(c.get("amount") or 0 for c in contracts) or None
    return {
        "name": (pm.get("name") or "").strip(),
        "corp_num": pm.get("corporate_number") or None,
        "amount": amount,
        "summary": uniq_join([c.get("overview") for c in contracts], " / "),
        "method": uniq_join([method_label(c.get("contract_method"), c.get("contract_method_description"))
                             for c in contracts], "、"),
        "bids": uniq_join([c.get("number_of_applicants") for c in contracts], "、"),
        "rate": uniq_join([None if c.get("hide_bid_rate") else c.get("bid_rate") for c in contracts], "、"),
    }


def insert_payees(cur, pk, fy, groups, edges):
    """fetch_review_csv.py の insert_payees と同じ規則（ブロック=payment-group）"""
    if not groups:
        return 0
    gmap = {g["id"]: g for g in groups}
    children_map, root_ids = {}, []
    for e in edges:
        src, dst = e.get("source_node_id"), e.get("target_node_id")
        if not dst:
            continue
        if src is None:
            root_ids.append(dst)
        else:
            children_map.setdefault(src, []).append(dst)
    if not root_ids:
        root_ids = list(gmap)

    def code(g):
        return g.get("display_code") or g["id"]

    count, visited = 0, set()
    queue = deque()
    for gid in sorted(set(root_ids), key=lambda i: code(gmap[i]) if i in gmap else i):
        if gid in gmap:
            queue.append((gid, 0, None))
            visited.add(gid)

    def insert_block_row(g, level, parent, is_leaf):
        cur.execute(
            "INSERT INTO payees (project_id, fiscal_year, block_code, payee_name, amount, "
            "parent_payee_id, level, is_leaf) VALUES (?,?,?,?,?,?,?,?)",
            (pk, fy, code(g), g.get("name"), g.get("total_amount"), parent, level, is_leaf),
        )
        return cur.lastrowid

    def insert_leaf_payees(g, level, parent):
        n = 0
        for pm in g.get("payments") or []:
            f = payment_fields(pm)
            cur.execute(
                "INSERT INTO payees (project_id, fiscal_year, block_code, payee_name, "
                "corporate_number, amount, parent_payee_id, level, is_leaf, "
                "contract_summary, contract_method, bid_count, win_rate) "
                "VALUES (?,?,?,?,?,?,?,?,1,?,?,?,?)",
                (pk, fy, code(g), f["name"], f["corp_num"], f["amount"], parent, level,
                 f["summary"], f["method"], f["bids"], f["rate"]),
            )
            n += 1
        if n == 0:
            insert_block_row(g, level, parent, 1)
            n = 1
        return n

    while queue:
        gid, level, parent = queue.popleft()
        g = gmap[gid]
        if gid in children_map:
            db_id = insert_block_row(g, level, parent, 0)
            count += 1
            for child in children_map[gid]:
                if child in gmap and child not in visited:
                    visited.add(child)
                    queue.append((child, level + 1, db_id))
        else:
            count += insert_leaf_payees(g, level, parent)

    for gid, g in gmap.items():
        if gid not in visited:
            count += insert_leaf_payees(g, 0, None)
    return count


def compute_self_amounts(con, cur):
    cur.execute("""
        UPDATE payees
        SET self_amount = MAX(0, COALESCE(amount, 0) - COALESCE(
            (SELECT SUM(COALESCE(c.amount, 0)) FROM payees c WHERE c.parent_payee_id = payees.id), 0))
    """)
    con.commit()


SCHEMA = """
CREATE TABLE projects (
    id TEXT PRIMARY KEY, fiscal_year INTEGER, project_id INTEGER, name TEXT,
    organization TEXT, org_full_path TEXT, ministry_name TEXT, bureau TEXT,
    initial_budget INTEGER, supplementary INTEGER, carryover INTEGER,
    budget_total INTEGER, executed_amount INTEGER, execution_rate REAL,
    lineage_id TEXT, overview TEXT, purpose TEXT
);
CREATE TABLE payees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT REFERENCES projects(id), fiscal_year INTEGER, block_code TEXT,
    payee_name TEXT, corporate_number TEXT, amount INTEGER,
    parent_payee_id INTEGER REFERENCES payees(id), level INTEGER DEFAULT 0,
    is_leaf INTEGER DEFAULT 1, self_amount INTEGER, contract_summary TEXT,
    contract_method TEXT, bid_count TEXT, win_rate TEXT
);
CREATE TABLE expenditure_items (
    id TEXT, project_id TEXT, fiscal_year INTEGER, purpose_name TEXT, upper_name TEXT,
    budget_type TEXT, budget_type_code TEXT, requested_amount INTEGER,
    finalized_amount INTEGER, PRIMARY KEY (id)
);
"""


def build_db():
    tmp_path = DB_PATH.with_suffix(".building.db")
    if tmp_path.exists():
        tmp_path.unlink()
    con = sqlite3.connect(str(tmp_path))
    cur = con.cursor()
    cur.executescript(SCHEMA)

    for fy in FISCAL_YEARS:
        projects = list_projects(fy)
        # RS=レビューシートのみ（一括CSVと同じ範囲）。KS=基金シート、SS=JAXA交付金のセグメント別シートで支出先が重複するため除外
        space = [p for p in projects
                 if p.get("sheet_type") == "RS" and any(k in (p.get("name") or "") for k in KEYWORDS)]
        print(f"\n=== FY{fy}: 全{len(projects)}事業 / 宇宙関連 {len(space)}件 ===")
        fy_nodes = 0
        for p in space:
            num = p.get("project_number") or ""
            pk = f"{fy}-{int(num) if num.isdigit() else p['id']}"
            org = p.get("organization") or {}
            names = (org.get("flatten") or {}).get("names") or []
            ministry = p.get("ministry_name") or (names[0] if names else "")
            bureau = names[1] if len(names) > 1 else ""
            cur.execute(
                "INSERT INTO projects (id, fiscal_year, project_id, name, organization, org_full_path, "
                "ministry_name, bureau, lineage_id, overview, purpose) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (pk, fy, int(num) if num.isdigit() else None, p.get("name"), ministry,
                 " > ".join(names) or ministry, ministry, bureau, p.get("lineage_id"),
                 p.get("overview") or "", p.get("purpose") or ""),
            )
            groups = api_get(f"/projects/{p['id']}/payment-groups/", cache_key=f"groups_{p['id']}") or []
            edges = api_get(f"/projects/{p['id']}/payment-edges/", cache_key=f"edges_{p['id']}") or []
            n = insert_payees(cur, pk, fy, groups, edges)
            fy_nodes += n
            root_sum = cur.execute(
                "SELECT SUM(amount) FROM payees WHERE project_id=? AND parent_payee_id IS NULL", (pk,)
            ).fetchone()[0]
            # 旧システム移行分（FY2022/2023）はブロック間のつながりが無く、再委託先も最上位に並ぶため
            # ルート合計が二重計上になる → 前年度執行額（支出先と同じ年度の実績）で代替
            if not edges and len(groups) > 1 and p.get("previous_year_execution_amount"):
                root_sum = p["previous_year_execution_amount"]
                old_format_fixed.append(pk)
            if root_sum:
                cur.execute("UPDATE projects SET budget_total=?, executed_amount=? WHERE id=?",
                            (root_sum, root_sum, pk))
        print(f"  支出先ノード {fy_nodes}件")

    con.commit()
    compute_self_amounts(con, cur)
    con.close()

    print(f"\n旧形式（つながり情報なし）で執行額を前年度執行額に置換: {len(old_format_fixed)}事業")
    if unknown_methods:
        print("\n[WARN] 未対応の契約方式コード:", unknown_methods)
    if DB_PATH.exists():
        DB_PATH.unlink()
    tmp_path.rename(DB_PATH)
    print(f"\nDB: {DB_PATH}")


if __name__ == "__main__":
    build_db()
