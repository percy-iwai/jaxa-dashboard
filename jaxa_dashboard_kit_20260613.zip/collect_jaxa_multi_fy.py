#!/usr/bin/env python3
"""
JAXA FY2022・FY2023 契約実績 収集・DB追加スクリプト

ソース URL パターン:
    https://stage.tksc.jaxa.jp/compe/zui/nendo/zui{YYYY}nendo.pdf

Usage:
    python collect_jaxa_multi_fy.py          # FY2022・FY2023 を両方追加
    python collect_jaxa_multi_fy.py 2022     # FY2022 のみ
    python collect_jaxa_multi_fy.py 2023     # FY2023 のみ
"""
import io
import re
import sqlite3
import sys
import urllib.request
from pathlib import Path
from typing import Optional

import pdfplumber

# Windows cp932 コンソールでも日本語出力できるように UTF-8 に強制
if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "buffer"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

sys.path.insert(0, str(Path(__file__).parent))
from parsers.base_parser import BaseParser

# ── 定数 ──────────────────────────────────────────────────────────────────────
DB_PATH = Path("data/db/jaxa_procurement.db")

DOWNLOAD_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/pdf,*/*",
}

# ── PDF 列インデックス（FY2024 スクリプトと同一）──────────────────────────────
_CI_NAME    = 1
_CI_OFFICER = 2
_CI_DATE    = 3
_CI_VENDOR  = 4
_CI_CORP    = 5
_CI_COL6    = 6
_CI_EST     = 7
_CI_AMT     = 8
_CI_RATE    = 9


def _col6_is_zuii(header_row: list) -> bool:
    cell = (header_row[_CI_COL6] if len(header_row) > _CI_COL6 else "") or ""
    return "随意契約" in cell


def _is_data_header(row: list) -> bool:
    if not row or len(row) < 5:
        return False
    first  = (row[0] or "").strip().replace("\n", "").replace(" ", "")
    second = (row[1] or "").strip()
    if first in ("ＮＯ", "NO", "Ｎo", "No"):
        return True
    if "公共工事" in second or "物品役務" in second:
        return True
    return False


def _extract_contract_name(cell: str) -> str:
    if not cell:
        return ""
    m = re.search(r'[0-9１-９]?\s*[\)）]?\s*件名[：:]\s*(.+?)(?:\n|$)', cell)
    if m:
        return m.group(1).strip()
    return cell.split("\n")[0].strip()


def _normalize_amount_allow_negative(bp: BaseParser, text: str) -> Optional[int]:
    if not text or text.strip() in ("-", "－", "−", ""):
        return None
    text = text.strip()
    negative = text.startswith("-") or text.startswith("－") or text.startswith("−")
    cleaned = re.sub(r"[¥,円\-－−\s]", "", text)
    cleaned = re.sub(r"[^\d]", "", cleaned)
    if not cleaned:
        return None
    try:
        val = int(cleaned)
        return -val if negative else val
    except ValueError:
        return None


# ── カテゴリ分類（FY2024 スクリプトと同一）────────────────────────────────────
CATEGORY_RULES = [
    ("宇宙機・衛星",     ["衛星", "探査機", "宇宙機", "ひまわり", "だいち", "みちびき",
                          "あかつき", "はやぶさ", "SLIM", "スリム", "きぼう",
                          "惑星", "月面", "火星", "小惑星", "デブリ", "宇宙デブリ",
                          "SOLAR-C", "ALOS", "EarthCARE", "GCOM", "JEM運用",
                          "地球観測", "リモートセンシング", "宇宙ステーション", "ISS",
                          "スペース", "宇宙飛行士", "宇宙科学", "天文", "宇宙望遠鏡",
                          "ローバー", "着陸機", "観測機", "MMX", "XRISM", "HTV"]),
    ("ロケット・打上",   ["ロケット", "打上", "打ち上", "H3", "H-3", "H-IIA", "H-ⅡA",
                          "イプシロン", "推進", "推薬", "エンジン", "燃焼試験",
                          "液化水素", "液体水素", "液体酸素", "液体窒素", "液酸",
                          "射場", "発射", "射点", "台地", "固体モータ", "スラスタ",
                          "Air Launch", "エアロスペース"]),
    ("情報システム・IT", ["情報システム", "ソフトウェア", "ネットワーク", "サーバ",
                          "クラウド", "セキュリティ", "情報処理", "データベース",
                          "DX", "デジタル", "電算", "ICT", "Web", "ウェブ",
                          "ライセンス", "アーカイバ", "リモートアクセス",
                          "プラットフォーム", "アプリ", "SAP", "財務会計システム"]),
    ("試験・評価・解析", ["試験", "評価", "解析", "計測", "検証",
                          "シミュレーション", "測定", "分析", "性能確認", "審査",
                          "観測実験", "較正", "キャリブ", "計算"]),
    ("研究・開発",       ["研究", "開発", "設計", "技術調査", "技術研究",
                          "技術支援", "フィージビリティ", "概念設計", "製造"]),
    ("施設・設備・工事", ["建設", "工事", "改修", "修繕", "設備",
                          "電気工事", "空調", "配管", "塗装", "土木", "解体",
                          "新築", "舗装", "補修", "棟", "施設整備"]),
    ("輸送・物流",       ["輸送", "物流", "運搬", "搬送", "輸出", "梱包", "海上輸送"]),
    ("役務・委託",       ["役務", "委託", "業務委託", "業務支援", "事務支援",
                          "管理業務", "保守", "清掃", "警備", "派遣", "監視",
                          "運転業務", "保険", "作業", "運営支援", "広報"]),
    ("物品・機器・部品", ["購入", "機器", "装置", "部品", "消耗品", "器材",
                          "材料", "計算機", "端末", "工具", "試薬",
                          "センサ", "カメラ", "電子部品", "調達"]),
]


def classify(name: Optional[str]) -> str:
    if not name:
        return "その他"
    for cat, kws in CATEGORY_RULES:
        if any(kw in name for kw in kws):
            return cat
    return "その他"


# ── FY 判定（CLAUDE.md 定義と同一）──────────────────────────────────────────
def date_to_fy(ds: str) -> Optional[int]:
    """'YYYYMMDD' 形式の日付文字列から会計年度を返す。"""
    if not ds or len(ds) < 6:
        return None
    try:
        y, mo = int(ds[:4]), int(ds[4:6])
        return y if mo >= 4 else y - 1
    except ValueError:
        return None


# ── DB DDL（既存テーブルがなければ作成）──────────────────────────────────────
DDL = """
CREATE TABLE IF NOT EXISTS contracts (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    fiscal_year      INTEGER  DEFAULT 2024,
    contract_name    TEXT,
    contract_officer TEXT,
    contract_date    TEXT,
    vendor_name      TEXT,
    vendor_address   TEXT,
    corporate_number TEXT,
    bid_method       TEXT,
    zuii_reason      TEXT,
    estimated_price  INTEGER,
    contract_amount  INTEGER,
    award_rate       REAL,
    category         TEXT,
    source_url       TEXT,
    created_at       TEXT     DEFAULT (datetime('now','localtime'))
)
"""


def setup_db(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(DDL)
    conn.commit()
    return conn


def insert_records(conn: sqlite3.Connection, records: list) -> int:
    sql = """
        INSERT INTO contracts (
            fiscal_year, contract_name, contract_officer, contract_date,
            vendor_name, vendor_address, corporate_number,
            bid_method, zuii_reason,
            estimated_price, contract_amount, award_rate,
            category, source_url
        ) VALUES (
            :fiscal_year, :contract_name, :contract_officer, :contract_date,
            :vendor_name, :vendor_address, :corporate_number,
            :bid_method, :zuii_reason,
            :estimated_price, :contract_amount, :award_rate,
            :category, :source_url
        )
    """
    conn.executemany(sql, records)
    conn.commit()
    return len(records)


# ── PDF ダウンロード ──────────────────────────────────────────────────────────
def download_pdf(fy: int) -> bytes:
    url = f"https://stage.tksc.jaxa.jp/compe/zui/nendo/zui{fy}nendo.pdf"
    cache = Path(f"data/cache/jaxa_zui{fy}nendo.pdf")
    if cache.exists():
        data = cache.read_bytes()
        print(f"  PDFキャッシュ使用: {cache} ({len(data):,} bytes)")
        return data, url
    print(f"  PDFダウンロード中: {url}")
    req = urllib.request.Request(url, headers=DOWNLOAD_HEADERS)
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = resp.read()
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_bytes(data)
    print(f"  -> {len(data):,} bytes 受信・キャッシュ保存")
    return data, url


# ── 1行からレコードを生成 ─────────────────────────────────────────────────────
def _make_record(
    row: list,
    is_zuii: bool,
    bp: BaseParser,
    source_url: str,
    target_fy: int,
) -> Optional[dict]:
    def cell(idx: int) -> str:
        return (row[idx] if idx < len(row) else None) or ""

    vendor_raw = cell(_CI_VENDOR).strip()
    if not vendor_raw or vendor_raw in ("-", "－"):
        return None

    vendor_parts   = vendor_raw.split("\n", 1)
    vendor_name    = vendor_parts[0].strip()
    vendor_address = vendor_parts[1].strip() if len(vendor_parts) > 1 else ""

    if not vendor_name or vendor_name in ("-", "－", "−"):
        return None

    contract_name    = _extract_contract_name(cell(_CI_NAME))
    contract_officer = cell(_CI_OFFICER).strip().replace("\n", " ")

    col6_val = cell(_CI_COL6).strip().replace("\n", " ")
    if is_zuii:
        zuii_reason = col6_val[:500] if col6_val and col6_val not in ("-", "－") else None
        bid_method  = "随意契約"
    else:
        zuii_reason = None
        bid_method  = bp._normalize_bid_method(col6_val) if col6_val else "一般競争入札"

    contract_date   = bp._normalize_date(cell(_CI_DATE))
    contract_amount = _normalize_amount_allow_negative(bp, cell(_CI_AMT))
    estimated_price = _normalize_amount_allow_negative(bp, cell(_CI_EST))
    award_rate      = bp._normalize_rate(cell(_CI_RATE))

    # FY 汚染チェック: contract_date が取れた場合は FY が一致するレコードのみ採用
    # contract_date が NULL の場合は target_fy をそのまま使う
    if contract_date:
        rec_fy = date_to_fy(contract_date)
        if rec_fy is not None and rec_fy != target_fy:
            return None  # 他 FY のデータを除外

    return {
        "fiscal_year":      target_fy,
        "contract_name":    contract_name or None,
        "contract_officer": contract_officer or None,
        "contract_date":    contract_date,
        "vendor_name":      vendor_name,
        "vendor_address":   vendor_address or None,
        "corporate_number": cell(_CI_CORP) or None,
        "bid_method":       bid_method,
        "zuii_reason":      zuii_reason,
        "estimated_price":  estimated_price,
        "contract_amount":  contract_amount,
        "award_rate":       award_rate,
        "category":         classify(contract_name),
        "source_url":       source_url,
    }


# ── PDF パース ────────────────────────────────────────────────────────────────
def parse_pdf(data: bytes, source_url: str, target_fy: int) -> list:
    bp        = BaseParser("jaxa", "宇宙航空研究開発機構（JAXA）", "JAXA")
    records   = []
    is_zuii   = False
    page_skip = 0
    page_ok   = 0
    skipped_fy = 0

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        total_pages = len(pdf.pages)
        print(f"  ページ数: {total_pages}")

        for page in pdf.pages:
            tables = page.extract_tables()
            if not tables:
                page_skip += 1
                continue

            for table in tables:
                header_found = False
                for row_idx, row in enumerate(table):
                    row = [cell.strip() if cell else "" for cell in row]

                    if _is_data_header(row):
                        is_zuii      = _col6_is_zuii(row)
                        header_found = True
                        continue

                    if header_found and row_idx <= 2:
                        col0 = (row[0] if row else "").strip()
                        if not col0 or not re.match(r"^\d+$", col0):
                            continue

                    rec = _make_record(row, is_zuii, bp, source_url, target_fy)
                    if rec is None:
                        # vendor が空 or FY汚染でスキップされた可能性あり
                        # 細かいカウントは省略
                        pass
                    else:
                        records.append(rec)

            page_ok += 1

    print(f"  処理ページ: {page_ok} / スキップ: {page_skip}")
    return records


# ── FY 単体処理 ───────────────────────────────────────────────────────────────
def process_fy(conn: sqlite3.Connection, fy: int):
    print(f"\n{'='*60}")
    print(f"  FY{fy} 処理開始")
    print(f"{'='*60}")

    # 既存データを削除（冪等性確保）
    deleted = conn.execute(
        "DELETE FROM contracts WHERE fiscal_year = ?", (fy,)
    ).rowcount
    conn.commit()
    if deleted:
        print(f"  既存 FY{fy} データ {deleted} 件を削除（再投入）")

    # PDF ダウンロード
    print(f"\n[1] PDF ダウンロード")
    pdf_data, source_url = download_pdf(fy)

    # PDF パース
    print(f"\n[2] PDF パース（target_fy={fy}）")
    records = parse_pdf(pdf_data, source_url, fy)
    print(f"  -> {len(records)} 件抽出（FY汚染分除外済み）")

    if not records:
        print(f"  [WARN] FY{fy} レコードなし。PDF フォーマット確認が必要かもしれません。")
        return 0

    # DB 挿入
    print(f"\n[3] DB 挿入")
    insert_records(conn, records)
    print(f"  -> {len(records)} 件挿入完了")

    # 統計
    row = conn.execute(
        """
        SELECT
            COUNT(*) AS cnt,
            COALESCE(SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END), 0) AS total,
            SUM(CASE WHEN contract_date IS NOT NULL THEN 1 ELSE 0 END) AS dated,
            MIN(contract_date), MAX(contract_date)
        FROM contracts WHERE fiscal_year = ?
        """,
        (fy,),
    ).fetchone()
    cnt, total, dated, min_dt, max_dt = row
    print(f"\n  【FY{fy} 統計】")
    print(f"    件数         : {cnt:,} 件")
    print(f"    契約金額合計 : {total/1e8:,.1f} 億円")
    print(f"    日付充填率   : {dated}/{cnt} ({dated/cnt*100:.1f}%)" if cnt else "")
    print(f"    期間         : {min_dt} ~ {max_dt}")

    print(f"\n  【FY{fy} 入札方式別】")
    for r in conn.execute(
        "SELECT bid_method, COUNT(*), SUM(CASE WHEN contract_amount>0 THEN contract_amount ELSE 0 END) "
        "FROM contracts WHERE fiscal_year=? GROUP BY bid_method ORDER BY 3 DESC",
        (fy,),
    ):
        print(f"    {(r[0] or '不明'):25s}: {r[1]:5d} 件  {(r[2] or 0)/1e8:8.1f} 億")

    return cnt


# ── メイン ────────────────────────────────────────────────────────────────────
def main():
    # 処理する FY を引数から取得（デフォルト: 2022, 2023）
    if len(sys.argv) > 1:
        try:
            fys = [int(a) for a in sys.argv[1:]]
        except ValueError:
            print("Usage: python collect_jaxa_multi_fy.py [2022] [2023]")
            sys.exit(1)
    else:
        fys = [2022, 2023]

    print("=" * 60)
    print(f"JAXA 複数年度 契約実績 収集スクリプト")
    print(f"対象FY: {fys}")
    print("=" * 60)

    conn = setup_db(DB_PATH)

    total_inserted = 0
    for fy in fys:
        cnt = process_fy(conn, fy)
        total_inserted += cnt

    # 全FY サマリー
    print(f"\n{'='*60}")
    print("  【全年度サマリー】")
    print(f"{'='*60}")
    for r in conn.execute(
        """
        SELECT fiscal_year, COUNT(*),
               COALESCE(SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END), 0)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
        """
    ):
        print(f"  FY{r[0]}: {r[1]:6,} 件  {r[2]/1e8:8.1f} 億円")

    total_row = conn.execute(
        """
        SELECT COUNT(*),
               COALESCE(SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END), 0)
        FROM contracts
        """
    ).fetchone()
    print(f"  {'合計':10s}: {total_row[0]:6,} 件  {total_row[1]/1e8:8.1f} 億円")

    conn.close()
    print(f"\n=== 完了 (今回追加: {total_inserted} 件) ===")
    print(f"  DB: {DB_PATH}")


if __name__ == "__main__":
    main()
