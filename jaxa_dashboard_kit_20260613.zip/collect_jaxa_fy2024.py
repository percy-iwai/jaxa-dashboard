#!/usr/bin/env python3
"""
JAXA FY2024 契約実績 収集・DB化・Excel エクスポートスクリプト

ソース: https://stage.tksc.jaxa.jp/compe/zui/nendo/zui2024nendo.pdf
出力:
    data/db/jaxa_procurement.db      -- SQLite DB
    data/output/jaxa_fy2024.xlsx     -- Excel（全件 / 企業別 / ジャンル別）

Usage:
    python collect_jaxa_fy2024.py
"""
import io
import re
import sqlite3
import sys
import urllib.request
from pathlib import Path
from typing import Optional

import pdfplumber
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# Windows cp932 コンソールでも日本語出力できるように UTF-8 に強制
if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "buffer"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# プロジェクトルートをパスに追加
sys.path.insert(0, str(Path(__file__).parent))
from parsers.base_parser import BaseParser

# ── 定数 ──────────────────────────────────────────────────────────────────────
PDF_URL     = "https://stage.tksc.jaxa.jp/compe/zui/nendo/zui2024nendo.pdf"
DB_PATH     = Path("data/db/jaxa_procurement.db")
EXCEL_PATH  = Path("data/output/jaxa_fy2024.xlsx")
FISCAL_YEAR = 2024

DOWNLOAD_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/pdf,*/*",
}

# ── PDF 固定列インデックス ─────────────────────────────────────────────────────
#   Col 0 : NO
#   Col 1 : 件名（公共工事の名称、場所、期間及び種別 / 物品役務名）
#   Col 2 : 契約担当者等の氏名並びにその所属する部局の名称及び所在地
#   Col 3 : 契約を締結した日
#   Col 4 : 契約の相手方の商号又は名称及び住所
#   Col 5 : 契約の相手方の法人番号
#   Col 6 : 一般競争入札/指名競争入札の別  OR  随意契約の根拠規定及び理由
#   Col 7 : 予定価格
#   Col 8 : 契約金額
#   Col 9 : 落札率
#   Col 10+: 公益法人・再就職役員・応札者数・備考（不使用）

_CI_NAME    = 1
_CI_OFFICER = 2
_CI_DATE    = 3
_CI_VENDOR  = 4
_CI_CORP    = 5
_CI_COL6    = 6
_CI_EST     = 7
_CI_AMT     = 8
_CI_RATE    = 9


def _col6_is_zuii(header_row: list) -> bool:
    """Col 6 ヘッダーが随意契約根拠列かどうかを判定する。"""
    cell = (header_row[_CI_COL6] if len(header_row) > _CI_COL6 else "") or ""
    return "随意契約" in cell


def _is_data_header(row: list) -> bool:
    """ヘッダー行かどうかを判定（NO 列 + 担当者 列の存在でチェック）。"""
    if not row or len(row) < 5:
        return False
    first = (row[0] or "").strip().replace("\n", "").replace(" ", "")
    second = (row[1] or "").strip()
    # ヘッダー行の特徴: Col0が「NO」「NO」など / Col1が「公共工事」or「物品役務」
    if first in ("ＮＯ", "NO", "Ｎo", "No"):
        return True
    if "公共工事" in second or "物品役務" in second:
        return True
    return False


def _extract_contract_name(cell: str) -> str:
    """
    工事系: 「1)件名：XXX\n2)場所：...\n3)期間：...\n4)工種：...」→ XXX
    物品役務系: そのまま返す。
    """
    if not cell:
        return ""
    # 「1)件名：」または「件名：」プレフィックス
    m = re.search(r'[0-9１-９]?\s*[\)）]?\s*件名[：:]\s*(.+?)(?:\n|$)', cell)
    if m:
        return m.group(1).strip()
    # 工事系でも「件名：」がない場合は改行前の最初の行を使う
    first_line = cell.split("\n")[0].strip()
    return first_line


def _normalize_amount_allow_negative(bp: BaseParser, text: str) -> Optional[int]:
    """金額文字列を整数（円）に変換。マイナス（変更契約）も許容。"""
    if not text or text.strip() in ("-", "－", "−", ""):
        return None
    text = text.strip()
    negative = text.startswith("-") or text.startswith("－") or text.startswith("−")
    cleaned = re.sub(r"[¥,円\-－−\s]", "", text)
    cleaned = re.sub(r"[^\d]", "", cleaned)
    if not cleaned:
        return None
    try:
        val = int(cleaned)
        return -val if negative else val
    except ValueError:
        return None


# ── カテゴリ分類ルール（優先順位順）──────────────────────────────────────────
CATEGORY_RULES = [
    # ① 宇宙機・衛星: JAXA の主要ミッション関連（最優先）
    ("宇宙機・衛星",     ["衛星", "探査機", "宇宙機", "ひまわり", "だいち", "みちびき",
                          "あかつき", "はやぶさ", "SLIM", "スリム", "きぼう",
                          "惑星", "月面", "火星", "小惑星", "デブリ", "宇宙デブリ",
                          "SOLAR-C", "ALOS", "EarthCARE", "GCOM", "JEM運用",
                          "地球観測", "リモートセンシング", "宇宙ステーション", "ISS",
                          "スペース", "宇宙飛行士", "宇宙科学", "天文", "宇宙望遠鏡",
                          "ローバー", "着陸機", "観測機", "MMX", "XRISM", "HTV"]),
    # ② ロケット・打上: 打上輸送システム
    ("ロケット・打上",   ["ロケット", "打上", "打ち上", "H3", "H-3", "H-IIA", "H-ⅡA",
                          "イプシロン", "推進", "推薬", "エンジン", "燃焼試験",
                          "液化水素", "液体水素", "液体酸素", "液体窒素", "液酸",
                          "射場", "発射", "射点", "台地", "固体モータ", "スラスタ",
                          "Air Launch", "エアロスペース"]),
    # ③ 情報システム・IT: より限定的なキーワードに絞る
    ("情報システム・IT", ["情報システム", "ソフトウェア", "ネットワーク", "サーバ",
                          "クラウド", "セキュリティ", "情報処理", "データベース",
                          "DX", "デジタル", "電算", "ICT", "Web", "ウェブ",
                          "ライセンス", "アーカイバ", "リモートアクセス",
                          "プラットフォーム", "アプリ", "SAP", "財務会計システム"]),
    # ④ 試験・評価・解析
    ("試験・評価・解析", ["試験", "評価", "解析", "計測", "検証",
                          "シミュレーション", "測定", "分析", "性能確認", "審査",
                          "観測実験", "較正", "キャリブ", "計算"]),
    # ⑤ 研究・開発・設計
    ("研究・開発",       ["研究", "開発", "設計", "技術調査", "技術研究",
                          "技術支援", "フィージビリティ", "概念設計", "製造"]),
    # ⑥ 施設・設備・工事
    ("施設・設備・工事", ["建設", "工事", "改修", "修繕", "設備",
                          "電気工事", "空調", "配管", "塗装", "土木", "解体",
                          "新築", "舗装", "補修", "棟", "施設整備"]),
    # ⑦ 輸送・物流
    ("輸送・物流",       ["輸送", "物流", "運搬", "搬送", "輸出", "梱包", "海上輸送"]),
    # ⑧ 役務・委託
    ("役務・委託",       ["役務", "委託", "業務委託", "業務支援", "事務支援",
                          "管理業務", "保守", "清掃", "警備", "派遣", "監視",
                          "運転業務", "保険", "作業", "運営支援", "広報"]),
    # ⑨ 物品・機器・部品
    ("物品・機器・部品", ["購入", "機器", "装置", "部品", "消耗品", "器材",
                          "材料", "計算機", "端末", "工具", "試薬",
                          "センサ", "カメラ", "電子部品", "調達"]),
]


def classify(name: Optional[str]) -> str:
    """契約件名からカテゴリを返す（優先順位順）。"""
    if not name:
        return "その他"
    for cat, kws in CATEGORY_RULES:
        if any(kw in name for kw in kws):
            return cat
    return "その他"


# ── DB セットアップ ────────────────────────────────────────────────────────────
DDL = """
CREATE TABLE IF NOT EXISTS contracts (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    fiscal_year      INTEGER  DEFAULT 2024,
    contract_name    TEXT,
    contract_officer TEXT,
    contract_date    TEXT,
    vendor_name      TEXT,
    vendor_address   TEXT,
    corporate_number TEXT,
    bid_method       TEXT,
    zuii_reason      TEXT,
    estimated_price  INTEGER,
    contract_amount  INTEGER,
    award_rate       REAL,
    category         TEXT,
    source_url       TEXT,
    created_at       TEXT     DEFAULT (datetime('now','localtime'))
)
"""


def setup_db(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(DDL)
    conn.commit()
    return conn


def insert_records(conn: sqlite3.Connection, records: list) -> int:
    sql = """
        INSERT INTO contracts (
            fiscal_year, contract_name, contract_officer, contract_date,
            vendor_name, vendor_address, corporate_number,
            bid_method, zuii_reason,
            estimated_price, contract_amount, award_rate,
            category, source_url
        ) VALUES (
            :fiscal_year, :contract_name, :contract_officer, :contract_date,
            :vendor_name, :vendor_address, :corporate_number,
            :bid_method, :zuii_reason,
            :estimated_price, :contract_amount, :award_rate,
            :category, :source_url
        )
    """
    conn.executemany(sql, records)
    conn.commit()
    return len(records)


# ── PDF ダウンロード ──────────────────────────────────────────────────────────
_PDF_CACHE = Path("data/cache/jaxa_zui2024nendo.pdf")


def download_pdf(url: str) -> bytes:
    if _PDF_CACHE.exists():
        data = _PDF_CACHE.read_bytes()
        print(f"PDFキャッシュ使用: {_PDF_CACHE} ({len(data):,} bytes)")
        return data
    print(f"PDFダウンロード中: {url}")
    req = urllib.request.Request(url, headers=DOWNLOAD_HEADERS)
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = resp.read()
    _PDF_CACHE.parent.mkdir(parents=True, exist_ok=True)
    _PDF_CACHE.write_bytes(data)
    print(f"  -> {len(data):,} bytes 受信・キャッシュ保存")
    return data


# ── 1行からレコードを生成 ─────────────────────────────────────────────────────
def _make_record(
    row: list,
    is_zuii: bool,
    bp: BaseParser,
    source_url: str,
) -> Optional[dict]:
    """
    固定列インデックスで1行を解析しレコードを返す。
    vendor_name が空なら None を返す（ヘッダー継続行等をスキップ）。
    """
    def cell(idx: int) -> str:
        return (row[idx] if idx < len(row) else None) or ""

    vendor_raw = cell(_CI_VENDOR).strip()
    if not vendor_raw or vendor_raw in ("-", "－"):
        return None

    # 相手方の名称と住所を分割（改行区切り）
    vendor_parts = vendor_raw.split("\n", 1)
    vendor_name    = vendor_parts[0].strip()
    vendor_address = vendor_parts[1].strip() if len(vendor_parts) > 1 else ""

    if not vendor_name or vendor_name in ("-", "－", "−"):
        return None

    # 件名を抽出（「1)件名：XXX\n2)場所：...」形式に対応）
    contract_name = _extract_contract_name(cell(_CI_NAME))

    # 契約担当者（名前と所属を改行区切りでまとめる）
    contract_officer = cell(_CI_OFFICER).strip().replace("\n", " ")

    # Col 6: 随意ページなら zuii_reason / それ以外は bid_method
    col6_val = cell(_CI_COL6).strip().replace("\n", " ")
    if is_zuii:
        zuii_reason = col6_val[:500] if col6_val and col6_val not in ("-", "－") else None
        bid_method  = "随意契約"
    else:
        zuii_reason = None
        bid_method  = bp._normalize_bid_method(col6_val) if col6_val else "一般競争入札"

    # 日付 ("2024/5/15" → "20240515" は BaseParser._normalize_date で変換)
    contract_date = bp._normalize_date(cell(_CI_DATE))

    # 金額（変更契約はマイナス値あり）
    contract_amount = _normalize_amount_allow_negative(bp, cell(_CI_AMT))
    estimated_price = _normalize_amount_allow_negative(bp, cell(_CI_EST))
    award_rate      = bp._normalize_rate(cell(_CI_RATE))

    return {
        "fiscal_year":      FISCAL_YEAR,
        "contract_name":    contract_name or None,
        "contract_officer": contract_officer or None,
        "contract_date":    contract_date,
        "vendor_name":      vendor_name,
        "vendor_address":   vendor_address or None,
        "corporate_number": cell(_CI_CORP) or None,
        "bid_method":       bid_method,
        "zuii_reason":      zuii_reason,
        "estimated_price":  estimated_price,
        "contract_amount":  contract_amount,
        "award_rate":       award_rate,
        "category":         classify(contract_name),
        "source_url":       source_url,
    }


# ── PDF パース（pdfplumber） ──────────────────────────────────────────────────
def parse_pdf(data: bytes, source_url: str) -> list:
    """PDF からテーブルを抽出し、レコードのリストを返す。"""
    bp        = BaseParser("jaxa", "宇宙航空研究開発機構（JAXA）", "JAXA")
    records   = []
    is_zuii   = False   # 現在のページが随意契約ページかどうか
    page_skip = 0
    page_ok   = 0

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        total_pages = len(pdf.pages)
        print(f"  ページ数: {total_pages}")

        for page in pdf.pages:
            page_no = page.page_number
            tables  = page.extract_tables()

            if not tables:
                page_skip += 1
                continue

            for table in tables:
                header_found = False
                for row_idx, row in enumerate(table):
                    row = [cell.strip() if cell else "" for cell in row]

                    # ヘッダー行を検出してページ種別（随意/一般）を確定
                    if _is_data_header(row):
                        is_zuii = _col6_is_zuii(row)
                        header_found = True
                        continue

                    # ヘッダー直後の副ヘッダー行（"公益法人の区分" 等）をスキップ
                    if header_found and row_idx <= 2:
                        # Col 0 が空または非数値なら副ヘッダー
                        col0 = (row[0] if row else "").strip()
                        if not col0 or not re.match(r"^\d+$", col0):
                            continue

                    rec = _make_record(row, is_zuii, bp, source_url)
                    if rec:
                        records.append(rec)

            page_ok += 1

    print(f"  処理ページ: {page_ok} / スキップ: {page_skip}")
    return records


# ── Excel 書式ヘルパー ────────────────────────────────────────────────────────
_HDR_FILL = PatternFill("solid", fgColor="1F497D")
_HDR_FONT = Font(bold=True, color="FFFFFF", size=10)
_TTL_FILL = PatternFill("solid", fgColor="D9D9D9")
_MONEY_FMT = "#,##0"


def _style_header_row(ws, row: int = 1):
    for cell in ws[row]:
        cell.font      = _HDR_FONT
        cell.fill      = _HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 22


def _auto_col_width(ws, max_width: int = 60):
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len    = max((len(str(cell.value or "")) for cell in col), default=0)
        ws.column_dimensions[col_letter].width = min(max_len * 1.4 + 2, max_width)


def _apply_money_format(ws, header_row: int = 1):
    """ヘッダーに「円」が含まれる列に通貨書式を適用する。"""
    for col_cells in ws.iter_cols(min_row=header_row, max_row=header_row):
        hdr = str(col_cells[0].value or "")
        if "円" in hdr:
            col_idx = col_cells[0].column
            for cell_row in ws.iter_rows(
                min_row=header_row + 1, max_row=ws.max_row,
                min_col=col_idx, max_col=col_idx
            ):
                for c in cell_row:
                    if c.value is not None:
                        c.number_format = _MONEY_FMT


# ── Excel エクスポート ────────────────────────────────────────────────────────
def export_excel(conn: sqlite3.Connection, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # ── Sheet1: 全件データ ─────────────────────────────────────────────────────
    df_all = pd.read_sql_query(
        """
        SELECT
            fiscal_year       AS "年度",
            contract_name     AS "件名",
            contract_officer  AS "契約担当官",
            contract_date     AS "契約締結日",
            vendor_name       AS "相手方（企業名）",
            vendor_address    AS "相手方住所",
            corporate_number  AS "法人番号",
            bid_method        AS "入札方式",
            zuii_reason       AS "随意契約の根拠",
            estimated_price   AS "予定価格（円）",
            contract_amount   AS "契約金額（円）",
            award_rate        AS "落札率（%）",
            category          AS "カテゴリ"
        FROM contracts
        ORDER BY contract_date, id
        """,
        conn,
    )
    # YYYYMMDD → YYYY/MM/DD 表示
    df_all["契約締結日"] = df_all["契約締結日"].apply(
        lambda x: f"{x[:4]}/{x[4:6]}/{x[6:]}" if isinstance(x, str) and len(x) == 8 else x
    )

    # ── Sheet2: 企業別内訳 ─────────────────────────────────────────────────────
    df_vendor = pd.read_sql_query(
        """
        SELECT
            vendor_name                                   AS "企業名",
            COUNT(*)                                      AS "件数",
            SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END)
                                                          AS "契約金額合計（円）",
            CAST(AVG(CASE WHEN contract_amount > 0 THEN contract_amount END) AS INTEGER)
                                                          AS "契約金額平均（円）",
            MAX(contract_amount)                          AS "最大契約金額（円）"
        FROM contracts
        WHERE vendor_name IS NOT NULL
        GROUP BY vendor_name
        ORDER BY SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END) DESC
        """,
        conn,
    )
    # 代表品目（最大金額の件名）を追加
    df_top = pd.read_sql_query(
        """
        SELECT c.vendor_name AS "企業名",
               c.contract_name AS "代表的な品目（最大金額）"
        FROM contracts c
        INNER JOIN (
            SELECT vendor_name, MAX(contract_amount) AS max_amt
            FROM contracts
            GROUP BY vendor_name
        ) m ON c.vendor_name = m.vendor_name AND c.contract_amount = m.max_amt
        GROUP BY c.vendor_name
        """,
        conn,
    )
    df_vendor = df_vendor.merge(df_top, on="企業名", how="left")

    # ── Sheet3: ジャンル別内訳 ─────────────────────────────────────────────────
    df_cat = pd.read_sql_query(
        """
        SELECT
            category             AS "カテゴリ",
            COUNT(*)             AS "件数",
            SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END)
                                 AS "契約金額合計（円）"
        FROM contracts
        GROUP BY category
        ORDER BY SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END) DESC
        """,
        conn,
    )
    total_amt = df_cat["契約金額合計（円）"].sum()
    df_cat["構成比（%）"] = (df_cat["契約金額合計（円）"] / total_amt * 100).round(1) if total_amt else 0.0
    total_row = pd.DataFrame([{
        "カテゴリ":       "【合計】",
        "件数":           int(df_cat["件数"].sum()),
        "契約金額合計（円）": total_amt,
        "構成比（%）":    100.0,
    }])
    df_cat = pd.concat([df_cat, total_row], ignore_index=True)

    # ── pandas で xlsx 書き出し ────────────────────────────────────────────────
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df_all.to_excel(writer,    sheet_name="全件データ",    index=False)
        df_vendor.to_excel(writer, sheet_name="企業別内訳",    index=False)
        df_cat.to_excel(writer,    sheet_name="ジャンル別内訳", index=False)

    # ── openpyxl で書式を上乗せ ────────────────────────────────────────────────
    wb = load_workbook(out_path)
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        _style_header_row(ws)
        _apply_money_format(ws)
        _auto_col_width(ws)
        if sheet_name == "ジャンル別内訳":
            for cell in ws[ws.max_row]:
                cell.fill = _TTL_FILL
                cell.font = Font(bold=True, size=10)
    wb.save(out_path)
    print(f"  -> Excel 保存完了: {out_path}")


# ── メイン ────────────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("JAXA FY2024 契約実績 収集スクリプト")
    print("=" * 60)

    # 1. PDF ダウンロード
    pdf_data = download_pdf(PDF_URL)

    # 2. PDF パース
    print("\n[2] PDFパース中...")
    records = parse_pdf(pdf_data, PDF_URL)
    print(f"  -> {len(records)} 件抽出")

    if not records:
        print("\n[ERROR] レコードが取得できませんでした。PDFのフォーマットを確認してください。")
        sys.exit(1)

    # 3. DB 保存
    print(f"\n[3] DB 保存中: {DB_PATH}")
    conn = setup_db(DB_PATH)
    conn.execute("DELETE FROM contracts")
    conn.commit()
    insert_records(conn, records)
    print(f"  -> {len(records)} 件挿入完了")

    # 4. 統計サマリー
    row = conn.execute(
        """
        SELECT
            COUNT(*)                                              AS cnt,
            COALESCE(SUM(CASE WHEN contract_amount > 0 THEN contract_amount ELSE 0 END), 0) AS total,
            SUM(CASE WHEN contract_date  IS NOT NULL THEN 1 ELSE 0 END) AS dated,
            SUM(CASE WHEN contract_amount IS NULL    THEN 1 ELSE 0 END) AS no_amt,
            MIN(contract_date)  AS min_dt,
            MAX(contract_date)  AS max_dt
        FROM contracts
        """
    ).fetchone()
    cnt, total, dated, no_amt, min_dt, max_dt = row

    print(f"\n【統計サマリー】")
    print(f"  件数         : {cnt:,} 件")
    print(f"  契約金額合計 : {total/1e8:,.1f} 億円 (¥{total:,.0f})")
    print(f"  日付充填率   : {dated}/{cnt} ({dated/cnt*100:.1f}%)" if cnt else "")
    print(f"  金額欠損件数 : {no_amt} 件")
    print(f"  期間         : {min_dt} ~ {max_dt}")

    print("\n【入札方式別】")
    for r in conn.execute(
        "SELECT bid_method, COUNT(*), SUM(CASE WHEN contract_amount>0 THEN contract_amount ELSE 0 END) "
        "FROM contracts GROUP BY bid_method ORDER BY 3 DESC"
    ):
        print(f"  {(r[0] or '不明'):25s}: {r[1]:5d} 件  {(r[2] or 0)/1e8:8.1f} 億")

    print("\n【カテゴリ別内訳】")
    for r in conn.execute(
        "SELECT category, COUNT(*), SUM(CASE WHEN contract_amount>0 THEN contract_amount ELSE 0 END) "
        "FROM contracts GROUP BY category "
        "ORDER BY SUM(CASE WHEN contract_amount>0 THEN contract_amount ELSE 0 END) DESC"
    ):
        pct = (r[2] or 0) / total * 100 if total else 0
        print(f"  {(r[0] or 'その他'):20s}: {r[1]:5d} 件  {(r[2] or 0)/1e8:8.1f} 億  ({pct:.1f}%)")

    print("\n【企業別上位15社（正の金額ベース）】")
    for r in conn.execute(
        "SELECT vendor_name, COUNT(*), "
        "SUM(CASE WHEN contract_amount>0 THEN contract_amount ELSE 0 END) AS tot "
        "FROM contracts GROUP BY vendor_name ORDER BY tot DESC LIMIT 15"
    ):
        print(f"  {(r[0] or '')[:30]:30s}: {r[1]:4d} 件  {(r[2] or 0)/1e8:8.2f} 億")

    # 5. Excel エクスポート
    print(f"\n[5] Excel エクスポート中: {EXCEL_PATH}")
    export_excel(conn, EXCEL_PATH)

    conn.close()
    print("\n=== 完了 ===")
    print(f"  DB:    {DB_PATH}")
    print(f"  Excel: {EXCEL_PATH}")


if __name__ == "__main__":
    main()
