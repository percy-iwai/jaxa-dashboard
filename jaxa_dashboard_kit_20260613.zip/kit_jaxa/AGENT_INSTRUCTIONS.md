# AIエージェント向け指示書（Claude Cowork 想定）

このフォルダは「JAXA・宇宙関連予算ダッシュボード 引っ越しキット」です。
あなた（AIエージェント）の役割は、**用意済みのスクリプトを順番に起動して完了を待つこと**です。
コードを書くことではありません。

DBは同梱済みのため、防衛キットと違い**ダウンロードも再構築も不要**です。全工程は10分以内に終わります。

## 最初に貼るプロンプト（人間用: これをCoworkセッションの最初に貼り付ける）

```
このフォルダはJAXA・宇宙関連予算ダッシュボードの引っ越しキットです。
kit_jaxa/AGENT_INSTRUCTIONS.md の行動ルールに従って、kit_jaxa/SETUP.md の
Step 1〜3 を順番に実行し、ダッシュボードを起動してください。各ステップは
スクリプトを起動して SUMMARY 行で成否判定するだけです。スクリプトの改変・
再実装はしないでください。最後に verify の結果を報告してください。
```

## 行動ルール（クレジット消費を最小にするための約束）

1. **各ステップは「起動 → 完了待ち → 最後の `SUMMARY` 行で成否判定」だけ。**
   ログ全文を読まない。スクリプトのソースを読まない。
2. **スクリプトの修正・再実装・改善提案をしない。** 設計済み・検証済みです。
   うまく動かない場合も、まず下の早見表 → それでも不明なら**人間に報告して指示を待つ**。
3. **深い調査（DB直接クエリ・ソース精読）をしてよいのは verify が FAIL のときだけ。**
   そのときも読むのは `kit_jaxa/exports/verify_report.json` のみ。
4. ネットワークを使うのは Step 1 の pip install と増分収集だけ。検証・起動は全てローカル処理。
5. 同梱DB（`jaxa_deploy/data/` 配下・`data/db/` 配下）を手で UPDATE/DELETE しない。

## 実行手順（= SETUP.md の要約）

| # | コマンド | 成功判定（SUMMARY行） | 所要 |
|---|---------|----------------------|------|
| 1 | `bash kit_jaxa/setup_env.sh`（Win: `powershell -ExecutionPolicy Bypass -File kit_jaxa\setup_env.ps1`） | `setup=OK` | 数分 |
| 2 | `python kit_jaxa/verify_kit.py` | `result=PASS` | 数秒 |
| 3 | `python -m streamlit run jaxa_deploy/app.py` | 起動して3タブ表示 | — |

**縮退ルート**: Step 1 がネットワーク制約で失敗し続ける場合（wheels同梱も無い場合）は、
Step 3 の代わりに `python kit_jaxa/export_csv_xlsx.py --csv-only`
（成功判定: `export_data=OK`、標準ライブラリのみで動く）を実行してCSVを納品し、
「ダッシュボードはStreamlit導入不可のため未起動」と人間に報告する。

## よくある事象と一次対処（この表の範囲は自分で対処してよい）

| 事象 | 一次対処 | 上限 |
|------|---------|------|
| `ModuleNotFoundError` | venv未activate。`.venv\Scripts\Activate.ps1`（mac/Linux: `source .venv/bin/activate`）後に再実行 | — |
| pip install 失敗 | ネットワーク/プロキシ確認 → 再実行 | 2回まで |
| verify で `result=WARN`（sha256のみ不一致・件数一致） | DBが旧環境で更新された可能性。件数一致なら続行可。人間に一言報告 | — |
| verify で `result=FAIL` | zip展開不全の可能性。zipを再展開 → verify 再実行 | 1回まで |
| `database is locked` | streamlit 等を止めて再実行 | — |
| 文字化け | `PYTHONUTF8=1` を設定して再実行（SUMMARY行は常にASCII） | — |

**上限を超えても直らない / 表にない事象 → 作業を止めて人間に報告。**
報告に含めるもの: ①実行したコマンド ②最後のSUMMARY行 ③`kit_jaxa/exports/verify_report.json` の `fails` 配列。

## 人間に判断を仰ぐべきこと（自分で決めない）

- verify FAIL のままダッシュボードを公開してよいか
- 増分収集（新年度データの追加）をいつ・どの範囲で実行するか
- スクリプトの改修・依存パッケージのバージョン変更

## このDBについての前提知識（質問されたとき用）

- 中身: ①JAXA公開調達情報 36,153件（FY2019–2024）②宇宙戦略基金 68テーマ
  ③行政事業レビュー宇宙関連 38事業
- ダッシュボード: `jaxa_deploy/app.py`（Streamlit・3タブ）。DBは `jaxa_deploy/data/` 配下を読む
- rssystem.go.jp payment-groups の**1年オフセット問題**など収集の罠は `kit_jaxa/KNOWLEDGE.md` 参照
