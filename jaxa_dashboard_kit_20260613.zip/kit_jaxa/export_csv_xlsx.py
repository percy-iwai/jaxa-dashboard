"""DBの全テーブルを CSV / XLSX に吐き出す（Streamlit不要の縮退モード兼データ受け渡し用）。

- CSV: **Python標準ライブラリのみ**で動く（pip install 一切不要）。
  Excelで開けるよう utf-8-sig（BOM付き）で出力
- XLSX: openpyxl が入っていれば DBごとに1ブック（テーブル=シート）を生成。
  無ければ自動スキップしてCSVのみ（エラーにしない）

実行（キット展開ルートで）:
  python kit_jaxa/export_csv_xlsx.py             # 全DB → exports_data/
  python kit_jaxa/export_csv_xlsx.py --csv-only  # XLSXを作らない

出力:
  exports_data/<DB名>/<テーブル>.csv
  exports_data/<DB名>.xlsx
"""
from __future__ import annotations

import argparse
import csv
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
ROOT = KIT_DIR.parent

# 吐き出し対象DB（キット展開ルートからの相対パス）。テーブルは全件自動検出
DATABASES = [
    "jaxa_deploy/data/db/jaxa_procurement.db",
    "jaxa_deploy/data/fund_jaxa.db",
    "jaxa_deploy/data/review_space.db",
]

OUT_DIR = ROOT / "exports_data"


def export_db(db_path: Path, csv_only: bool) -> tuple[int, int]:
    """1DBを吐き出して (テーブル数, 行数合計) を返す。"""
    name = db_path.stem
    con = sqlite3.connect(db_path)
    tables = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name")]

    csv_dir = OUT_DIR / name
    csv_dir.mkdir(parents=True, exist_ok=True)

    wb = None
    clean = None
    if not csv_only:
        try:
            from openpyxl import Workbook
            from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
            wb = Workbook(write_only=True)

            def clean(v):  # XLSXに書けない制御文字を除去（PDF抽出テキスト対策）
                if isinstance(v, str):
                    return ILLEGAL_CHARACTERS_RE.sub("", v)
                return v
        except ImportError:
            print(f"  [INFO] openpyxl 未インストール → {name} はCSVのみ")

    total_rows = 0
    for t in tables:
        cur = con.execute(f"SELECT * FROM [{t}]")
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        total_rows += len(rows)

        with open(csv_dir / f"{t}.csv", "w", newline="",
                  encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(cols)
            w.writerows(rows)

        if wb is not None:
            ws = wb.create_sheet(title=t[:31])  # Excelのシート名は31文字まで
            ws.append(cols)
            for r in rows:
                ws.append([clean(v) for v in r])
        print(f"  {name}/{t}: {len(rows):,} rows")

    con.close()
    if wb is not None:
        wb.save(OUT_DIR / f"{name}.xlsx")
    return len(tables), total_rows


def main() -> None:
    parser = argparse.ArgumentParser(description="DB → CSV/XLSX 吐き出し")
    parser.add_argument("--csv-only", action="store_true",
                        help="XLSXを生成しない（openpyxl不要）")
    args = parser.parse_args()

    n_db = n_tab = n_row = 0
    missing = []
    for rel in DATABASES:
        p = ROOT / rel
        if not p.exists():
            missing.append(rel)
            print(f"  [WARN] 見つからない: {rel}")
            continue
        tabs, rows = export_db(p, args.csv_only)
        n_db += 1
        n_tab += tabs
        n_row += rows

    status = "OK" if not missing else "WARN"
    print(f"SUMMARY export_data={status} dbs={n_db} tables={n_tab} "
          f"rows={n_row} missing={len(missing)} out={OUT_DIR}")
    sys.exit(0 if not missing else 1)


if __name__ == "__main__":
    main()
