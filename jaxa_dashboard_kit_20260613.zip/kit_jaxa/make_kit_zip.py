"""自己完結の引っ越しキットzipを生成する（旧環境で実行）。

同梱物:
  ダッシュボード: jaxa_deploy/（app.py・3ダッシュボード・DB3本・.streamlit）
  マスターDB:    data/db/jaxa_procurement.db data/review_space.db
                 fund_jaxa/data/fund_jaxa.db
  増分収集:      collect_jaxa_fy2024.py collect_jaxa_multi_fy.py make_jaxa_excel.py
                 scripts/fetch_review_data.py fund_jaxa/scripts/*.py parsers/
  キット:        kit_jaxa/（このフォルダ。exports/expected_state.json 含む）
  ※ fund_jaxa/data/ の原本キャッシュ（HTML/PDF）は同梱しない — 再取得可能

実行:
  python kit_jaxa/export_expected_state.py   # 先に検証基準を最新化
  python kit_jaxa/make_kit_zip.py            # → jaxa_dashboard_kit_<date>.zip
  python kit_jaxa/make_kit_zip.py --output D:/path/kit.zip
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from datetime import datetime
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
ROOT = KIT_DIR.parent

INCLUDE_DIRS = [
    "kit_jaxa",
    "jaxa_deploy",
    "parsers",
    "fund_jaxa/scripts",
]
INCLUDE_FILES = [
    "collect_jaxa_fy2024.py",
    "collect_jaxa_multi_fy.py",
    "make_jaxa_excel.py",
    "scripts/fetch_review_data.py",
    "data/db/jaxa_procurement.db",
    "data/review_space.db",
    "fund_jaxa/data/fund_jaxa.db",
]

EXCLUDE_PARTS = {"__pycache__", ".venv", "node_modules", ".git"}
EXCLUDE_SUFFIXES = {".pyc", ".log", ".tmp"}
EXCLUDE_NAMES = {"secrets.toml", "verify_report.json", "kit_manifest.json"}


def _excluded(p: Path, include_wheels: bool) -> bool:
    if any(part in EXCLUDE_PARTS for part in p.parts):
        return True
    if not include_wheels and "wheels" in p.parts:
        return True
    if p.suffix.lower() in EXCLUDE_SUFFIXES:
        return True
    if p.name in EXCLUDE_NAMES:
        return True
    return False


def collect_files(include_wheels: bool) -> list[Path]:
    files: list[Path] = []
    for d in INCLUDE_DIRS:
        base = ROOT / d
        if not base.exists():
            print(f"  WARN: {d} が存在しません")
            continue
        for p in base.rglob("*"):
            if p.is_file() and not _excluded(p, include_wheels):
                files.append(p)
    for f in INCLUDE_FILES:
        p = ROOT / f
        if p.exists():
            files.append(p)
        else:
            print(f"  WARN: {f} が存在しません")
    return sorted(set(files))


def main() -> None:
    parser = argparse.ArgumentParser(description="JAXAダッシュボード引っ越しキットzip生成")
    parser.add_argument("--output",
                        default=str(ROOT / f"jaxa_dashboard_kit_"
                                           f"{datetime.now():%Y%m%d}.zip"))
    parser.add_argument("--include-wheels", action="store_true",
                        help="kit_jaxa/wheels/（オフラインinstall用）も同梱する")
    args = parser.parse_args()

    expected = KIT_DIR / "exports" / "expected_state.json"
    if not expected.exists():
        print("SUMMARY zip=FAIL reason=expected_state_not_found "
              "(先に export_expected_state.py を実行)")
        sys.exit(1)
    if args.include_wheels and not (KIT_DIR / "wheels").exists():
        print("SUMMARY zip=FAIL reason=wheels_not_found "
              "(先に download_wheels.py を実行)")
        sys.exit(1)

    files = collect_files(args.include_wheels)
    out = Path(args.output)

    manifest: dict = {"created_at": datetime.now().isoformat(timespec="seconds"),
                      "kit": "jaxa", "files": {}}
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            rel = p.relative_to(ROOT).as_posix()
            zf.write(p, rel)
            manifest["files"][rel] = {
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()[:16],
            }
        zf.writestr("kit_manifest.json",
                    json.dumps(manifest, ensure_ascii=False, indent=1))

    total_mb = sum(v["bytes"] for v in manifest["files"].values()) / 1e6
    print(f"SUMMARY zip=OK files={len(files)} uncompressed={total_mb:.0f}MB "
          f"zip={out.stat().st_size / 1e6:.0f}MB")
    print(f"出力: {out}")


if __name__ == "__main__":
    main()
