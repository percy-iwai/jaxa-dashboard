# JAXA・宇宙関連予算ダッシュボード 引っ越しキット

JAXA調達情報DB（contracts 36,153件 / FY2019–2024）＋ 宇宙戦略基金DB ＋
行政事業レビュー宇宙関連DB と、それらを表示する Streamlit ダッシュボード
（`jaxa_deploy/app.py`、3タブ構成）を別環境へ移設するためのキットです。

## 考え方 — 防衛キットとの違い（DB同梱型）

防衛調達キット（defense_procurement_2nd/kit）は DB 174MB＋原本キャッシュ10GB超のため
「URLリスト＋パーサーで再生成」方式でしたが、本キットの DB は**合計約18MBと小さい**ため、

- **DB本体をそのまま同梱**します。新環境でのダウンロード・再構築は不要（数分で起動可）
- 収集スクリプトは「ゼロから再構築するため」ではなく**増分更新（新年度データ追加）用**に同梱
- 検証は「再構築結果の突合」ではなく「**同梱DBが壊れず届いたかのチェックサム＋件数照合**」

## クイックスタート（3ステップ）

```bash
# 1. 環境構築（Python 3.10+ が必要）
bash kit_jaxa/setup_env.sh            # Windows: powershell -ExecutionPolicy Bypass -File kit_jaxa\setup_env.ps1

# 2. 同梱DBの検証（数秒）
python kit_jaxa/verify_kit.py

# 3. ダッシュボード起動
python -m streamlit run jaxa_deploy/app.py
```

`verify_kit.py` が `SUMMARY result=PASS` を出せば移設完了。
ブラウザで http://localhost:8501 を開くと3タブ（JAXA契約実績 / 行政事業レビュー宇宙関連 / 宇宙戦略基金）が表示されます。

## キットの中身

| パス | 内容 |
|------|------|
| `kit_jaxa/README_KIT.md` | このファイル（人間向け概要） |
| `kit_jaxa/SETUP.md` | ステップバイステップ手順書（増分更新手順つき） |
| `kit_jaxa/AGENT_INSTRUCTIONS.md` | **Claude Cowork 等のAIエージェント向け指示書**（最初に読ませる） |
| `kit_jaxa/KNOWLEDGE.md` | ドメイン知識（payment-groups年度オフセット等の罠） |
| `kit_jaxa/setup_env.ps1` / `.sh` | Python仮想環境ブートストラップ |
| `kit_jaxa/requirements.txt` | 依存パッケージ（ダッシュボード＋増分収集） |
| `kit_jaxa/verify_kit.py` | 同梱DBの整合性検証（PASS/WARN/FAIL） |
| `kit_jaxa/export_csv_xlsx.py` | **DB → CSV/XLSX 吐き出し**（CSVは標準ライブラリのみ＝pip不要で動く） |
| `kit_jaxa/download_wheels.py` | （旧環境用）オフラインinstall用wheelsのダウンロード |
| `kit_jaxa/export_expected_state.py` | （旧環境用）検証基準 expected_state.json の生成 |
| `kit_jaxa/make_kit_zip.py` | （旧環境用）このzip自体の生成スクリプト（`--include-wheels` でwheels同梱） |
| `kit_jaxa/exports/expected_state.json` | 検証基準（テーブル件数・SHA256・FY別集計） |
| `jaxa_deploy/` | **ダッシュボード本体＋DB3本**（自己完結。これだけでも動く） |
| `data/db/jaxa_procurement.db` ほか | 収集スクリプトが書き込むマスターDB（deploy配下と同内容） |
| `parsers/` | JAXA調達PDFのパーサー（増分収集に必要） |
| `collect_jaxa_*.py` / `scripts/fetch_review_data.py` / `fund_jaxa/scripts/` | 増分収集スクリプト |

## データの中身（2026-06-13 キット作成時点）

| DB | テーブル | 件数 | 内容 |
|----|---------|------|------|
| `jaxa_procurement.db` | contracts | 36,153 | JAXA公開調達情報（会計法公表データ、FY2019–2024） |
| `fund_jaxa.db` | themes / theme_budgets / research_tasks / organizations | 67 / 105 / 169 / 161 | 宇宙戦略基金（fund.jaxa.jp＋各省実施方針PDF） |
| `review_space.db` | projects / payees | 38 / 539 | 行政事業レビュー 宇宙関連（rssystem.go.jp） |

## 増分更新（新年度データの追加）

`kit_jaxa/SETUP.md` の「増分更新」参照。要点:
更新は**マスターDB（`data/db/` 等）に書き込み → `jaxa_deploy/data/` へコピー → expected再生成**の3手。

## Streamlit と環境制約について（よくある質問）

**Q. Streamlit は移植先で入れ直しが必要？**
はい。仮想環境（.venv）はパス埋め込み＆OS依存のため持ち運べず、移植先で
`setup_env` が requirements.txt から入れ直します（全自動）。

**Q. どんな環境でも入る？**
必要条件は **Python 3.10+ と PyPIへのネット接続** の2つだけ。管理者権限は不要
（venvはユーザー権限で作れる）。プロキシ環境は `pip config` または
`HTTPS_PROXY` 環境変数で通せば可。

**Q. ネットに出られない環境では？**
2段構えで対応:
1. **wheels同梱**: 旧環境で `python kit_jaxa/download_wheels.py` →
   `python kit_jaxa/make_kit_zip.py --include-wheels`（zipは+100MB前後）。
   移植先の setup_env が wheels/ を検知して自動でオフラインinstallに切り替わる。
   ※ バイナリwheelのため**移植先とOS・Pythonマイナーバージョンの一致が必要**
   （Linux向けは `--platform manylinux2014_x86_64 --python-version 3.12` 等で指定DL）
2. **縮退モード**: Streamlit が入らなくても
   `python kit_jaxa/export_csv_xlsx.py --csv-only` は**Python標準ライブラリのみ**で
   全テーブルをCSV化できる（pip install ゼロ）。openpyxl だけ入ればXLSXも出る。
   つまり「収集 → DB → CSV/XLSX」のデータパイプラインはダッシュボード無しでも完結する。

## CSV / XLSX 吐き出し

```bash
python kit_jaxa/export_csv_xlsx.py            # 全DB・全テーブル → exports_data/
python kit_jaxa/export_csv_xlsx.py --csv-only # pip不要（標準ライブラリのみ）
python make_jaxa_excel.py                     # 整形済みExcel（openpyxlのみで動作）
```

## 再現の限界（正直な注意書き）

- DB同梱型のため「同梱DBが壊れていた」場合の復旧はzipの再取得が基本
- JAXA調達PDF（stage.tksc.jaxa.jp）は年度ページが消えることがある。過去分の再収集可否は保証しない
- rssystem.go.jp の payment-groups API には**1年の年度オフセット**がある（KNOWLEDGE.md 必読）
