# セットアップ手順書（新環境用・ステップバイステップ）

各ステップは**1コマンド・冪等（何度実行しても安全）**です。
コマンドはすべて**キットを展開したディレクトリの直下**で実行してください。

> Windows で日本語が文字化けする場合は、先に `set PYTHONUTF8=1`（PowerShellは
> `$env:PYTHONUTF8="1"`）を実行してください。機械判定用の `SUMMARY` 行は常にASCIIです。

---

## Step 0. キットの入手と展開

zip を展開するだけ。DBは同梱済みなのでダウンロード工程はありません。

## Step 1. Python環境構築

```bash
bash kit_jaxa/setup_env.sh                                       # macOS / Linux
powershell -ExecutionPolicy Bypass -File kit_jaxa\setup_env.ps1   # Windows
```

- **期待される出力**: `SUMMARY setup=OK venv=... mode=online`
  （wheels同梱キットの場合は `mode=offline-wheels` — ネット不要で完了）
- **失敗時**: Python 3.10+ が無い → インストールして再実行。pip エラー → ネットワーク/プロキシを確認して再実行
- **ネットもwheelsも無い場合**: Step 3（ダッシュボード）は諦め、縮退モードへ →
  `python kit_jaxa/export_csv_xlsx.py --csv-only` は標準ライブラリのみで動く（Step 2'参照）
- 以後のコマンドは venv を activate してから実行
  （`source .venv/bin/activate` / `.venv\Scripts\Activate.ps1`）

## Step 2. 同梱DBの検証（数秒）

```bash
python kit_jaxa/verify_kit.py
```

- 同梱DB（jaxa_procurement.db / fund_jaxa.db / review_space.db）のテーブル件数・
  SHA256・FY別集計を `kit_jaxa/exports/expected_state.json` と突合します
- **期待される出力**: `SUMMARY result=PASS`
- **WARN**: sha256のみ不一致（件数は一致）→ 旧環境でDBが更新された後 expected を再生成し
  忘れたケース。実用上は続行可
- **FAIL**: zip展開不全・DB破損の可能性。zipを再展開してやり直す。
  詳細は `kit_jaxa/exports/verify_report.json`

## Step 2'. CSV / XLSX 吐き出し（任意・Streamlit不要）

```bash
python kit_jaxa/export_csv_xlsx.py             # 全DB・全テーブル → exports_data/
python kit_jaxa/export_csv_xlsx.py --csv-only  # pip install ゼロ（標準ライブラリのみ）
```

- **期待される出力**: `SUMMARY export_data=OK dbs=3 tables=... rows=...`
- CSVは utf-8-sig（BOM付き）なのでExcelでそのまま開ける
- 整形済みExcelが欲しい場合: `python make_jaxa_excel.py`（openpyxlのみで動作）
- Streamlit が入らない制約環境では、このステップが Step 3 の代替になる

## Step 3. ダッシュボード起動

```bash
python -m streamlit run jaxa_deploy/app.py --server.port 8501
```

ブラウザで http://localhost:8501 を開き、3タブ
（🚀JAXA契約実績 / 📋行政事業レビュー宇宙関連 / 💰宇宙戦略基金）が表示されれば完了。

---

## 増分更新（新年度データの追加）

確定分の移設とは別系統です。**マスターDBに書き込み → deploy配下へコピー → expected再生成**の3手が基本形。

### A. JAXA調達情報（jaxa_procurement.db）

```bash
# ソース: https://stage.tksc.jaxa.jp/compe/zui/nendo/zui{YYYY}nendo.pdf
python collect_jaxa_multi_fy.py 2025          # 対象FYを指定（data/db/jaxa_procurement.db に追記）
cp data/db/jaxa_procurement.db jaxa_deploy/data/db/   # deployへ反映
```

### B. 行政事業レビュー宇宙関連（review_space.db）

```bash
python scripts/fetch_review_data.py           # data/review_space.db を再構築
cp data/review_space.db jaxa_deploy/data/
```

> **重要**: payment-groups APIの1年オフセット（FY=NのシートにN−1年度の支払実績が入る）に
> 対応済みのスクリプトです。改変しないこと。詳細は `KNOWLEDGE.md`。

### C. 宇宙戦略基金（fund_jaxa.db）

```bash
# 必ず fetch → parse → supplement の順
python fund_jaxa/scripts/fetch_fund_jaxa.py
python fund_jaxa/scripts/parse_cao_overview_pdfs.py
python fund_jaxa/scripts/supplement_db.py
cp fund_jaxa/data/fund_jaxa.db jaxa_deploy/data/
```

### 更新後の締め（必ず実行）

```bash
python kit_jaxa/export_expected_state.py      # 検証基準を更新後の状態に合わせる
python kit_jaxa/verify_kit.py                 # PASS を確認
```

---

## キットzipの再生成（旧環境用）

```bash
python kit_jaxa/make_kit_zip.py               # → jaxa_dashboard_kit_<date>.zip
```

## トラブルシューティング早見表

| 症状 | 対処 |
|------|------|
| `ModuleNotFoundError` | venv を activate していない / Step 1 をやり直す |
| `database is locked` | 別プロセス（ダッシュボード等）がDBを開いている。閉じて再実行 |
| verify FAIL | zip再展開 → verify。直らなければ旧環境で `export_expected_state.py` → zip再生成 |
| ダッシュボードに「DBが見つかりません」 | `jaxa_deploy/data/` 配下のDB3本の有無を確認（zip展開漏れ） |
| 文字化け | `PYTHONUTF8=1` を設定 |
