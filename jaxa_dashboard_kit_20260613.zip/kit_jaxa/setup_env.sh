#!/usr/bin/env bash
# Python仮想環境ブートストラップ（macOS / Linux）
# 実行: bash kit_jaxa/setup_env.sh
# kit_jaxa/wheels/ が存在する場合は自動でオフラインinstall（ネット不要）に切り替わる
set -e
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(dirname "$KIT_DIR")"
cd "$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
    echo "SUMMARY setup=FAIL reason=python_not_found"
    exit 1
fi

[ -d .venv ] || python3 -m venv .venv

if [ -d "$KIT_DIR/wheels" ]; then
    MODE="offline-wheels"
    .venv/bin/python -m pip install --no-index --find-links "$KIT_DIR/wheels" \
        -r "$KIT_DIR/requirements.txt" --quiet || {
        echo "SUMMARY setup=FAIL reason=pip_install_error mode=$MODE"
        echo "HINT: ネットもwheelsも無い場合でも、CSV吐き出し（kit_jaxa/export_csv_xlsx.py --csv-only）は標準ライブラリのみで動く"
        exit 1; }
else
    MODE="online"
    .venv/bin/python -m pip install --upgrade pip --quiet
    .venv/bin/python -m pip install -r "$KIT_DIR/requirements.txt" --quiet || {
        echo "SUMMARY setup=FAIL reason=pip_install_error mode=$MODE"
        echo "HINT: ネットもwheelsも無い場合でも、CSV吐き出し（kit_jaxa/export_csv_xlsx.py --csv-only）は標準ライブラリのみで動く"
        exit 1; }
fi
echo "SUMMARY setup=OK venv=$ROOT/.venv mode=$MODE"
