import sqlite3, sys, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")

HEADER_BG   = "1F497D"
HEADER_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
HEADER_FILL = PatternFill("solid", fgColor=HEADER_BG)
AMT_FORMAT  = "#,##0"
DATA_FONT   = Font(name="Arial", size=10)

def style_header(ws, height=20, wrap=False):
    ws.row_dimensions[1].height = height
    for cell in ws[1]:
        cell.font  = HEADER_FONT
        cell.fill  = HEADER_FILL
        cell.alignment = Alignment(
            horizontal="center", vertical="center", wrap_text=wrap
        )

def set_col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

def fmt_date(s):
    if s and len(s) == 8 and s.isdigit():
        return f"{s[:4]}/{s[4:6]}/{s[6:]}"
    return s or ""

TOTAL_FONT = Font(bold=True, name="Arial", size=10)
TOTAL_FILL = PatternFill("solid", fgColor="D9E1F2")

def add_total_row(ws, values):
    ws.append(values)
    for cell in ws[ws.max_row]:
        cell.font = TOTAL_FONT
        cell.fill = TOTAL_FILL

conn = sqlite3.connect("data/db/jaxa_procurement.db")
cur  = conn.cursor()

# ── 全件データ ──
cur.execute("""
    SELECT fiscal_year, contract_name, contract_officer, contract_date,
           vendor_name, vendor_address, corporate_number, bid_method,
           zuii_reason, estimated_price, contract_amount, award_rate, category
    FROM contracts
    WHERE fiscal_year BETWEEN 2019 AND 2024
    ORDER BY fiscal_year, contract_date
""")
all_rows = cur.fetchall()

# ── 企業別集計 ──
cur.execute("""
    SELECT vendor_name,
           COUNT(*) as cnt,
           SUM(contract_amount) as total,
           AVG(contract_amount) as avg_amt,
           MAX(contract_amount) as max_amt,
           NULL as top_item
    FROM contracts
    WHERE fiscal_year BETWEEN 2019 AND 2024
      AND vendor_name IS NOT NULL AND vendor_name != ''
    GROUP BY vendor_name
    ORDER BY total DESC
""")
vendor_rows = cur.fetchall()

# ── カテゴリ別集計 ──
cur.execute("""
    SELECT category, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year BETWEEN 2019 AND 2024 AND category IS NOT NULL
    GROUP BY category ORDER BY total DESC
""")
cat_rows = cur.fetchall()
grand_total = sum(r[2] for r in cat_rows if r[2])

# ── 年度別サマリー ──
cur.execute("""
    SELECT fiscal_year,
           COUNT(*) as cnt,
           SUM(contract_amount) as total,
           SUM(CASE WHEN bid_method='随意契約' THEN 1 ELSE 0 END),
           SUM(CASE WHEN bid_method='随意契約' THEN contract_amount ELSE 0 END),
           SUM(CASE WHEN bid_method='一般競争入札' THEN 1 ELSE 0 END),
           SUM(CASE WHEN bid_method='一般競争入札' THEN contract_amount ELSE 0 END),
           AVG(contract_amount),
           MAX(contract_amount),
           COUNT(DISTINCT vendor_name)
    FROM contracts
    WHERE fiscal_year BETWEEN 2019 AND 2024
    GROUP BY fiscal_year ORDER BY fiscal_year
""")
fy_rows = cur.fetchall()
conn.close()

# ══════════════════════════════════════════════════════
wb = openpyxl.Workbook()

# ── Sheet 1: 全件データ ──
ws1 = wb.active
ws1.title = "全件データ"
ws1.append(["年度","件名","契約担当官","契約締結日","相手方（企業名）",
            "相手方住所","法人番号","入札方式","随意契約の根拠",
            "予定価格（円）","契約金額（円）","落札率（%）","カテゴリ"])
style_header(ws1)
ws1.freeze_panes = "A2"
ws1.auto_filter.ref = f"A1:M1"

for r in all_rows:
    row = list(r)
    row[3] = fmt_date(row[3])
    ws1.append(row)

for row in ws1.iter_rows(min_row=2, max_row=ws1.max_row):
    row[9].number_format  = AMT_FORMAT
    row[10].number_format = AMT_FORMAT
    row[11].number_format = "0.00"

set_col_widths(ws1, [6, 50, 28, 12, 24, 28, 14, 12, 30, 15, 15, 10, 14])
print(f"Sheet1 done: {ws1.max_row-1} rows")

# ── Sheet 2: 企業別内訳 ──
ws2 = wb.create_sheet("企業別内訳")
ws2.append(["企業名","件数","契約金額合計（円）","契約金額平均（円）",
            "最大契約金額（円）","代表的な品目（最大金額）"])
style_header(ws2)
ws2.freeze_panes = "A2"
ws2.auto_filter.ref = "A1:F1"

for r in vendor_rows:
    ws2.append(list(r))

for row in ws2.iter_rows(min_row=2, max_row=ws2.max_row):
    row[2].number_format = AMT_FORMAT
    row[3].number_format = AMT_FORMAT
    row[4].number_format = AMT_FORMAT

set_col_widths(ws2, [28, 8, 18, 18, 18, 50])
print(f"Sheet2 done: {ws2.max_row-1} vendors")

# ── Sheet 3: ジャンル別内訳 ──
ws3 = wb.create_sheet("ジャンル別内訳")
ws3.append(["カテゴリ","件数","契約金額合計（円）","構成比（%）"])
style_header(ws3)

for r in cat_rows:
    pct = round(r[2] / grand_total * 100, 1) if grand_total and r[2] else 0
    ws3.append([r[0], r[1], r[2], pct])

total_cnt = sum(r[1] for r in cat_rows)
add_total_row(ws3, ["合計", total_cnt, grand_total, 100.0])

for row in ws3.iter_rows(min_row=2, max_row=ws3.max_row):
    row[2].number_format = AMT_FORMAT
    row[3].number_format = "0.0"

set_col_widths(ws3, [20, 8, 18, 12])
print(f"Sheet3 done: {ws3.max_row-1} categories + total")

# ── Sheet 4: 年度別サマリー ──
ws4 = wb.create_sheet("年度別サマリー")
ws4.append([
    "年度","件数","契約金額合計（円）","平均契約金額（円）","最大契約金額（円）",
    "随意契約件数","随意契約金額（円）","随意契約率（件数%）","随意契約率（金額%）",
    "競争入札件数","競争入札金額（円）","競争入札率（件数%）",
    "ベンダー数"
])
style_header(ws4, height=40, wrap=True)
ws4.freeze_panes = "A2"

for r in fy_rows:
    fy, cnt, total, zuii_cnt, zuii_amt, kyoso_cnt, kyoso_amt, avg_amt, max_amt, vendor_cnt = r
    zuii_rate_cnt = round(zuii_cnt / cnt * 100, 1) if cnt else 0
    zuii_rate_amt = round(zuii_amt / total * 100, 1) if total else 0
    kyoso_rate    = round(kyoso_cnt / cnt * 100, 1) if cnt else 0
    ws4.append([
        fy, cnt, int(total) if total else 0,
        int(round(avg_amt)) if avg_amt else 0,
        int(max_amt) if max_amt else 0,
        zuii_cnt, int(zuii_amt) if zuii_amt else 0,
        zuii_rate_cnt, zuii_rate_amt,
        kyoso_cnt, int(kyoso_amt) if kyoso_amt else 0,
        kyoso_rate, vendor_cnt
    ])

all_cnt       = sum(r[1] for r in fy_rows)
all_total     = sum(r[2] for r in fy_rows)
all_zuii_cnt  = sum(r[3] for r in fy_rows)
all_zuii_amt  = sum(r[4] for r in fy_rows)
all_kyoso_cnt = sum(r[5] for r in fy_rows)
all_kyoso_amt = sum(r[6] for r in fy_rows)
add_total_row(ws4, [
    "合計", all_cnt, all_total,
    int(round(all_total/all_cnt)) if all_cnt else 0, "",
    all_zuii_cnt, all_zuii_amt,
    round(all_zuii_cnt/all_cnt*100, 1) if all_cnt else 0,
    round(all_zuii_amt/all_total*100, 1) if all_total else 0,
    all_kyoso_cnt, all_kyoso_amt,
    round(all_kyoso_cnt/all_cnt*100, 1) if all_cnt else 0,
    ""
])

for row in ws4.iter_rows(min_row=2, max_row=ws4.max_row):
    row[2].number_format  = AMT_FORMAT
    row[3].number_format  = AMT_FORMAT
    row[4].number_format  = AMT_FORMAT
    row[6].number_format  = AMT_FORMAT
    row[7].number_format  = "0.0"
    row[8].number_format  = "0.0"
    row[10].number_format = AMT_FORMAT
    row[11].number_format = "0.0"

set_col_widths(ws4, [7, 8, 18, 16, 16, 12, 18, 16, 16, 12, 18, 14, 10])
print(f"Sheet4 done: {ws4.max_row-1} FY rows + total")

out = "data/output/jaxa_fy2019_2024.xlsx"
wb.save(out)
print(f"\nSaved: {out}")
