"""
rssystem.go.jp 行政事業レビュー DB構築スクリプト（宇宙関連版）

対象組織:
  847ec284-6f87-4d79-8693-90a650ee067a  文部科学省 宇宙開発利用課
  d78ed8b4-1a09-4b62-8bf4-b4c9f4dcf759  内閣府 宇宙開発戦略推進本部
  70621f7c-4c5a-4220-8e06-333adfdac092  総務省 宇宙通信政策課
  9b734d1e-c6eb-49a9-a46e-39ca0998a41b  経産省 宇宙産業課

対象年度: FY2022/2023/2024/2025

スキーマは航空局版 atc_review.db と同一（build_rs_db.py 準拠）

実行: python scripts/fetch_review_data.py
保存: data/review_space.db
"""

import json
import os
import sqlite3
import time
from collections import deque

import requests

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE, "data", "review_space.db")

# ── 対象組織 ──────────────────────────────────────────────────────
SPACE_ORGS = [
    ("847ec284-6f87-4d79-8693-90a650ee067a", "文科省 宇宙開発利用課"),
    ("d78ed8b4-1a09-4b62-8bf4-b4c9f4dcf759", "内閣府 宇宙開発戦略推進本部"),
    ("70621f7c-4c5a-4220-8e06-333adfdac092", "総務省 宇宙通信政策課"),
    ("9b734d1e-c6eb-49a9-a46e-39ca0998a41b", "経産省 宇宙産業課"),
]
FISCAL_YEARS = [2022, 2023, 2024, 2025]

API_BASE = "https://rssystem.go.jp/api"
HEADERS = {
    "Accept": "application/json",
    "User-Agent": "Mozilla/5.0 (compatible; research-tool/1.0)",
    "Referer": "https://rssystem.go.jp/",
}


# ── helpers ───────────────────────────────────────────────────────

def yen(v):
    if v is None:
        return "N/A"
    return f"{v/1e8:.2f}億円"


def api_get(path, params=None, retries=3):
    url = f"{API_BASE}{path}"
    for attempt in range(retries):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=30)
            if r.status_code == 404:
                return None
            r.raise_for_status()
            return r.json()
        except requests.RequestException as exc:
            print(f"  [WARN] attempt {attempt+1} failed for {url}: {exc}")
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
    return None


def fetch_project_list(org_id, fiscal_year):
    """1組織×1年度のプロジェクト一覧を取得（ページング対応）"""
    all_results = []
    page = 1
    while True:
        data = api_get(
            "/projects/",
            params={
                "organization_ids": org_id,
                "fiscal_year": fiscal_year,
                "page": page,
                "page_size": 100,
            },
        )
        if data is None:
            break
        if isinstance(data, list):
            all_results.extend(data)
            break
        results = data.get("results", [])
        all_results.extend(results)
        if not data.get("next"):
            break
        page += 1
        time.sleep(0.3)
    return all_results


def fetch_project_detail(project_id):
    return api_get(f"/projects/{project_id}/")


def extract_budget(detail):
    """
    sub_projects → expenditure_carts から予算内訳と執行額を集計。
    build_rs_db.py の extract_budget() と同一ロジック。
    Returns:
        initial_budget, supplementary, carryover, budget_total, executed_amount, items
    """
    initial = supplementary = carryover = 0
    executed = None
    items = []

    subs = detail.get("sub_projects", []) or []
    for sub in subs:
        for cart in sub.get("expenditure_carts", []) or []:
            # 執行額
            exec_item = cart.get("execution_item") or {}
            if exec_item.get("amount") is not None:
                executed = (executed or 0) + exec_item["amount"]

            # 予算内訳
            for ei in cart.get("expenditure_items", []) or []:
                amt = ei.get("finalized_amount") or 0
                bt_type = (ei.get("budget_type") or {}).get("type", "")
                bt_name = (ei.get("budget_type") or {}).get("name", "")

                # 費目名
                ep = ei.get("expenditure_budget_purpose") or {}
                ep_purpose = ep.get("expenditure_purpose") or {}
                ep_upper = ep_purpose.get("upper") or {}
                purpose_name = ep_purpose.get("name") or ep_upper.get("name") or ""
                upper_name = ep_upper.get("name") or ""

                if bt_type == "initial":
                    initial += amt
                elif bt_type == "supplementary":
                    supplementary += amt
                elif bt_type == "carried-forward":
                    carryover += amt

                items.append({
                    "purpose_name": purpose_name,
                    "upper_name": upper_name,
                    "budget_type": bt_name,
                    "budget_type_code": bt_type,
                    "finalized_amount": amt if amt else None,
                    "requested_amount": ei.get("requested_amount"),
                    "expenditure_item_id": ei.get("id"),
                })

    budget_total = initial + supplementary + carryover
    return initial, supplementary, carryover, budget_total, executed, items


# ── DB 構築 ────────────────────────────────────────────────────────

def build_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    # atc_review.db と同一スキーマ
    cur.executescript("""
    CREATE TABLE projects (
        id              TEXT PRIMARY KEY,
        fiscal_year     INTEGER,
        name            TEXT,
        organization    TEXT,
        org_full_path   TEXT,
        ministry_name   TEXT,
        initial_budget  INTEGER,
        supplementary   INTEGER,
        carryover       INTEGER,
        budget_total    INTEGER,
        executed_amount INTEGER,
        execution_rate  REAL,
        lineage_id      TEXT,
        overview        TEXT
    );

    CREATE TABLE expenditure_items (
        id                TEXT,
        project_id        TEXT,
        fiscal_year       INTEGER,
        purpose_name      TEXT,
        upper_name        TEXT,
        budget_type       TEXT,
        budget_type_code  TEXT,
        requested_amount  INTEGER,
        finalized_amount  INTEGER,
        PRIMARY KEY (id),
        FOREIGN KEY (project_id) REFERENCES projects(id)
    );

    CREATE TABLE payees (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id       TEXT,
        fiscal_year      INTEGER,
        payee_name       TEXT,
        corporate_number TEXT,
        amount           INTEGER,
        parent_payee_id  INTEGER,
        level            INTEGER DEFAULT 0,
        is_leaf          INTEGER DEFAULT 1,
        self_amount      INTEGER,
        FOREIGN KEY (project_id) REFERENCES projects(id),
        FOREIGN KEY (parent_payee_id) REFERENCES payees(id)
    );
    """)

    total = {"projects": 0, "items": 0, "payees": 0}
    seen_project_ids = set()  # 同一UUIDが複数年度クエリで重複しないように

    for org_id, org_label in SPACE_ORGS:
        print(f"\n=== {org_label} (org_id={org_id}) ===")

        for fy in FISCAL_YEARS:
            print(f"\n--- FY{fy} ---")
            projects_list = fetch_project_list(org_id, fy)
            print(f"  {len(projects_list)} projects found")

            for p_list in projects_list:
                pid = p_list["id"]
                name = p_list.get("name", "")

                # 重複スキップ（同じUUIDが複数年度クエリに出る場合）
                if pid in seen_project_ids:
                    print(f"  [skip dup] {name[:40]}")
                    continue
                seen_project_ids.add(pid)

                # 組織情報
                org = p_list.get("organization") or {}
                flatten = org.get("flatten") or {}
                org_name = org.get("name", "")
                org_path = " > ".join(flatten.get("names", [])) or org_name

                # payment_data（リストレスポンスに含まれる）
                payment_data = p_list.get("payment_data") or {}

                # 詳細取得
                time.sleep(0.4)
                detail = fetch_project_detail(pid)

                if detail is None:
                    print(f"  [WARN] detail fetch failed for {pid}")
                    initial = supplementary = carryover = budget_total = executed = None
                    items = []
                    ministry = p_list.get("ministry_name", "")
                    overview = ""
                    lineage = ""
                else:
                    initial, supplementary, carryover, budget_total, executed, items = extract_budget(detail)
                    ministry = detail.get("ministry_name", "")
                    overview = detail.get("overview", "") or ""
                    lineage = detail.get("lineage_id", "") or ""

                exec_rate = None
                if budget_total and executed:
                    exec_rate = round(executed / budget_total * 100, 2)

                # 予算が空の場合はリストの集計値で補完
                if not budget_total:
                    budget_total = (
                        (p_list.get("finalized_amount_for_initial_budget") or 0)
                        + (p_list.get("finalized_amount_for_supplementary_budget") or 0)
                        + (p_list.get("finalized_amount_for_carried_forward") or 0)
                    )
                    if not initial:
                        initial = p_list.get("finalized_amount_for_initial_budget") or 0
                    if not supplementary:
                        supplementary = p_list.get("finalized_amount_for_supplementary_budget") or 0
                    if not carryover:
                        carryover = p_list.get("finalized_amount_for_carried_forward") or 0

                if not executed:
                    executed = p_list.get("previous_year_execution_amount") or None

                if not exec_rate and budget_total and executed:
                    exec_rate = round(executed / budget_total * 100, 2)

                cur.execute("""
                    INSERT OR REPLACE INTO projects VALUES
                    (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (pid, fy, name, org_name, org_path,
                      ministry, initial, supplementary, carryover, budget_total,
                      executed, exec_rate, lineage, overview))
                total["projects"] += 1

                # 歳出目別明細
                for ei in items:
                    if not ei.get("expenditure_item_id"):
                        continue
                    cur.execute("""
                        INSERT OR IGNORE INTO expenditure_items VALUES
                        (?,?,?,?,?,?,?,?,?)
                    """, (ei["expenditure_item_id"], pid, fy,
                          ei["purpose_name"], ei["upper_name"],
                          ei["budget_type"], ei["budget_type_code"],
                          ei["requested_amount"], ei["finalized_amount"]))
                    total["items"] += 1

                # 支出先 (level=0 flat, parent_payee_id=NULL, is_leaf=1)
                if payment_data and payment_data.get("name"):
                    amt = payment_data.get("amount")
                    cur.execute("""
                        INSERT INTO payees
                          (project_id, fiscal_year, payee_name, corporate_number, amount,
                           parent_payee_id, level, is_leaf, self_amount)
                        VALUES (?,?,?,?,?,NULL,0,1,?)
                    """, (pid, fy,
                          payment_data.get("name"),
                          payment_data.get("corporate_number"),
                          amt, amt))
                    total["payees"] += 1

                payee_label = str(payment_data.get("name") or "N/A")[:20] if payment_data else "N/A"
                print(f"  [{fy}] {name[:45]!r}")
                print(f"         当初={yen(initial)} 補正={yen(supplementary)} 繰越={yen(carryover)}"
                      f" 計={yen(budget_total)} 執行={yen(executed)} 支出先={payee_label}")

    con.commit()
    con.close()

    print(f"\n=== DB構築完了 ===")
    print(f"  projects:          {total['projects']}")
    print(f"  expenditure_items: {total['items']}")
    print(f"  payees:            {total['payees']}")
    print(f"  DB path: {DB_PATH}")


def insert_payment_tree(cur, pid, fy, groups, edges):
    """
    payment-groups + payment-edges から多段ツリーを payees テーブルに挿入。
    既存のフラット payees レコードを削除してから挿入する。
    Returns: 挿入件数
    """
    if not groups:
        return 0

    cur.execute("DELETE FROM payees WHERE project_id=? AND fiscal_year=?", (pid, fy))

    gmap = {g["id"]: g for g in groups}

    # children_map[src_id] -> [target_id, ...]  (src_id=None → 省庁ルート)
    children_map = {}
    for e in edges:
        src = e.get("source_node_id")
        tgt = e.get("target_node_id")
        if tgt:
            children_map.setdefault(src, []).append(tgt)

    # 子を持つグループ = 中間ノード（is_leaf=0）
    groups_with_children = {src for src in children_map if src is not None}

    count = 0
    db_id_for_group = {}

    # BFS: (group_id, level, parent_db_id)
    queue = deque()
    for child_gid in children_map.get(None, []):
        queue.append((child_gid, 0, None))

    reached = set(children_map.get(None, []))

    while queue:
        gid, level, parent_db_id = queue.popleft()
        g = gmap.get(gid)
        if not g:
            continue

        is_leaf = 0 if gid in groups_with_children else 1
        # corporate_number は payments[0] から取得
        payments = g.get("payments") or []
        corp_num = payments[0].get("corporate_number") if payments else None

        cur.execute("""
            INSERT INTO payees
              (project_id, fiscal_year, payee_name, corporate_number, amount,
               parent_payee_id, level, is_leaf)
            VALUES (?,?,?,?,?,?,?,?)
        """, (pid, fy, g["name"], corp_num, g.get("total_amount"),
              parent_db_id, level, is_leaf))
        db_id = cur.lastrowid
        db_id_for_group[gid] = db_id
        count += 1

        for child_gid in children_map.get(gid, []):
            if child_gid not in reached:
                reached.add(child_gid)
                queue.append((child_gid, level + 1, db_id))

    # エッジから到達できないグループ（孤立）はフラットに追加
    for g in groups:
        if g["id"] not in reached:
            payments = g.get("payments") or []
            corp_num = payments[0].get("corporate_number") if payments else None
            cur.execute("""
                INSERT INTO payees
                  (project_id, fiscal_year, payee_name, corporate_number, amount,
                   parent_payee_id, level, is_leaf)
                VALUES (?,?,?,?,?,NULL,0,1)
            """, (pid, fy, g["name"], corp_num, g.get("total_amount")))
            count += 1

    return count


def enrich_payees_with_tree(con, cur):
    """
    全プロジェクトに対して payment-groups / payment-edges を取得し、
    payees テーブルを多段ツリーで再構築する。
    """
    pids = [r[0] for r in cur.execute("SELECT DISTINCT id FROM projects").fetchall()]
    print(f"\n=== 支出先ツリー取得 ({len(pids)} projects) ===")

    enriched = 0
    for pid in pids:
        r1 = api_get(f"/projects/{pid}/payment-groups/")
        r2 = api_get(f"/projects/{pid}/payment-edges/")
        time.sleep(0.3)

        if r1 is None or not isinstance(r1, list):
            continue

        groups = r1
        edges = r2 if isinstance(r2, list) else []

        if not groups:
            continue

        # fiscal_year を DB から取得
        fy = cur.execute("SELECT fiscal_year FROM projects WHERE id=?", (pid,)).fetchone()
        if not fy:
            continue
        fy = fy[0]

        n = insert_payment_tree(cur, pid, fy, groups, edges)
        if n > 0:
            name = cur.execute("SELECT name FROM projects WHERE id=?", (pid,)).fetchone()[0]
            print(f"  {name[:50]!r}: {n} payee nodes (edges={len(edges)})")
            enriched += 1

    con.commit()
    print(f"  enriched {enriched} projects")


def compute_self_amounts(con, cur):
    """
    各支出先の自己保有額（途絶えポイント）を計算。
    self_amount = amount - Σ(直接の子への支払い額)
    子を持たないノード（末端）は amount がそのまま self_amount。
    全ノードの self_amount の合計 = 最上位ノードの amount の合計 = 事業支出合計。
    """
    cur.execute("""
        UPDATE payees
        SET self_amount = MAX(0, COALESCE(amount, 0) - COALESCE(
            (SELECT SUM(COALESCE(c.amount, 0)) FROM payees c WHERE c.parent_payee_id = payees.id),
            0
        ))
    """)
    con.commit()
    row = cur.execute(
        "SELECT COUNT(*), SUM(self_amount) FROM payees WHERE self_amount > 0"
    ).fetchone()
    print(f"  self_amount computed: {row[0]} terminal nodes, total={row[1]/1e8:.1f}億円" if row[1] else "  self_amount computed (no data)")


if __name__ == "__main__":
    build_db()
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    enrich_payees_with_tree(con, cur)
    compute_self_amounts(con, cur)
    con.close()
