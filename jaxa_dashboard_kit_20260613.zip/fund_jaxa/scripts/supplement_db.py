"""
Supplemental DB updates:
1. Handle inline header+scale lines missed by main parser (theme17, theme2_11)
2. Insert 第三期 themes not on fund.jaxa.jp yet (from phase3 overview PDF)
"""
import io
import re
import sqlite3
import sys
import unicodedata
from pathlib import Path

from pdfminer.high_level import extract_text_to_fp
from pdfminer.layout import LAParams

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DATA_DIR = Path(__file__).parent.parent / "data"
PDF_DIR = DATA_DIR / "pdfs"
DB_PATH = DATA_DIR / "fund_jaxa.db"


def norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s)


def get_lines(path: Path) -> list[str]:
    buf = io.StringIO()
    with open(path, "rb") as f:
        extract_text_to_fp(f, buf,
                           laparams=LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5),
                           output_type="text", codec="utf-8")
    return [norm(ln) for ln in buf.getvalue().splitlines()]


RE_INLINE_SCALE = re.compile(r"【[^】]+】\s*(?:\d+[.．]\s*)?.+支援規模[：:]\s*(\d+(?:\.\d+)?)\s*億円")
RE_SCALE = re.compile(r"支援規模[：:]\s*(\d+(?:\.\d+)?)\s*億円")
RE_PER = re.compile(r"1件あたり支援総額[^:：\n]*[：:]\s*(\d+(?:\.\d+)?)\s*億円")
RE_CASES = re.compile(r"採択予定件数[^:：\n]*[：:]\s*(\d+)\s*件")
RE_AB = re.compile(r"\(?([A-Z])\)?\s*(\d+(?:\.\d+)?)\s*億円")


def upsert_theme(conn: sqlite3.Connection, theme_id: str, theme_name: str,
                 period: str, ministry: str, domain: str) -> None:
    exists = conn.execute("SELECT 1 FROM themes WHERE theme_id=?", (theme_id,)).fetchone()
    if exists:
        return
    conn.execute(
        "INSERT INTO themes(theme_id, theme_name, period, ministry, domain) VALUES(?,?,?,?,?)",
        (theme_id, theme_name, period, ministry, domain),
    )
    print(f"  INSERT theme: {theme_id} - {theme_name[:40]}")


def upsert_budget(conn: sqlite3.Connection, theme_id: str, sub: str,
                  total: float | None, per: float | None, cases: int | None) -> None:
    existing = conn.execute(
        "SELECT total_budget_oku, max_per_case_oku, expected_cases FROM theme_budgets "
        "WHERE theme_id=? AND sub_theme=?", (theme_id, sub)).fetchone()
    if existing is None:
        if total is None and per is None and cases is None:
            return
        conn.execute(
            "INSERT INTO theme_budgets(theme_id,sub_theme,total_budget_oku,max_per_case_oku,expected_cases,raw_text) "
            "VALUES(?,?,?,?,?,?)", (theme_id, sub, total, per, cases, ""))
        print(f"  INSERT budget: {theme_id}[{sub}] total={total} per={per} cases={cases}")
    else:
        ex_total, ex_per, ex_cases = existing
        new_total = ex_total if ex_total is not None else total
        new_per = ex_per if ex_per is not None else per
        new_cases = ex_cases if ex_cases is not None else cases
        if (new_total, new_per, new_cases) != (ex_total, ex_per, ex_cases):
            conn.execute(
                "UPDATE theme_budgets SET total_budget_oku=?,max_per_case_oku=?,expected_cases=? "
                "WHERE theme_id=? AND sub_theme=?", (new_total, new_per, new_cases, theme_id, sub))
            print(f"  UPDATE budget: {theme_id}[{sub}] total={new_total} per={new_per} cases={new_cases}")


def add_inline_scale_totals(conn: sqlite3.Connection) -> None:
    """Handle overview PDF lines where header+scale appear on same line."""
    print("\n=== Adding inline scale totals ===")
    # These are manually identified from debug_overview2.py:
    # PDF1 line 1497: theme17 total=155
    # PDF2 line 1567: theme2_11 total=165
    inline_cases = [
        ("theme17", "", 155.0),
        ("theme2_11", "", 165.0),
    ]
    for tid, sub, total in inline_cases:
        upsert_budget(conn, tid, sub, total, None, None)
    conn.commit()


# 第三期 themes not yet on fund.jaxa.jp (from phase3 overview PDF)
# Period: 第三期, assigned provisional IDs
PHASE3_THEMES = [
    # (id, name, period, ministry, domain, total, per, cases, subthemes)
    # 総務省
    ("theme3_2", "月・地球間通信インフラの実現に必要な地球局の開発・実証",
     "第三期", "総務省", "探査等", 50.0, 50.0, 1, {}),
    ("theme3_3", "衛星を取り巻くセキュリティ技術（電波の妨害・傍受対処技術）の開発・実証",
     "第三期", "総務省", "衛星等", 25.0, 25.0, 1, {}),
    ("theme3_4", "Q/V帯等通信機器の開発・実証",
     "第三期", "総務省", "衛星等", 93.0, 93.0, 1, {}),
    ("theme3_5", "次世代衛星通信を実現する革新的衛星搭載アンテナの開発・実証",
     "第三期", "総務省", "衛星等", 63.0, 63.0, 1, {}),
    # 文部科学省
    ("theme3_6", "打上げシステムへの洋上活用技術",
     "第三期", "文部科学省", "輸送", 90.0, 90.0, 1, {}),
    ("theme3_7", "宇宙輸送機の大気圏再突入における熱防護技術",
     "第三期", "文部科学省", "輸送", 95.0, 35.0, None, {}),
    ("theme3_9", "物理AI等による宇宙システムの革新技術",
     "第三期", "文部科学省", "軌道上サービス", 80.0, None, None, {}),
    ("theme3_10", "LEO利用促進技術",
     "第三期", "文部科学省", "地球低軌道・ISS等", 112.0, None, None, {}),
    ("theme3_11", "LEO拠点リブースト技術",
     "第三期", "文部科学省", "地球低軌道・ISS等", 60.0, 60.0, 1, {}),
    ("theme3_12", "月・小惑星等の宇宙資源活用に向けた技術",
     "第三期", "文部科学省", "探査等", 95.0, None, None, {}),
    ("theme3_13", "SX技術シーズ統合・人材育成拠点",
     "第三期", "文部科学省", "分野共通", 110.0, 22.0, 5, {}),
    ("theme3_14", "SX基盤領域発展研究",
     "第三期", "文部科学省", "分野共通", 100.0, 2.0, None, {}),
    # 経済産業省
    ("theme3_15", "民間ロケット打上げ実証加速化",
     "第三期", "経済産業省", "輸送", 240.0, 120.0, None, {}),
    ("theme3_16", "ロケット飛行運用の効率化・高機能化",
     "第三期", "経済産業省", "輸送", 50.0, None, None, {}),
    ("theme3_17", "宇宙交通管理を見据えた自律性確保に資する事業化加速",
     "第三期", "経済産業省", "衛星等", 150.0, None, None, {}),
    ("theme3_18", "デジタル技術を前提とした衛星開発・製造プロセスの刷新及び機能高度化の技術開発・実証",
     "第三期", "経済産業省", "衛星等", 230.0, None, None,
     {"A": (None, 100.0, None), "B": (None, 65.0, None)}),
]

# Also handle 2nd PDF unmatched: 衛星光通信の実装を見据えた衛星バス・光通信端末...
# This is theme2_3 with truncated name — already has data in DB, so skip.


def add_phase3_themes(conn: sqlite3.Connection) -> None:
    print("\n=== Adding 第三期 new themes ===")
    for row in PHASE3_THEMES:
        tid, name, period, ministry, domain, total, per, cases, subs = row
        upsert_theme(conn, tid, name, period, ministry, domain)
        upsert_budget(conn, tid, "", total, per, cases)
        for sub_label, (sub_total, sub_per, sub_cases) in subs.items():
            upsert_budget(conn, tid, sub_label, sub_total, sub_per, sub_cases)
    conn.commit()


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    add_inline_scale_totals(conn)
    add_phase3_themes(conn)

    # Final summary
    themes_cnt = conn.execute("SELECT COUNT(*) FROM themes").fetchone()[0]
    budgets_cnt = conn.execute("SELECT COUNT(*) FROM theme_budgets").fetchone()[0]
    print(f"\n=== Final counts ===")
    print(f"  themes: {themes_cnt}")
    print(f"  theme_budgets: {budgets_cnt}")

    # Show period/ministry breakdown
    rows = conn.execute(
        "SELECT period, ministry, COUNT(*) FROM themes GROUP BY period, ministry ORDER BY period, ministry"
    ).fetchall()
    print("\n  Theme count by period/ministry:")
    for r in rows:
        print(f"    {r[0]} | {r[1]} | {r[2]}")

    conn.close()


if __name__ == "__main__":
    main()
