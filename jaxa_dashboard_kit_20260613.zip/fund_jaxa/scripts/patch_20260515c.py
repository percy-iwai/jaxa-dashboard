"""
2026-05-15 DB patch (part C):
  ① research_tasks: rename period_start/period_end → start_date/end_date,
     then populate from koboyoryo "最長N年" duration + theme adoption fiscal year.
  ② organizations: add sub_theme column, populate from kekka PDF
     (technical-development-theme-name block carries （A）/（B）/（C） markers).

Data sources (all already cached locally):
  - fund_jaxa/data/pdfs/*kekka*.pdf     — adoption result PDFs (sub_theme per org)
  - fund_jaxa/data/pdfs/*koboyoryo*.pdf — call guidelines (最長N年 duration)
  - themes.adoption_date                — gives the support-start fiscal year

NOTE on ①: kekka PDFs contain NO explicit per-task implementation dates
(verified by scanning all 57 kekka PDFs). The only real period data available
is the theme-level maximum duration stated in each koboyoryo PDF ("最長N年").
period = [adoption fiscal year] .. [adoption FY + maxN - 1], stored as "YYYY年度".
This is the official planned period, applied per theme to its tasks.
"""
import io
import re
import sqlite3
import sys
import unicodedata
from collections import defaultdict
from pathlib import Path

from pdfminer.high_level import extract_text_to_fp
from pdfminer.layout import LAParams

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DATA_DIR = Path(__file__).parent.parent / "data"
PDF_DIR  = DATA_DIR / "pdfs"
DB_PATH  = DATA_DIR / "fund_jaxa.db"
LAPARAMS = LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5)


def norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s)


def org_key(name: str) -> str:
    """Match key: NFKC + remove all whitespace."""
    return re.sub(r"\s+", "", norm(name))


def dump_pdf(path: Path) -> str:
    buf = io.StringIO()
    with open(path, "rb") as f:
        extract_text_to_fp(f, buf, laparams=LAPARAMS, output_type="text", codec="utf-8")
    return buf.getvalue()


# ─── Schema migration ─────────────────────────────────────────────────────────

def migrate_schema(conn: sqlite3.Connection) -> None:
    print("=== Schema migration ===")
    cols = {r[1] for r in conn.execute("PRAGMA table_info(research_tasks)")}
    if "period_start" in cols and "start_date" not in cols:
        conn.execute("ALTER TABLE research_tasks RENAME COLUMN period_start TO start_date")
        print("  research_tasks: period_start → start_date")
    if "period_end" in cols and "end_date" not in cols:
        conn.execute("ALTER TABLE research_tasks RENAME COLUMN period_end TO end_date")
        print("  research_tasks: period_end → end_date")

    org_cols = {r[1] for r in conn.execute("PRAGMA table_info(organizations)")}
    if "sub_theme" not in org_cols:
        conn.execute("ALTER TABLE organizations ADD COLUMN sub_theme TEXT")
        print("  organizations: + sub_theme")
    conn.commit()


# ─── kekka PDF → (theme_id, sub_theme, org_name) records ─────────────────────

RE_THEME_LABEL = re.compile(r"技術開発テーマ名")
RE_ORG_LABEL   = re.compile(r"実施機関名")
RE_REP_LABEL   = re.compile(r"研究代表者名")
# sub_theme marker at the start of a line: (A) / A) / (A-1) / （B） …
RE_SUB = re.compile(r"^\(?([A-Z](?:-\d+)?)\)")


def kekka_to_theme(stem: str) -> tuple[str | None, str | None]:
    """
    Map a kekka PDF filename stem to (theme_id, sub_theme_prefix).
    sub_theme_prefix is normally None; for the theme21 追加公募 PDF it is '追加公募'.
    """
    # kekka21-2 → theme21, marker prefix 追加公募 (theme21-2 was merged into theme21)
    if stem in ("kekka21-2",):
        return "theme21", "追加公募"
    # sg_kekka16_1 / sg_kekka21_1 → theme16 / theme21
    m = re.match(r"sg_kekka([0-9]+)_\d+$", stem)
    if m:
        return "theme" + m.group(1), None
    # kekka2_sg_1 → theme2
    m = re.match(r"kekka([0-9]+)_sg_\d+$", stem)
    if m:
        return "theme" + m.group(1), None
    # kekka1_A / kekka1_B-1 / kekka6_B → theme1 / theme6  (sub_theme read from PDF body)
    m = re.match(r"kekka([0-9]+(?:_[0-9]+)?)(?:_[A-Z](?:-\d+)?)?$", stem)
    if m:
        return "theme" + m.group(1), None
    # kekka4-2 → theme4-2
    m = re.match(r"kekka([0-9]+-[0-9]+)$", stem)
    if m:
        return "theme" + m.group(1), None
    return None, None


def parse_kekka(text: str) -> list[tuple[str | None, str, str]]:
    """Return [(sub_theme, org_name, task_name), ...] from one kekka PDF."""
    lines = [norm(ln) for ln in text.splitlines()]
    n = len(lines)
    records: list[tuple[str | None, str, str]] = []

    theme_label_idx = [i for i, ln in enumerate(lines) if RE_THEME_LABEL.search(ln)]
    for ti in theme_label_idx:
        # find next 実施機関名
        oi = ti + 1
        while oi < n and not RE_ORG_LABEL.search(lines[oi]):
            oi += 1
        if oi >= n:
            continue

        # sub_theme: scan theme-name block (between theme label and org label)
        sub = None
        for k in range(ti + 1, oi):
            s = lines[k].strip()
            if not s:
                continue
            ms = RE_SUB.match(s)
            if ms:
                sub = ms.group(1)
                break

        # org name: same line after "(代表機関)" OR next non-empty line
        org = ""
        after = re.split(r"実施機関名\s*\(?[^)）]*[）)]?", lines[oi], maxsplit=1)
        if len(after) > 1 and after[1].strip():
            org = after[1].strip()
        else:
            k = oi + 1
            while k < n and not lines[k].strip():
                k += 1
            # guard: must not be the next section label
            if k < n and not RE_REP_LABEL.search(lines[k]) and "技術開発" not in lines[k]:
                org = lines[k].strip()

        # task name
        task = ""
        k = oi
        while k < n and "技術開発課題の名称" not in lines[k]:
            if RE_THEME_LABEL.search(lines[k]) and k > oi:
                break
            k += 1
        if k < n and "技術開発課題の名称" in lines[k]:
            k += 1
            buf = []
            while k < n and "技術開発課題の概要" not in lines[k] and not RE_THEME_LABEL.search(lines[k]):
                if lines[k].strip():
                    buf.append(lines[k].strip())
                k += 1
            task = "".join(buf)

        if org:
            records.append((sub, org, task))
    return records


def build_subtheme_map(conn: sqlite3.Connection) -> tuple[dict, dict, list]:
    """
    Parse all kekka PDFs.
    Returns:
      org_subs:  {(theme_id, org_key): set(sub_theme)}
      stats:     {pdf_stem: (theme_id, n_records, n_with_sub)}
      unmapped:  list of pdf stems with no theme mapping
    """
    org_subs: dict[tuple, set] = defaultdict(set)
    stats: dict[str, tuple] = {}
    unmapped: list[str] = []

    for path in sorted(PDF_DIR.glob("*kekka*.pdf")):
        stem = path.name.replace("fund_jaxa_jp_content_uploads_", "").replace("_pdf.pdf", "")
        tid, sub_prefix = kekka_to_theme(stem)
        if tid is None:
            unmapped.append(stem)
            continue
        recs = parse_kekka(dump_pdf(path))
        n_sub = 0
        for sub, org, _task in recs:
            if sub:
                n_sub += 1
                final_sub = (sub_prefix + sub) if sub_prefix else sub
                org_subs[(tid, org_key(org))].add(final_sub)
        stats[stem] = (tid, len(recs), n_sub)
    return org_subs, stats, unmapped


# kekka PDFs that print the bare theme name with NO （A）/（B） marker, yet whose
# 代表機関 map unambiguously to a sub_theme by task content vs theme_budgets.raw_text.
# Keyed by (theme_id, org_key(org_name)).
MANUAL_ORG_SUBTHEME = {
    # theme17: kekka17.pdf carries no （A）/（B） label.
    #   日本低軌道社中 → 物資補給システム技術 = A ; IHIエアロスペース → ドッキング検証 = B
    ("theme17", org_key("株式会社日本低軌道社中")): "A",
    ("theme17", org_key("株式会社IHIエアロスペース")): "B",
}


def fill_org_subtheme(conn: sqlite3.Connection) -> None:
    print("\n=== ② organizations.sub_theme ===")
    org_subs, stats, unmapped = build_subtheme_map(conn)

    print(f"  parsed {len(stats)} kekka PDFs"
          + (f", unmapped: {unmapped}" if unmapped else ""))

    rows = conn.execute("SELECT id, theme_id, org_name FROM organizations").fetchall()
    set_cnt = 0
    manual_cnt = 0
    no_match: list[tuple] = []
    for oid, tid, org_name in rows:
        subs = org_subs.get((tid, org_key(org_name)))
        manual = MANUAL_ORG_SUBTHEME.get((tid, org_key(org_name)))
        if subs:
            value = ",".join(sorted(subs))
            conn.execute("UPDATE organizations SET sub_theme=? WHERE id=?", (value, oid))
            set_cnt += 1
        elif manual:
            conn.execute("UPDATE organizations SET sub_theme=? WHERE id=?", (manual, oid))
            set_cnt += 1
            manual_cnt += 1
        else:
            no_match.append((tid, org_name))
    conn.commit()
    if manual_cnt:
        print(f"  ({manual_cnt} assigned via manual map — kekka PDF had no marker)")

    total = len(rows)
    print(f"  sub_theme set: {set_cnt}/{total}")
    print(f"  not determined: {len(no_match)}")

    # A theme is "multi-track" if at least one of its orgs got a sub_theme.
    # Within such a theme, remaining NULL orgs are 参画機関 (kekka lists 代表機関 only).
    # Themes with zero sub_themed orgs are single-track → NULL is correct.
    multi_track = {
        r[0] for r in conn.execute(
            "SELECT DISTINCT theme_id FROM organizations WHERE sub_theme IS NOT NULL"
        )
    }
    by_theme: dict[str, int] = defaultdict(int)
    for tid, _ in no_match:
        by_theme[tid] += 1
    flagged = {t: c for t, c in by_theme.items() if t in multi_track}
    single_track_nulls = sum(c for t, c in by_theme.items() if t not in multi_track)

    print(f"    - {single_track_nulls} orgs in single-track themes (NULL is correct)")
    if flagged:
        print(f"    - {sum(flagged.values())} orgs in multi-track themes are 参画機関 "
              f"(kekka PDF lists 代表機関 only):")
        for t, c in sorted(flagged.items()):
            print(f"        {t}: {c}")


# ─── koboyoryo durations → research_tasks period ─────────────────────────────

# "最長5年" / "最長5年間" — explicit max duration
DUR_RE = re.compile(r"最長\s*([0-9]+)\s*年(?:間)?")
# "最長 2028 年度末まで" — explicit end fiscal year (theme1, theme6)
END_FY_RE = re.compile(r"最長\s*(20[0-9]{2})\s*年度末まで")
# "支援開始後3年目を目途に" — base support period (theme2_5, theme2_18)
BASE_RE = re.compile(r"支援開始後\s*([0-9]+)\s*年目")


def koboyoryo_theme_id(stem: str) -> str | None:
    # koboyoryo_10 → theme10 ; koboyoryo_2_7 → theme2_7 ;
    # koboyoryo_1_A → theme1 ; koboyoryo_4-2 → theme4-2 ; koboyoryo_21-2 → theme21
    m = re.match(r"koboyoryo_(.+)", stem)
    if not m:
        return None
    core = m.group(1)
    if core == "21-2":
        return "theme21"
    if core == "rfp":
        return None
    # strip trailing _A / _B-1 sub-theme suffix
    core = re.sub(r"_[A-Z](?:-\d+)?$", "", core)
    return "theme" + core


def load_koboyoryo_periods() -> dict[str, tuple[int | None, int | None]]:
    """
    Return {theme_id: (max_duration_years, explicit_end_fiscal_year)}.
    Either component may be None. Sources, in priority order:
      1. "最長 YYYY 年度末まで"  → explicit_end_fy
      2. "最長 N 年(間)"         → duration N
      3. "支援開始後 N 年目"     → duration N (base support period fallback)
    """
    out: dict[str, tuple[int | None, int | None]] = {}
    for path in sorted(PDF_DIR.glob("*koboyoryo*.pdf")):
        stem = path.name.replace("fund_jaxa_jp_content_uploads_", "").replace("_pdf.pdf", "")
        tid = koboyoryo_theme_id(stem)
        if not tid:
            continue
        text = norm(dump_pdf(path))

        end_fys = [int(x) for x in END_FY_RE.findall(text) if 2024 <= int(x) <= 2040]
        durs = [int(x) for x in DUR_RE.findall(text) if 1 <= int(x) <= 10]
        if not durs:
            durs = [int(x) for x in BASE_RE.findall(text) if 1 <= int(x) <= 10]

        prev_dur, prev_end = out.get(tid, (None, None))
        new_dur = max([d for d in (durs + ([prev_dur] if prev_dur else []))], default=None)
        new_end = max([e for e in (end_fys + ([prev_end] if prev_end else []))], default=None)
        out[tid] = (new_dur, new_end)
    return out


def adoption_fiscal_year(adoption_date: str) -> int | None:
    """'2024-12-20' → 2024 ; '2025-02-28' → 2024 (JP fiscal year: Apr–Mar)."""
    m = re.match(r"(\d{4})-(\d{1,2})", adoption_date or "")
    if not m:
        return None
    year, month = int(m.group(1)), int(m.group(2))
    return year if month >= 4 else year - 1


def fill_task_periods(conn: sqlite3.Connection) -> None:
    print("\n=== ① research_tasks.start_date / end_date ===")
    periods = load_koboyoryo_periods()
    print(f"  koboyoryo periods loaded for {len(periods)} themes")

    themes = {
        r[0]: r[1]
        for r in conn.execute("SELECT theme_id, adoption_date FROM themes")
    }

    rows = conn.execute("SELECT id, theme_id FROM research_tasks").fetchall()
    set_cnt = 0
    skipped_no_period: set[str] = set()
    skipped_no_adopt: set[str] = set()

    for rid, tid in rows:
        dur, end_fy = periods.get(tid, (None, None))
        adopt = themes.get(tid)
        start_fy = adoption_fiscal_year(adopt) if adopt else None

        if start_fy is None:
            skipped_no_adopt.add(tid)
            continue
        if end_fy is None and dur is None:
            skipped_no_period.add(tid)
            continue

        final_end_fy = end_fy if end_fy is not None else start_fy + dur - 1
        conn.execute(
            "UPDATE research_tasks SET start_date=?, end_date=? WHERE id=?",
            (f"{start_fy}年度", f"{final_end_fy}年度", rid),
        )
        set_cnt += 1
    conn.commit()

    total = len(rows)
    print(f"  period set: {set_cnt}/{total}")
    if set_cnt < total:
        n_null = conn.execute(
            "SELECT COUNT(*) FROM research_tasks WHERE start_date IS NULL"
        ).fetchone()[0]
        print(f"  not set: {n_null} tasks")
        if skipped_no_period:
            print(f"    themes without parseable koboyoryo period: {sorted(skipped_no_period)}")
        if skipped_no_adopt:
            print(f"    themes without adoption_date: {sorted(skipped_no_adopt)}")


# ─── Report ───────────────────────────────────────────────────────────────────

def report(conn: sqlite3.Connection) -> None:
    print("\n=== Final state ===")
    rt_total = conn.execute("SELECT COUNT(*) FROM research_tasks").fetchone()[0]
    rt_dated = conn.execute(
        "SELECT COUNT(*) FROM research_tasks WHERE start_date IS NOT NULL"
    ).fetchone()[0]
    org_total = conn.execute("SELECT COUNT(*) FROM organizations").fetchone()[0]
    org_sub = conn.execute(
        "SELECT COUNT(*) FROM organizations WHERE sub_theme IS NOT NULL"
    ).fetchone()[0]
    print(f"  research_tasks: {rt_dated}/{rt_total} have start_date/end_date")
    print(f"  organizations:  {org_sub}/{org_total} have sub_theme")

    print("\n  Sample research_tasks periods:")
    for r in conn.execute(
        "SELECT theme_id, org_name, start_date, end_date FROM research_tasks "
        "WHERE start_date IS NOT NULL ORDER BY theme_id LIMIT 6"
    ).fetchall():
        print(f"    {r[0]:<10} {r[1][:24]:<24} {r[2]} 〜 {r[3]}")

    print("\n  Sample organizations sub_theme:")
    for r in conn.execute(
        "SELECT theme_id, org_name, sub_theme FROM organizations "
        "WHERE sub_theme IS NOT NULL ORDER BY theme_id LIMIT 10"
    ).fetchall():
        print(f"    {r[0]:<10} [{r[2]}] {r[1][:34]}")


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    migrate_schema(conn)
    fill_org_subtheme(conn)
    fill_task_periods(conn)
    report(conn)

    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
