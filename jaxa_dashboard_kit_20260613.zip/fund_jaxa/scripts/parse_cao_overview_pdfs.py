"""
Parse the 3 CAO overview PDFs and update theme_budgets in fund_jaxa.db.
All text is NFKC-normalized before regex matching to handle PDF variant chars.
"""
import io
import re
import sqlite3
import sys
import unicodedata
from pathlib import Path

from pdfminer.high_level import extract_text_to_fp
from pdfminer.layout import LAParams

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
PDF_DIR = DATA_DIR / "pdfs"
DB_PATH = DATA_DIR / "fund_jaxa.db"

OVERVIEW_PDFS = [
    PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_pdf.pdf",
    PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_2_pdf.pdf",
    PDF_DIR / "www8_cao_go_jp_space_kikin_phase3_r7hoseiyosan_pdf.pdf",
]

# --- Regex (applied to NFKC-normalized text) ---
RE_HEADER = re.compile(r"【[^】]+】\s*(?:\d+[.．]\s*)?(.+)")
# Support both "支援規模:X億円" and "支援規模:X億円程度"
RE_SCALE = re.compile(r"支援規模[：:]\s*(\d+(?:\.\d+)?)\s*億円")
# "A)X億円、B)Y億円" in the per-case line
RE_AB = re.compile(r"\(?([A-Z])\)?\s*(\d+(?:\.\d+)?)\s*億円")
# "1件あたり支援総額 : X億円(上限)" — also handles (A)X億 inline
RE_PER = re.compile(r"1件あたり支援総額[^:：]*[：:]\s*(\d+(?:\.\d+)?)\s*億円")
RE_PER_AB = re.compile(r"1件あたり支援総額[^:：]*[：:]\s*(.*?)(?:上限|$)", re.DOTALL)
RE_CASES = re.compile(r"採択予定件数[^:：]*[：:]\s*(\d+)\s*件")
RE_AMOUNT = re.compile(r"(\d+(?:\.\d+)?)\s*億円")


def _norm(s: str) -> str:
    """NFKC normalize and remove variation selectors."""
    return unicodedata.normalize("NFKC", s)


def _fuzzy(s: str) -> str:
    """Further normalize for DB matching: remove spaces/parens/periods."""
    s = _norm(s).lower()
    for ch in " 　\t・･（）()「」『』【】。、，,．.":
        s = s.replace(ch, "")
    return s


def extract_lines(path: Path) -> list[str]:
    buf = io.StringIO()
    with open(path, "rb") as f:
        extract_text_to_fp(
            f, buf,
            laparams=LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5),
            output_type="text", codec="utf-8",
        )
    return [_norm(ln) for ln in buf.getvalue().splitlines()]


def load_themes(conn: sqlite3.Connection) -> dict[str, str]:
    """Return {fuzzy_name: theme_id}."""
    rows = conn.execute("SELECT theme_id, theme_name FROM themes").fetchall()
    return {_fuzzy(name): tid for tid, name in rows if name}


def find_theme_id(raw_name: str, theme_map: dict[str, str]) -> str | None:
    """Match raw theme name string to a theme_id."""
    key = _fuzzy(raw_name)

    # Strip trailing ministry "(省庁名)" before matching
    key_stripped = re.sub(r"\(?[総文経内]\w+省?\)?\s*$", "", key).rstrip()
    if not key_stripped:
        key_stripped = key

    if key_stripped in theme_map:
        return theme_map[key_stripped]
    if key in theme_map:
        return theme_map[key]

    # Substring: longest matching key that is a substring of each other
    best = None
    best_len = 0
    for k, tid in theme_map.items():
        if len(k) < 6:
            continue
        if k in key_stripped or key_stripped in k:
            if len(k) > best_len:
                best_len = len(k)
                best = tid
    return best


def upsert_budget(conn: sqlite3.Connection, theme_id: str, sub_theme: str,
                  total: float | None, per: float | None, cases: int | None) -> str:
    """Insert or selectively fill NULL columns. Returns 'new'/'updated'/'same'."""
    existing = conn.execute(
        "SELECT rowid, total_budget_oku, max_per_case_oku, expected_cases "
        "FROM theme_budgets WHERE theme_id=? AND sub_theme=?",
        (theme_id, sub_theme),
    ).fetchone()

    if existing is None:
        if total is None and per is None and cases is None:
            return "skip"
        conn.execute(
            "INSERT INTO theme_budgets(theme_id, sub_theme, total_budget_oku, "
            "max_per_case_oku, expected_cases, raw_text) VALUES(?,?,?,?,?,?)",
            (theme_id, sub_theme, total, per, cases, ""),
        )
        return "new"

    _rowid, ex_total, ex_per, ex_cases = existing
    new_total = ex_total if ex_total is not None else total
    new_per = ex_per if ex_per is not None else per
    new_cases = ex_cases if ex_cases is not None else cases

    if (new_total, new_per, new_cases) == (ex_total, ex_per, ex_cases):
        return "same"

    conn.execute(
        "UPDATE theme_budgets SET total_budget_oku=?, max_per_case_oku=?, "
        "expected_cases=? WHERE theme_id=? AND sub_theme=?",
        (new_total, new_per, new_cases, theme_id, sub_theme),
    )
    return "updated"


def parse_section(lines: list[str], start: int, end: int) -> dict[str, dict]:
    """
    Parse budget from lines[start:end].
    Returns {sub_theme: {total, per, cases}}.
    """
    text = "\n".join(lines[start:end])
    results: dict[str, dict] = {}

    # Total budget from "支援規模:" line
    scale_m = RE_SCALE.search(text)
    total = float(scale_m.group(1)) if scale_m else None

    # Cases
    cases_m = RE_CASES.search(text)
    cases = int(cases_m.group(1)) if cases_m else None

    # Per-case budget — always join 6 lines from the keyword to capture split-line formats
    per_line = ""
    for i, ln in enumerate(lines[start:end]):
        if "1件あたり支援総額" in ln or "1件当たり支援総額" in ln:
            per_line = " ".join(lines[start + i: start + i + 6])
            break

    # Check for A/B subthemes in the per-case line
    ab_matches = RE_AB.findall(per_line)
    if ab_matches and len(ab_matches) >= 2:
        for label, amount in ab_matches:
            results[label] = {"total": None, "per": float(amount), "cases": None}
        # Also record total-level row
        results[""] = {"total": total, "per": None, "cases": cases}
    else:
        # Single per-case
        per_m = RE_PER.search(per_line)
        per = float(per_m.group(1)) if per_m else None

        # If no per-line was found, per stays None
        if not per_line:
            per = None

        results[""] = {"total": total, "per": per, "cases": cases}

    return results


def parse_overview_pdf(path: Path, theme_map: dict[str, str],
                       conn: sqlite3.Connection) -> list[str]:
    """Parse one overview PDF. Returns log messages."""
    print(f"\n=== {path.name} ===")
    lines = extract_lines(path)
    print(f"  Lines: {len(lines)}")

    # Find section boundaries: lines with 【...】 that look like theme headers
    section_starts: list[tuple[int, str]] = []
    for i, ln in enumerate(lines):
        if "【" not in ln:
            continue
        m = RE_HEADER.match(ln.strip())
        if not m:
            continue
        raw_name = m.group(1).strip()
        # Skip short or clearly non-theme lines
        if len(raw_name) < 8 or "億円" in raw_name:
            continue
        # Skip lines that are just category TOC entries at start of doc
        if i < 50:
            continue
        section_starts.append((i, raw_name))

    print(f"  Theme sections found: {len(section_starts)}")

    log: list[str] = []
    for idx, (sec_start, raw_name) in enumerate(section_starts):
        sec_end = section_starts[idx + 1][0] if idx + 1 < len(section_starts) else len(lines)
        sec_end = min(sec_end, sec_start + 100)

        text_block = "\n".join(lines[sec_start:sec_end])
        has_budget = "支援規模" in text_block or "1件あたり支援総額" in text_block or "1件当たり支援総額" in text_block
        if not has_budget:
            continue

        tid = find_theme_id(raw_name, theme_map)
        if tid is None:
            log.append(f"  UNMATCHED: {raw_name[:60]}")
            continue

        budget = parse_section(lines, sec_start, sec_end)
        for sub, vals in budget.items():
            status = upsert_budget(conn, tid, sub, vals["total"], vals["per"], vals["cases"])
            if status != "same" and status != "skip":
                log.append(f"  {status.upper():7s}: {tid}[{sub!r:3s}] "
                            f"total={vals['total']} per={vals['per']} cases={vals['cases']} "
                            f"<- {raw_name[:45]}")

    conn.commit()
    return log


def main():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    theme_map = load_themes(conn)
    print(f"Loaded {len(theme_map)} themes")

    all_log: list[str] = []
    for pdf_path in OVERVIEW_PDFS:
        if not pdf_path.exists():
            print(f"MISSING: {pdf_path}")
            continue
        log = parse_overview_pdf(pdf_path, theme_map, conn)
        all_log.extend(log)

    print("\n=== Changes ===")
    for entry in all_log:
        print(entry)

    print("\n=== Final budget record count ===")
    count = conn.execute("SELECT COUNT(*) FROM theme_budgets").fetchone()[0]
    print(f"  Total: {count}")

    missing = conn.execute(
        "SELECT theme_id, sub_theme FROM theme_budgets "
        "WHERE total_budget_oku IS NULL ORDER BY theme_id, sub_theme"
    ).fetchall()
    print(f"  Missing total_budget_oku: {len(missing)}")
    for tid, sub in missing:
        print(f"    {tid}[{sub}]")

    conn.close()


if __name__ == "__main__":
    main()
