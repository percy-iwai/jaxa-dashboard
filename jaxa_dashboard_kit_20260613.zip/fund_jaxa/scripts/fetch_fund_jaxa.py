#!/usr/bin/env python3
"""
JAXA宇宙戦略基金 公募テーマ・採択結果 収集スクリプト
https://fund.jaxa.jp

Usage:
    python fund_jaxa/scripts/fetch_fund_jaxa.py [--force-download]

出力:
    fund_jaxa/data/fund_jaxa.db
    fund_jaxa/data/cache/     (HTMLキャッシュ)
    fund_jaxa/data/pdfs/      (PDFキャッシュ)
"""
import argparse
import io
import logging
import random
import re
import sqlite3
import sys
import time
import unicodedata
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from pdfminer.high_level import extract_pages, extract_text_to_fp
from pdfminer.layout import LAParams, LTTextContainer

# Windows cp932コンソールでも日本語出力できるように UTF-8 に強制
if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "buffer"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# ── パス定義 ──────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent
DATA_DIR   = SCRIPT_DIR.parent / "data"
CACHE_DIR  = DATA_DIR / "cache"
PDF_DIR    = DATA_DIR / "pdfs"
DB_PATH    = DATA_DIR / "fund_jaxa.db"

# ── URL 定数 ──────────────────────────────────────────────────────────────────
BASE_URL       = "https://fund.jaxa.jp"
TECHLIST_URL   = "https://fund.jaxa.jp/techlist/"
TECHRESULT01   = "https://fund.jaxa.jp/techlist/techresult-01/"
PDF_BASE_URL   = "https://fund.jaxa.jp/content/uploads/"

SLEEP_MIN, SLEEP_MAX = 1.0, 2.0

# 省庁コード → 省庁名
MINISTRY_CODE_MAP: Dict[str, str] = {
    "総": "総務省",
    "文": "文部科学省",
    "経": "経済産業省",
    "内": "内閣府",
    "国": "国土交通省",
}

# 期別の省庁情報PDF
MINISTRY_PDF_URLS: Dict[str, str] = {
    "第三期": "https://fund.jaxa.jp/content/uploads/yokoku20260313.pdf",
    "第二期": "https://fund.jaxa.jp/content/uploads/koboyotei20250418.pdf",
}

# 第一期 PRシートPDF
PR_SHEET_URL = "https://fund.jaxa.jp/content/uploads/20251020_1st_term_PR_sheets.pdf"

# 内閣府 実施方針PDF (filename, period, ministry)
CAO_BASE = "https://www8.cao.go.jp/space/kikin/"
CAO_JISSIHOUSIN_PDFS = [
    ("jissihousin_monka.pdf",            "第一期", "文部科学省"),
    ("jissihousin_keisan.pdf",           "第一期", "経済産業省"),
    ("jissihousin_soumu_r1.pdf",         "第一期", "総務省"),
    ("jissihousin_monka_2.pdf",          "第二期", "文部科学省"),
    ("jissihousin_keisan_2.pdf",         "第二期", "経済産業省"),
    ("jissihousin_soumu_r1_2.pdf",       "第二期", "総務省"),
    ("jissihousin_monka_20260225.pdf",   "第三期", "文部科学省"),
    ("jissihousin_keisan_20260225.pdf",  "第三期", "経済産業省"),
    ("jissihousin_soumu_20260225.pdf",   "第三期", "総務省"),
]

# 実施方針PDFで確定している省庁マッピング（不明テーマ補完用）
KNOWN_MINISTRY_FIXES: Dict[str, str] = {
    "theme3":   "文部科学省",   # 再生型燃料電池システム
    "theme4-2": "総務省",       # （再公募）月面水資源探査
    "theme5":   "総務省",       # 月-地球間通信システム開発・実証（FS）
    "theme19":  "経済産業省",   # 衛星データ利用システム海外実証（FS）
    "theme21":  "経済産業省",   # 衛星サプライチェーン構築
    "theme2_18": "文部科学省",  # SX中核領域発展研究「SX-ARK」
    "theme2_21": "経済産業省",  # 射場における高頻度打上げに資する汎用設備のあり方FS
}

PERIODS = ["第一期", "第二期", "第三期", "第四期"]
DOMAINS = ["宇宙輸送", "衛星等", "探査等", "分野共通"]

MINISTRY_KEYWORDS = ["文部科学省", "経済産業省", "総務省", "内閣府",
                     "国土交通省", "農林水産省", "厚生労働省", "防衛省"]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "ja,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

logger = logging.getLogger(__name__)

# ── セッション ────────────────────────────────────────────────────────────────
_session: Optional[requests.Session] = None


def get_session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
    return _session


# ── ディレクトリ・DB初期化 ────────────────────────────────────────────────────
def setup_dirs() -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS themes (
            theme_id      TEXT PRIMARY KEY,
            theme_name    TEXT,
            period        TEXT,
            domain        TEXT,
            ministry      TEXT,
            adoption_date TEXT,
            detail_url    TEXT
        );

        CREATE TABLE IF NOT EXISTS organizations (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            theme_id  TEXT,
            org_name  TEXT,
            is_lead   INTEGER,
            org_type  TEXT,
            UNIQUE(theme_id, org_name)
        );

        CREATE TABLE IF NOT EXISTS theme_budgets (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            theme_id          TEXT,
            sub_theme         TEXT,
            total_budget_oku  REAL,
            max_per_case_oku  REAL,
            expected_cases    INTEGER,
            raw_text          TEXT,
            UNIQUE(theme_id, sub_theme)
        );

        CREATE TABLE IF NOT EXISTS research_tasks (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            theme_id       TEXT,
            org_name       TEXT,
            task_name      TEXT,
            task_overview  TEXT,
            committee_type TEXT,
            subsidy_rate   TEXT,
            start_date     TEXT,
            end_date       TEXT,
            UNIQUE(theme_id, org_name, task_name)
        );
    """)
    conn.commit()

    # 既存DBへの新カラム追加（マイグレーション）
    for col_def in [
        "ALTER TABLE themes ADD COLUMN pr_sheet_url TEXT",
        "ALTER TABLE themes ADD COLUMN pr_sheet_page INTEGER",
    ]:
        try:
            conn.execute(col_def)
            conn.commit()
        except sqlite3.OperationalError:
            pass


# ── キャッシュ・HTTP ──────────────────────────────────────────────────────────
def _url_to_cache_path(url: str, ext: str = ".html") -> Path:
    parsed = urlparse(url)
    safe = (parsed.netloc + parsed.path).replace("/", "_").replace(".", "_")
    safe = re.sub(r"[^\w\-]", "_", safe)[:180]
    base = PDF_DIR if ext == ".pdf" else CACHE_DIR
    return base / (safe + ext)


def fetch_html(url: str, force: bool = False) -> Optional[str]:
    cache_path = _url_to_cache_path(url, ".html")
    if cache_path.exists() and not force:
        return cache_path.read_text(encoding="utf-8")
    try:
        resp = get_session().get(url, timeout=30)
        resp.raise_for_status()
        content = resp.content
        for enc in [resp.apparent_encoding, "utf-8", "shift-jis"]:
            try:
                html = content.decode(enc or "utf-8")
                break
            except (UnicodeDecodeError, LookupError):
                continue
        else:
            html = content.decode("utf-8", errors="replace")
        cache_path.write_text(html, encoding="utf-8")
        time.sleep(random.uniform(SLEEP_MIN, SLEEP_MAX))
        return html
    except Exception as e:
        logger.warning("HTML取得失敗: %s — %s", url, e)
        return None


def fetch_pdf(url: str, force: bool = False) -> Optional[bytes]:
    cache_path = _url_to_cache_path(url, ".pdf")
    if cache_path.exists() and not force:
        return cache_path.read_bytes()
    try:
        resp = get_session().get(url, timeout=60)
        if resp.status_code == 404:
            logger.debug("PDF 404: %s", url)
            return None
        resp.raise_for_status()
        data = resp.content
        cache_path.write_bytes(data)
        time.sleep(random.uniform(SLEEP_MIN, SLEEP_MAX))
        return data
    except Exception as e:
        logger.warning("PDF取得失敗: %s — %s", url, e)
        return None


# ── PDFテキスト抽出 ───────────────────────────────────────────────────────────
def extract_pdf_text(pdf_bytes: bytes) -> str:
    try:
        output = io.StringIO()
        laparams = LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5)
        extract_text_to_fp(
            io.BytesIO(pdf_bytes), output,
            laparams=laparams, output_type="text", codec="utf-8"
        )
        return output.getvalue()
    except Exception as e:
        logger.warning("PDFテキスト抽出失敗: %s", e)
        return ""


# ── ユーティリティ ────────────────────────────────────────────────────────────
def _extract_theme_id(href: str) -> str:
    m = re.search(r"/techlist/([^/]+)/?$", href)
    return m.group(1) if m else href.strip("/").split("/")[-1]


def _parse_date_dotted(text: str) -> Optional[str]:
    """'2026.03.23' → '2026-03-23'"""
    m = re.match(r"(\d{4})\.(\d{1,2})\.(\d{1,2})", text.strip())
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return None


def _parse_japanese_date(text: str) -> Optional[str]:
    m = re.search(r"令和\s*(\d+)\s*年\s*(\d+)\s*月(?:\s*(\d+)\s*日)?", text)
    if m:
        year = 2018 + int(m.group(1))
        month = int(m.group(2))
        day = m.group(3)
        if day:
            return f"{year}-{month:02d}-{int(day):02d}"
        return f"{year}-{month:02d}"
    # YYYY年MM月DD日
    m2 = re.search(r"(\d{4})\s*年\s*(\d{1,2})\s*月(?:\s*(\d{1,2})\s*日)?", text)
    if m2:
        day = m2.group(3)
        if day:
            return f"{m2.group(1)}-{int(m2.group(2)):02d}-{int(day):02d}"
        return f"{m2.group(1)}-{int(m2.group(2)):02d}"
    m3 = re.search(r"(\d{4})[-/](\d{1,2})", text)
    if m3:
        return f"{m3.group(1)}-{int(m3.group(2)):02d}"
    return None


def _classify_org(name: str) -> str:
    if any(k in name for k in ["大学", "大学院", "University"]):
        return "大学"
    if any(k in name for k in ["研究所", "研究院", "研究機構", "研究センター",
                                 "JAXA", "NICT", "NEDO", "産総研", "理化学",
                                 "国立研究開発法人", "宇宙航空研究"]):
        return "研究機関"
    if any(k in name for k in ["株式会社", "有限会社", "合同会社", "㈱",
                                 "Inc.", "Corp.", "Ltd.", "LLC"]):
        return "民間企業"
    return "その他"


def _split_orgs_smart(text: str) -> List[str]:
    """複数機関が連結されているテキストを個々に分割"""
    if not text.strip():
        return []
    # まず明示的な区切り文字で分割
    parts = re.split(r"[、・／\n　]+", text)
    result = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        # 連結した法人名を境界で分割
        # 境界: 機関名種別キーワードの前
        boundary = (
            r"(?<!\A)(?<!\s)"
            r"(?=(?:株式会社|有限会社|合同会社|国立大学法人|公立大学法人"
            r"|学校法人|国立研究開発法人|公益財団法人|一般社団法人"
            r"|一般財団法人|地方独立行政法人|独立行政法人"
            r"|国立天文台|JAXA|NICT|NEDO))"
        )
        sub = re.split(boundary, part)
        result.extend([s.strip() for s in sub if s.strip()])
    return result


def _pdf_filename_stem(theme_id: str) -> str:
    m = re.match(r"^theme(.+)$", theme_id)
    return m.group(1) if m else theme_id


def _koboyoryo_urls(theme_id: str) -> List[str]:
    stem = _pdf_filename_stem(theme_id)
    return [
        f"{PDF_BASE_URL}koboyoryo_{stem}.pdf",
        f"{PDF_BASE_URL}koboyoryo_{stem.replace('_', '-')}.pdf",
        f"{PDF_BASE_URL}koboyoryo{stem}.pdf",
    ]


def _kekka_urls(theme_id: str) -> List[str]:
    stem = _pdf_filename_stem(theme_id)
    return [
        f"{PDF_BASE_URL}kekka{stem}.pdf",
        f"{PDF_BASE_URL}kekka_{stem}.pdf",
        f"{PDF_BASE_URL}kekka{stem.replace('_', '-')}.pdf",
    ]


def _extract_pdf_links_from_detail(soup: BeautifulSoup) -> Dict[str, str]:
    """詳細ページからPDFリンクを抽出"""
    result: Dict[str, str] = {}
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not href.lower().endswith(".pdf"):
            continue
        href_full = urljoin(BASE_URL, href)
        link_text = a.get_text(strip=True)
        basename = href.split("/")[-1].lower()
        if "公募要領" in link_text or "koboyoryo" in basename:
            result.setdefault("koboyoryo_pdf", href_full)
        elif "kekka" in basename or "採択結果" in link_text:
            result.setdefault("kekka_pdf", href_full)
    return result


def _extract_ministry_from_text(text: str) -> Optional[str]:
    """テキスト中から省庁名を抽出"""
    for kw in MINISTRY_KEYWORDS:
        if kw in text:
            return kw
    return None


# ── DB UPSERT ─────────────────────────────────────────────────────────────────
def upsert_theme(
    conn: sqlite3.Connection,
    theme_id: str,
    theme_name: Optional[str],
    period: Optional[str],
    domain: Optional[str],
    detail_url: Optional[str],
    ministry: Optional[str] = None,
    adoption_date: Optional[str] = None,
) -> None:
    conn.execute("""
        INSERT INTO themes (theme_id, theme_name, period, domain, detail_url,
                            ministry, adoption_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(theme_id) DO UPDATE SET
            theme_name    = COALESCE(excluded.theme_name,    themes.theme_name),
            period        = COALESCE(excluded.period,        themes.period),
            domain        = COALESCE(excluded.domain,        themes.domain),
            detail_url    = COALESCE(excluded.detail_url,    themes.detail_url),
            ministry      = COALESCE(excluded.ministry,      themes.ministry),
            adoption_date = COALESCE(excluded.adoption_date, themes.adoption_date)
    """, (theme_id, theme_name, period, domain, detail_url, ministry, adoption_date))


def upsert_org(
    conn: sqlite3.Connection,
    theme_id: str,
    org_name: str,
    is_lead: Optional[int],
    org_type: Optional[str],
) -> None:
    org_name = org_name.strip()
    if not org_name or len(org_name) < 2:
        return
    conn.execute("""
        INSERT INTO organizations (theme_id, org_name, is_lead, org_type)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(theme_id, org_name) DO UPDATE SET
            is_lead  = COALESCE(excluded.is_lead,  organizations.is_lead),
            org_type = COALESCE(excluded.org_type, organizations.org_type)
    """, (theme_id, org_name, is_lead, org_type))


def upsert_budget(
    conn: sqlite3.Connection,
    theme_id: str,
    sub_theme: str,
    total_budget_oku: Optional[float],
    max_per_case_oku: Optional[float],
    expected_cases: Optional[int],
    raw_text: str,
) -> None:
    conn.execute("""
        INSERT INTO theme_budgets
            (theme_id, sub_theme, total_budget_oku, max_per_case_oku, expected_cases, raw_text)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(theme_id, sub_theme) DO UPDATE SET
            total_budget_oku = COALESCE(excluded.total_budget_oku, theme_budgets.total_budget_oku),
            max_per_case_oku = COALESCE(excluded.max_per_case_oku, theme_budgets.max_per_case_oku),
            expected_cases   = COALESCE(excluded.expected_cases,   theme_budgets.expected_cases),
            raw_text         = excluded.raw_text
    """, (theme_id, sub_theme, total_budget_oku, max_per_case_oku, expected_cases, raw_text))


def upsert_research_task(
    conn: sqlite3.Connection,
    theme_id: str,
    org_name: str,
    task_name: str,
    task_overview: Optional[str],
    committee_type: Optional[str],
    subsidy_rate: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
) -> None:
    org_name  = (org_name or "").strip()
    task_name = (task_name or "").strip()
    if not org_name or not task_name:
        return
    conn.execute("""
        INSERT INTO research_tasks
            (theme_id, org_name, task_name, task_overview,
             committee_type, subsidy_rate, start_date, end_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(theme_id, org_name, task_name) DO NOTHING
    """, (theme_id, org_name, task_name, task_overview,
          committee_type, subsidy_rate, start_date, end_date))


# ── テーマ一覧スクレイピング ──────────────────────────────────────────────────
def fetch_techlist(conn: sqlite3.Connection, force: bool = False) -> List[str]:
    """
    techlist/ の li.p-theme_item を走査してテーマ登録。
    - h2.l-section_heading から period/domain を取得
    - p.p-theme_item_title からテーマ名
    - a.p-theme_item_detail から detail_url
    - p.p-theme_item_result > a.p-theme_item_link から kekka URL・採択日
    """
    html = fetch_html(TECHLIST_URL, force)
    if not html:
        logger.error("テックリスト取得失敗")
        return []

    soup = BeautifulSoup(html, "lxml")
    theme_ids: List[str] = []
    seen: set = set()

    for section in soup.find_all("section", class_="l-section"):
        h2 = section.find("h2", class_="l-section_heading")
        if not h2:
            continue
        h2_text = h2.get_text(strip=True)

        current_period: Optional[str] = None
        for p in PERIODS:
            if p in h2_text:
                current_period = p
                break

        current_domain: Optional[str] = None
        for d in DOMAINS:
            if d in h2_text:
                current_domain = d
                break

        for li in section.find_all("li", class_="p-theme_item"):
            # プレースホルダーはスキップ
            if li.get("data-status") == "データ無し":
                continue

            title_p = li.find("p", class_="p-theme_item_title")
            if not title_p:
                continue
            theme_name = title_p.get_text(strip=True)
            # 「コンテンツの準備が整い次第」はスキップ
            if "コンテンツの準備" in theme_name:
                continue

            detail_a = li.find("a", class_="p-theme_item_detail")
            if not detail_a:
                continue
            href = detail_a.get("href", "")
            full_url = urljoin(BASE_URL, href)
            if full_url in seen:
                continue
            seen.add(full_url)

            theme_id = _extract_theme_id(href)

            # 採択結果列: kekka PDF URL と採択日
            kekka_url: Optional[str] = None
            adoption_date: Optional[str] = None
            result_p = li.find("p", class_="p-theme_item_result")
            if result_p:
                result_a = result_p.find("a", class_="p-theme_item_link")
                if result_a:
                    kekka_href = result_a.get("href", "")
                    if kekka_href:
                        kekka_url = urljoin(BASE_URL, kekka_href)
                    date_text = result_a.get_text(strip=True)
                    adoption_date = _parse_date_dotted(date_text) or _parse_japanese_date(date_text)

            upsert_theme(conn, theme_id, theme_name, current_period,
                         current_domain, full_url, adoption_date=adoption_date)

            # kekka URL をセッション内 dict に保存（main() で利用）
            if kekka_url:
                _KEKKA_URLS_FROM_TECHLIST[theme_id] = kekka_url

            theme_ids.append(theme_id)
            logger.info("テーマ登録: %s [%s / %s] %s",
                        theme_id, current_period, current_domain,
                        "※採択済" if adoption_date else "")

    conn.commit()
    return theme_ids


# セッション内 kekka URL キャッシュ
_KEKKA_URLS_FROM_TECHLIST: Dict[str, str] = {}


# ── 第一期採択結果ページ ──────────────────────────────────────────────────────
def _norm(s: str) -> str:
    """NFKC正規化 + 空白除去（KANGXI RADICALや全角文字を標準化）"""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s))


def _match_theme_by_name(conn: sqlite3.Connection, text: str) -> Optional[str]:
    """テーマ名のテキスト照合で theme_id を返す"""
    rows = conn.execute("SELECT theme_id, theme_name FROM themes").fetchall()
    text_norm = _norm(text)
    best_id: Optional[str] = None
    best_score = 0
    for row in rows:
        if not row["theme_name"]:
            continue
        name_norm = _norm(row["theme_name"])
        if len(name_norm) < 5:
            continue
        # 双方向包含チェック（最低10文字一致）
        if name_norm[:20] in text_norm or text_norm[:30] in name_norm:
            score = len(name_norm)
            if score > best_score:
                best_score = score
                best_id = row["theme_id"]
    return best_id


def fetch_techresult01(conn: sqlite3.Connection, force: bool = False) -> None:
    """
    第一期採択結果ページから実施機関・担当省を補完。
    テーブル構成: 技術開発テーマ名・概要 | 担当省 | 実施機関名
    """
    html = fetch_html(TECHRESULT01, force)
    if not html:
        logger.warning("第一期結果ページ取得失敗")
        return

    soup = BeautifulSoup(html, "lxml")
    org_count = 0
    ministry_count = 0

    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        for tr in rows:
            tds = tr.find_all("td")
            if len(tds) < 2:
                continue

            theme_cell = tds[0].get_text("\n", strip=True)
            ministry   = tds[1].get_text(strip=True) if len(tds) > 1 else None
            orgs_text  = tds[2].get_text("\n", strip=True) if len(tds) > 2 else ""

            theme_id = _match_theme_by_name(conn, theme_cell)

            if theme_id and ministry and ministry in MINISTRY_KEYWORDS:
                conn.execute(
                    "UPDATE themes SET ministry=? WHERE theme_id=? AND ministry IS NULL",
                    (ministry, theme_id)
                )
                ministry_count += 1

            if theme_id and orgs_text:
                for org in _split_orgs_smart(orgs_text):
                    upsert_org(conn, theme_id, org, is_lead=None,
                               org_type=_classify_org(org))
                    org_count += 1

    conn.commit()
    logger.info("第一期: 省庁 %d件、実施機関 %d件更新", ministry_count, org_count)


# ── 個別テーマ詳細ページ ──────────────────────────────────────────────────────
def fetch_theme_detail(
    conn: sqlite3.Connection,
    theme_id: str,
    detail_url: str,
    force: bool = False,
) -> Dict[str, Optional[str]]:
    """
    詳細ページから:
    - h1.c-pageTitle → theme_name 補完
    - li.c-pageTaxonomy → period/domain 補完
    - 採択結果リンク → adoption_date + kekka PDF URL
    - 公募要領リンク → koboyoryo PDF URL
    省庁情報は詳細ページには掲載されていない。
    """
    html = fetch_html(detail_url, force)
    if not html:
        return {}

    soup = BeautifulSoup(html, "lxml")
    pdf_links = _extract_pdf_links_from_detail(soup)

    # テーマ名 (H1)
    h1 = soup.find("h1", class_="c-pageTitle")
    theme_name = h1.get_text(strip=True) if h1 else None

    # 期・分野 (taxonomy タグ)
    period: Optional[str] = None
    domain: Optional[str] = None
    tax = soup.find("li", class_="c-pageTaxonomy")
    if tax:
        tax_text = tax.get_text(strip=True)
        for p in PERIODS:
            if p in tax_text:
                period = p
                break
        for d in DOMAINS:
            if d in tax_text:
                domain = d
                break

    # 採択日 + kekka URL（スケジュール section の採択結果行）
    adoption_date: Optional[str] = None
    kekka_url_from_detail: Optional[str] = None
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "kekka" in href.lower() and href.lower().endswith(".pdf"):
            kekka_url_from_detail = urljoin(BASE_URL, href)
            date_text = a.get_text(strip=True)
            adoption_date = _parse_japanese_date(date_text) or _parse_date_dotted(date_text)
            if kekka_url_from_detail:
                pdf_links.setdefault("kekka_pdf", kekka_url_from_detail)

    # themes を補完
    conn.execute("""
        UPDATE themes SET
            theme_name    = COALESCE(?, theme_name),
            period        = COALESCE(?, period),
            domain        = COALESCE(?, domain),
            adoption_date = COALESCE(?, adoption_date)
        WHERE theme_id = ?
    """, (theme_name, period, domain, adoption_date, theme_id))
    conn.commit()

    return pdf_links


# ── 公募要領 PDF パース ───────────────────────────────────────────────────────
RE_TOTAL_BUDGET = re.compile(
    r"(?:支援総額|事業総額|予算総額|支援額の規模|規模|総額)[：:は]?\s*(?:総額\s*)?(?:約\s*)?(\d+(?:\.\d+)?)\s*億円"
)
RE_PER_CASE = re.compile(
    r"(?:1件あたり|１件あたり|1件当たり|１件当たり|一件あたり)\s*(?:[のは]\s*)?"
    r"(?:上限\s*)?(?:約\s*)?(\d+(?:\.\d+)?)\s*億円"
)
RE_UPPER_LIMIT = re.compile(
    r"(?:上限|上限額)[：:\s]*(?:約\s*)?(\d+(?:\.\d+)?)\s*億円"
)
RE_CASE_COUNT = re.compile(
    r"(?:採択(?:予定)?件数|件数)[：:は]?\s*(?:約\s*)?(\d+)\s*件"
)
RE_SUBTHEME = re.compile(r"^\s*（?([A-Z](?:-\d+)?)）?\s*[）)．.\s]", re.MULTILINE)
RE_MINISTRY_PDF = re.compile(
    r"(文部科学省|経済産業省|総務省|内閣府|国土交通省|農林水産省|厚生労働省|防衛省)"
)
RE_MINISTRY_THEME_LINE = re.compile(
    r"[⚫●\s]*【(総|文|経|内|国)】\s*(.+?)(?:\n|$)"
)


def parse_koboyoryo_pdf(theme_id: str, text: str) -> Tuple[List[Dict], Optional[str]]:
    """
    公募要領PDFから予算情報と省庁名を抽出。
    Returns: (budget_records, ministry_or_None)
    """
    if not text.strip():
        return [], None

    ministry = None
    m_min = RE_MINISTRY_PDF.search(text[:2000])
    if m_min:
        ministry = m_min.group(1)

    records: List[Dict] = []

    def _extract_budget(segment: str, sub_theme: str) -> Dict:
        total    = None
        per_case = None
        exp_cases = None

        m = RE_TOTAL_BUDGET.search(segment)
        if m:
            total = float(m.group(1))

        m = RE_PER_CASE.search(segment)
        if m:
            per_case = float(m.group(1))
        if per_case is None:
            m = RE_UPPER_LIMIT.search(segment)
            if m:
                per_case = float(m.group(1))

        m = RE_CASE_COUNT.search(segment)
        if m:
            exp_cases = int(m.group(1))

        return {
            "theme_id":         theme_id,
            "sub_theme":        sub_theme,
            "total_budget_oku": total,
            "max_per_case_oku": per_case,
            "expected_cases":   exp_cases,
            "raw_text":         segment[:500].strip(),
        }

    subtheme_matches = list(RE_SUBTHEME.finditer(text))
    if len(subtheme_matches) >= 2:
        for i, match in enumerate(subtheme_matches):
            start = match.start()
            end   = subtheme_matches[i + 1].start() if i + 1 < len(subtheme_matches) else len(text)
            segment   = text[start:end]
            sub_label = match.group(1)
            rec = _extract_budget(segment, sub_label)
            if any(v is not None for v in [rec["total_budget_oku"],
                                            rec["max_per_case_oku"],
                                            rec["expected_cases"]]):
                records.append(rec)
    else:
        rec = _extract_budget(text, "")
        if any(v is not None for v in [rec["total_budget_oku"],
                                        rec["max_per_case_oku"],
                                        rec["expected_cases"]]):
            records.append(rec)

    return records, ministry


# ── 採択結果 PDF パース ───────────────────────────────────────────────────────
#
# 実際のkekka PDF形式（pdfminerテキスト出力）:
#   技術開発テーマ名
#   <テーマ名>
#
#   実施機関名（代表機関） <機関名>   ← コロンなし、同一行
#
#   技術開発課題の名称
#   <課題名>                         ← 次行
#
#   技術開発課題の概要
#   <概要...複数行>                  ← 次行以降
#
#   （参考）審査会　構成員           ← 終端マーカー
#

# 実施機関名（代表機関）の後は空白+機関名（コロンなし）
RE_KEKKA_ORG = re.compile(
    r"実施機関名.{0,15}[）)]\s*(.+?)(?:\n|$)"
)
# 技術開発課題の名称は次の行に値
RE_KEKKA_TASK_LABEL = re.compile(r"技術開発課題の名称")
# 技術開発課題の概要は次の行以降に値
RE_KEKKA_OVERVIEW_LABEL = re.compile(r"技術開発課題の概要")
# 委託/補助
RE_COMMITTEE = re.compile(r"(?:委託[／/]補助|事業形態)[：:]\s*(委託|補助)")
# 補助率
RE_SUBSIDY = re.compile(r"(?:補助率|補助割合)[：:]\s*([\d／/]+(?:分の\d+)?(?:/\d+)?)")
# 実施期間
RE_PERIOD = re.compile(
    r"令和\s*(\d+)\s*年\s*(?:(\d+)\s*月\s*)?[〜～から]令和\s*(\d+)\s*年\s*(?:(\d+)\s*月)?"
)
RE_PERIOD_NENDO = re.compile(
    r"令和\s*(\d+)\s*年度?\s*[〜～から]\s*令和\s*(\d+)\s*年度?"
)
# 終端マーカー（審査会情報の手前）
RE_KEKKA_END = re.compile(r"（\s*参\s*考\s*）|審\s*査\s*会|座\s*長|委\s*員")


def _reiwa_to_year(n: int) -> int:
    return 2018 + n


def _parse_period(text: str) -> Tuple[Optional[str], Optional[str]]:
    m = RE_PERIOD.search(text)
    if m:
        y1 = _reiwa_to_year(int(m.group(1)))
        mo1 = f"-{int(m.group(2)):02d}" if m.group(2) else ""
        y2 = _reiwa_to_year(int(m.group(3)))
        mo2 = f"-{int(m.group(4)):02d}" if m.group(4) else ""
        return f"{y1}{mo1}", f"{y2}{mo2}"
    m = RE_PERIOD_NENDO.search(text)
    if m:
        return str(_reiwa_to_year(int(m.group(1)))), str(_reiwa_to_year(int(m.group(2))))
    return None, None


def _next_nonempty_line(lines: List[str], idx: int) -> str:
    """idx の次の空でない行を返す"""
    for j in range(idx + 1, len(lines)):
        if lines[j].strip():
            return lines[j].strip()
    return ""


def _lines_until_next_section(lines: List[str], idx: int) -> str:
    """idx 以降で次のセクションラベルまでの行を結合"""
    buf = []
    for j in range(idx + 1, len(lines)):
        line = lines[j].strip()
        # 空行が2連続したら終わり
        if not line:
            if buf and buf[-1] == "":
                break
            buf.append("")
            continue
        # 審査会等終端マーカー
        if RE_KEKKA_END.search(line):
            break
        # 別のセクションラベル的行（短くて「名称」「概要」「機関名」を含む）
        if len(line) < 20 and any(k in line for k in ["名称", "概要", "機関名", "代表者"]):
            break
        buf.append(line)
    return "\n".join(buf).strip()


def parse_kekka_pdf(theme_id: str, text: str) -> List[Dict]:
    """
    採択結果PDFから研究課題情報を抽出。
    1ページに複数レコードが含まれる場合がある。
    """
    if not text.strip():
        return []

    # 実施機関行で分割して各レコードを処理
    # 分割マーカー: "実施機関名" を含む行
    lines = text.split("\n")
    records: List[Dict] = []

    # 実施機関名行のインデックスを収集
    org_line_indices = [
        i for i, line in enumerate(lines)
        if "実施機関名" in line
    ]

    if not org_line_indices:
        return []

    # 各実施機関ブロックを処理
    for block_idx, org_line_i in enumerate(org_line_indices):
        # ブロック終端
        next_org_i = (org_line_indices[block_idx + 1]
                      if block_idx + 1 < len(org_line_indices)
                      else len(lines))
        block_lines = lines[org_line_i:next_org_i]
        block_text  = "\n".join(block_lines)

        # 機関名: 同じ行にスペース後に続く
        m_org = RE_KEKKA_ORG.search(block_text)
        if not m_org:
            # "実施機関名（代表機関）\n<機関名>" 形式のフォールバック
            org_line = block_lines[0].strip()
            # ラベル部分を除去
            org_name_raw = re.sub(r"実施機関名.{0,15}[）)]?\s*", "", org_line).strip()
            if not org_name_raw and len(block_lines) > 1:
                org_name_raw = block_lines[1].strip()
        else:
            org_name_raw = m_org.group(1).strip()

        # 課題名と概要
        task_name: Optional[str] = None
        task_overview: Optional[str] = None

        for i, line in enumerate(block_lines):
            if RE_KEKKA_TASK_LABEL.search(line) and task_name is None:
                task_name = _next_nonempty_line(block_lines, i)
            if RE_KEKKA_OVERVIEW_LABEL.search(line) and task_overview is None:
                task_overview = _lines_until_next_section(block_lines, i)

        if not task_name:
            continue

        # 委託/補助・補助率・期間
        m_com = RE_COMMITTEE.search(block_text)
        committee_type = m_com.group(1) if m_com else None

        m_sub = RE_SUBSIDY.search(block_text)
        subsidy_rate = m_sub.group(1) if m_sub else None

        start_date, end_date = _parse_period(block_text)

        records.append({
            "theme_id":       theme_id,
            "org_name":       org_name_raw,
            "task_name":      task_name,
            "task_overview":  (task_overview or "")[:1000],
            "committee_type": committee_type,
            "subsidy_rate":   subsidy_rate,
            "start_date":     start_date,
            "end_date":       end_date,
        })

    return records


# ── 省庁情報補完（第二・三期）────────────────────────────────────────────────
def fetch_ministry_pdfs(conn: sqlite3.Connection, force: bool = False) -> int:
    """
    第二・三期テーマの省庁情報補完。
    yokoku20260313.pdf（第三期）・koboyotei20250418.pdf（第二期）を解析し
    【経】【文】【総】等のコードからthemes.ministryを更新する。
    """
    updated = 0
    for period, url in MINISTRY_PDF_URLS.items():
        logger.info("省庁情報PDF取得: %s (%s)", url.split("/")[-1], period)
        data = fetch_pdf(url, force)
        if not data:
            logger.warning("省庁PDF取得失敗: %s", url)
            continue
        text = extract_pdf_text(data)
        if not text.strip():
            logger.warning("省庁PDF テキスト抽出失敗: %s", url)
            continue

        for m in RE_MINISTRY_THEME_LINE.finditer(text):
            code = m.group(1)
            theme_name_raw = m.group(2).strip()
            if not theme_name_raw or len(theme_name_raw) < 5:
                continue
            ministry = MINISTRY_CODE_MAP.get(code)
            if not ministry:
                continue
            theme_id = _match_theme_by_name(conn, theme_name_raw)
            if theme_id:
                cur = conn.execute(
                    "UPDATE themes SET ministry=? WHERE theme_id=? AND (ministry IS NULL OR ministry='')",
                    (ministry, theme_id)
                )
                if cur.rowcount > 0:
                    updated += 1
                    logger.info("  省庁補完: %s → %s [%s]",
                                theme_id, ministry, theme_name_raw[:35])

    conn.commit()
    logger.info("省庁補完: %d件更新完了", updated)
    return updated


# ── PRシートページマッピング ──────────────────────────────────────────────────
RE_PR_HEADER = re.compile(r"第一期\s+技術開発テーマ[：:]\s*(.+)")
RE_PR_SUBTHEME_SUFFIX = re.compile(r"\s+[A-Z](?:-\d+)?[）)]\s*.*$")


def _get_pr_sheet_pages(pdf_bytes: bytes) -> Dict[str, int]:
    """PRシートPDFをページ毎にスキャンしテーマ名→ページ番号マップを返す"""
    result: Dict[str, int] = {}
    try:
        laparams = LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5)
        for page_num, page_layout in enumerate(
            extract_pages(io.BytesIO(pdf_bytes), laparams=laparams), start=1
        ):
            page_text_blocks = []
            for element in page_layout:
                if isinstance(element, LTTextContainer):
                    page_text_blocks.append(element.get_text())
            page_text = "\n".join(page_text_blocks)

            m = RE_PR_HEADER.search(page_text)
            if m:
                raw_name = m.group(1).strip()
                # "テーマ名 A）..." → "テーマ名" サブテーマサフィックス除去
                clean_name = RE_PR_SUBTHEME_SUFFIX.sub("", raw_name).strip()
                if clean_name and clean_name not in result:
                    result[clean_name] = page_num
                    logger.debug("PRシート: p%d → %s", page_num, clean_name[:40])
    except Exception as e:
        logger.warning("PRシートページスキャン失敗: %s", e)
    return result


def fetch_pr_sheet(conn: sqlite3.Connection, force: bool = False) -> int:
    """PRシートPDFを解析しthemes.pr_sheet_url/pr_sheet_pageを更新"""
    logger.info("PRシートPDF取得: %s", PR_SHEET_URL.split("/")[-1])
    data = fetch_pdf(PR_SHEET_URL, force)
    if not data:
        logger.warning("PRシートPDF取得失敗: %s", PR_SHEET_URL)
        return 0

    page_map = _get_pr_sheet_pages(data)
    logger.info("PRシート: %d テーマのページを検出", len(page_map))

    updated = 0
    for theme_name_raw, page_num in page_map.items():
        theme_id = _match_theme_by_name(conn, theme_name_raw)
        if theme_id:
            conn.execute(
                "UPDATE themes SET pr_sheet_url=?, pr_sheet_page=? WHERE theme_id=?",
                (PR_SHEET_URL, page_num, theme_id)
            )
            updated += 1
            logger.info("  PRシート: %s → p%d [%s]",
                        theme_id, page_num, theme_name_raw[:35])

    conn.commit()
    logger.info("PRシート: %d件更新完了", updated)
    return updated


# ── 内閣府 実施方針PDF 予算補完 ──────────────────────────────────────────────
# \x0c はページ区切りで ^ にマッチしないため、正規化後に使用
RE_JISSI_SECTION = re.compile(
    r"^（(\d+)）\s*(.+?)$", re.MULTILINE
)
RE_JISSI_BUDGET_AREA = re.compile(
    r"支援規模|支援の方法|５－２|5-2|支援総額|[1１]件あたり", re.IGNORECASE
)
RE_JISSI_TOTAL = re.compile(
    r"(?:テーマ総額|支援総額)[：:]\s*(\d+(?:\.\d+)?)\s*(?:億|憶)円"
)
RE_JISSI_TOTAL_IKA = re.compile(
    r"(\d+(?:\.\d+)?)\s*(?:億|憶)円以下"
)
# [1１]件あたり: halfwidth/fullwidth 両対応、憶円 typo も吸収
RE_JISSI_PER_CASE = re.compile(
    r"[1１]\s*件あたり\s*(\d+(?:\.\d+)?)\s*(?:億|憶)円程度を上限"
)
# A) XX億円程度を上限として（「１件あたり」なしのサブテーマ形式）
RE_JISSI_AB_UPPER = re.compile(
    r"[A-Z](?:-\d+)?[）)]\s*(\d+(?:\.\d+)?)\s*(?:億|憶)円程度を上限(?:として|とし)"
)
RE_JISSI_CASES = re.compile(
    r"(?:最大)?(\d+)\s*件程度(?:を採択|採択)"
)
RE_JISSI_CASES_ALT = re.compile(
    r"支援件数[：:]\s*(\d+)\s*件"
)
# FS 合算上限: 「（１）（２）合わせてX億円程度を上限とし」
RE_JISSI_TOTAL_AWASETE = re.compile(
    r"合わせて(\d+(?:\.\d+)?)\s*(?:億|憶)円程度を上限"
)
# インライン A/B サブテーマ: 「A) 125億円程度を上限として、1件程度を採択する。B) 30億円...」
RE_JISSI_AB_BUDGET_INLINE = re.compile(
    r"([A-Z](?:-\d+)?)[）)]\s*(\d+(?:\.\d+)?)\s*(?:億|憶)円程度を上限(?:として|とし).*?(\d+)\s*件程度"
)


# セクションヘッダーパターン: （N） または (N) が行頭に現れる
# 第一期詳細: 行頭に「24 （6）」等のページ番号付き
# 第二期詳細: 行頭に「74    （11）」等（ページ番号+空白+括弧番号）
# 簡易リスト: 行頭が直接「（1）」
_RE_JISSI_SECTION_HEADER = re.compile(r"^\s*(?:\d+\s+)?[（(]\s*\d+\s*[）)]\s*")


def _search_budget_by_theme_name_in_text(
    full_text: str, theme_name: str
) -> List[Dict]:
    """
    PDFテキスト全体でテーマ名を行単位検索し、近傍の支援規模から予算情報を抽出。
    section-splittingが効かない第二期PDFへのフォールバック。

    「（N）テーマ名」形式の行（セクションヘッダー）をすべて収集し、
    後ろから順に試みる（詳細セクションは簡易リストより後方に位置する）。
    各候補で次のセクションヘッダーまでを検索ウィンドウとして絞り、
    予算情報が見つかった最初の候補を採用する。
    """
    theme_norm = _norm(theme_name)
    if len(theme_norm) < 8:
        return []
    search_prefix = theme_norm[:min(15, len(theme_norm))]

    lines = full_text.split("\n")

    # セクションヘッダー候補を全て収集
    header_candidates: List[int] = []
    for i, line in enumerate(lines):
        if _RE_JISSI_SECTION_HEADER.match(line.strip()) and search_prefix in _norm(line):
            header_candidates.append(i)

    # 後ろから順に試みる（詳細セクションを優先）
    for section_start_idx in reversed(header_candidates):
        next_section_idx = min(section_start_idx + 200, len(lines))
        for i in range(section_start_idx + 1, next_section_idx):
            stripped = lines[i].strip()
            if _RE_JISSI_SECTION_HEADER.match(stripped) and len(_norm(stripped)) > 8:
                next_section_idx = i
                break

        context_lines = lines[section_start_idx: next_section_idx]
        context_text = "\n".join(context_lines)

        if not RE_JISSI_BUDGET_AREA.search(context_text):
            continue

        recs = _parse_jissihousin_section(context_text, theme_name)
        if recs:
            return recs

    # セクションヘッダーで見つからない場合は最後の行出現にフォールバック
    last_match_idx = -1
    for i, line in enumerate(lines):
        if search_prefix in _norm(line):
            last_match_idx = i

    if last_match_idx == -1:
        return []

    # FS テーマ等で詳細セクションが長い場合に備え、固定500行ウィンドウを使用
    # （サブセクション「（N）...」が中間に現れるため次セクションヘッダーで打ち切れない）
    context_lines = lines[last_match_idx: last_match_idx + 500]
    context_text = "\n".join(context_lines)
    if not RE_JISSI_BUDGET_AREA.search(context_text):
        return []

    return _parse_jissihousin_section(context_text, theme_name)


def _parse_jissihousin_section(section_text: str, theme_name: str) -> List[Dict]:
    """実施方針PDFの単一テーマセクションから予算情報を抽出"""
    records: List[Dict] = []

    # 支援規模セクションを特定
    m_area = RE_JISSI_BUDGET_AREA.search(section_text)
    budget_text = section_text[m_area.start():] if m_area else section_text

    # サブテーマ別予算（A, B-1, B-2 等）
    subtheme_lines: List[Tuple[str, str]] = []  # (label, line_text)
    for line in budget_text.split("\n"):
        sl = line.strip()
        # "A）1件あたり..." or "B-1)1件あたり..." pattern
        sm = re.match(r"^([A-Z](?:-\d+)?)[）)]\s*(.+)", sl)
        if sm and ("億円" in sl or "件" in sl):
            subtheme_lines.append((sm.group(1), sl))

    if subtheme_lines:
        for label, line in subtheme_lines:
            pc_m = RE_JISSI_PER_CASE.search(line)
            ca_m = RE_JISSI_CASES.search(line)
            per_case = float(pc_m.group(1)) if pc_m else None
            # "A) 125億円程度を上限として" 形式（件あたり表記なし）
            if per_case is None:
                m_upper = RE_JISSI_AB_UPPER.search(line)
                if m_upper:
                    per_case = float(m_upper.group(1))
            cases = int(ca_m.group(1)) if ca_m else 1
            if per_case is not None:
                records.append({
                    "theme_name": theme_name,
                    "sub_theme":  label,
                    "total_budget_oku": None,
                    "max_per_case_oku": per_case,
                    "expected_cases":   cases,
                    "raw_text": line[:300],
                })
    else:
        # インライン A/B 形式を budget_text 全体に対してスキャン
        # 例: "A) 125億円程度を上限として、1件程度を採択する。 B) 30億円程度を上限として..."
        inline_ab = list(RE_JISSI_AB_BUDGET_INLINE.finditer(budget_text))
        if inline_ab:
            for ab_m in inline_ab:
                label    = ab_m.group(1)
                per_case = float(ab_m.group(2))
                cases    = int(ab_m.group(3))
                records.append({
                    "theme_name": theme_name,
                    "sub_theme":  label,
                    "total_budget_oku": None,
                    "max_per_case_oku": per_case,
                    "expected_cases":   cases,
                    "raw_text": budget_text[:300].strip(),
                })
        else:
            # 単一テーマ形式
            total: Optional[float] = None
            per_case: Optional[float] = None
            cases: Optional[int] = None

            m = RE_JISSI_TOTAL.search(budget_text)
            if m:
                total = float(m.group(1))
            if total is None:
                m = RE_JISSI_TOTAL_IKA.search(budget_text)
                if m:
                    total = float(m.group(1))
            if total is None:
                m = RE_JISSI_TOTAL_AWASETE.search(budget_text)
                if m:
                    total = float(m.group(1))

            m = RE_JISSI_PER_CASE.search(budget_text)
            if m:
                per_case = float(m.group(1))
            if per_case is None:
                m = RE_JISSI_AB_UPPER.search(budget_text)
                if m:
                    per_case = float(m.group(1))

            m = RE_JISSI_CASES.search(budget_text)
            if m:
                cases = int(m.group(1))
            if cases is None:
                m = RE_JISSI_CASES_ALT.search(budget_text)
                if m:
                    cases = int(m.group(1))

            if total is not None or per_case is not None:
                records.append({
                    "theme_name": theme_name,
                    "sub_theme":  "",
                    "total_budget_oku": total,
                    "max_per_case_oku": per_case,
                    "expected_cases":   cases,
                    "raw_text": budget_text[:300].strip(),
                })

    return records


def fetch_jissihousin_pdfs(conn: sqlite3.Connection, force: bool = False) -> int:
    """
    内閣府の実施方針PDF（9本）から予算情報を補完。
    既に koboyoryo PDF で取得済みのレコードは上書きしない（COALESCE維持）。
    また ministry が不明なテーマを KNOWN_MINISTRY_FIXES で補完する。
    """
    updated_budget = 0
    updated_ministry = 0

    # ── 省庁マッピング補完（確定済みの不明テーマを修正）─────────────────────
    for theme_id, ministry in KNOWN_MINISTRY_FIXES.items():
        cur = conn.execute(
            "UPDATE themes SET ministry=? WHERE theme_id=? AND (ministry IS NULL OR ministry='')",
            (ministry, theme_id)
        )
        if cur.rowcount > 0:
            updated_ministry += 1
            logger.info("  省庁確定: %s → %s", theme_id, ministry)
    conn.commit()
    logger.info("省庁マッピング補完: %d件", updated_ministry)

    # ── 実施方針PDFからの予算補完 ────────────────────────────────────────────
    for fname, period, ministry in CAO_JISSIHOUSIN_PDFS:
        url = CAO_BASE + fname
        logger.info("実施方針PDF: %s (%s / %s)", fname, period, ministry)
        data = fetch_pdf(url, force)
        if not data:
            logger.warning("  取得失敗: %s", url)
            continue
        text = extract_pdf_text(data)
        if not text.strip():
            logger.warning("  テキスト抽出失敗: %s", fname)
            continue
        # \x0c（ページ区切り）を \n に正規化して ^ アンカーが効くようにする
        text = text.replace("\x0c", "\n")

        # テーマセクションを分割
        section_boundaries = list(RE_JISSI_SECTION.finditer(text))
        if not section_boundaries:
            logger.debug("  セクション不検出: %s", fname)
            continue

        for i, m in enumerate(section_boundaries):
            theme_name = m.group(2).strip()
            # セクション終端
            start = m.start()
            end = section_boundaries[i + 1].start() if i + 1 < len(section_boundaries) else len(text)
            section_text = text[start:end]

            # テーマIDを名前から検索
            theme_id = _match_theme_by_name(conn, theme_name)
            if not theme_id:
                logger.debug("  テーマ不一致: %s", theme_name[:40])
                continue

            # 既存省庁が不明なら更新
            row = conn.execute(
                "SELECT ministry FROM themes WHERE theme_id=?", (theme_id,)
            ).fetchone()
            if row and not row["ministry"]:
                conn.execute(
                    "UPDATE themes SET ministry=? WHERE theme_id=?",
                    (ministry, theme_id)
                )

            # 予算データ抽出
            recs = _parse_jissihousin_section(section_text, theme_name)
            for rec in recs:
                # 既存レコードがない場合のみ挿入（koboyoryo PDFデータを優先）
                existing = conn.execute(
                    "SELECT id FROM theme_budgets WHERE theme_id=? AND sub_theme=?",
                    (theme_id, rec["sub_theme"])
                ).fetchone()
                if not existing:
                    upsert_budget(
                        conn, theme_id, rec["sub_theme"],
                        rec["total_budget_oku"], rec["max_per_case_oku"],
                        rec["expected_cases"], rec["raw_text"]
                    )
                    updated_budget += 1
                    logger.info("  予算追加: %s [%s] 上限=%s, 総額=%s",
                                theme_id, rec["sub_theme"] or "単一",
                                rec["max_per_case_oku"], rec["total_budget_oku"])

        # ── フォールバック: section-splitting で取得できなかったテーマへの名前検索 ──
        db_themes = conn.execute(
            "SELECT theme_id, theme_name FROM themes WHERE period=? AND ministry=?",
            (period, ministry)
        ).fetchall()

        for db_row in db_themes:
            tid   = db_row["theme_id"]
            tname = db_row["theme_name"]
            if not tname:
                continue
            existing = conn.execute(
                "SELECT COUNT(*) FROM theme_budgets WHERE theme_id=?", (tid,)
            ).fetchone()[0]
            if existing > 0:
                continue
            recs = _search_budget_by_theme_name_in_text(text, tname)
            for rec in recs:
                upsert_budget(
                    conn, tid, rec["sub_theme"],
                    rec["total_budget_oku"], rec["max_per_case_oku"],
                    rec["expected_cases"], rec["raw_text"]
                )
                updated_budget += 1
                logger.info("  予算追加(fallback): %s [%s] 上限=%s, 総額=%s",
                            tid, rec["sub_theme"] or "単一",
                            rec["max_per_case_oku"], rec["total_budget_oku"])

        conn.commit()

    logger.info("実施方針PDF補完: 予算%d件追加", updated_budget)
    return updated_budget + updated_ministry


# ── レポート ──────────────────────────────────────────────────────────────────
def print_report() -> None:
    conn = get_conn()
    print("\n" + "=" * 60)
    print("JAXA宇宙戦略基金 収集完了レポート")
    print("=" * 60)

    for table, label in [
        ("themes",         "テーマ"),
        ("organizations",  "組織"),
        ("theme_budgets",  "予算情報"),
        ("research_tasks", "研究課題"),
    ]:
        count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"  {label:12s}: {count:4d} 件")

    print("\n【期別テーマ数】")
    for row in conn.execute(
        "SELECT period, COUNT(*) FROM themes GROUP BY period ORDER BY period"
    ):
        print(f"  {(row[0] or '不明'):12s}: {row[1]:3d} 件")

    print("\n【省庁別テーマ数】")
    for row in conn.execute(
        "SELECT ministry, COUNT(*) FROM themes GROUP BY ministry ORDER BY 2 DESC"
    ):
        print(f"  {(row[0] or '不明'):18s}: {row[1]:3d} 件")

    print("\n【予算情報 上位10件（1件上限）】")
    for row in conn.execute("""
        SELECT t.theme_id, t.theme_name, b.sub_theme, b.max_per_case_oku, b.total_budget_oku
        FROM theme_budgets b
        JOIN themes t ON b.theme_id = t.theme_id
        WHERE b.max_per_case_oku IS NOT NULL
        ORDER BY b.max_per_case_oku DESC
        LIMIT 10
    """):
        name  = (row[1] or "")[:28]
        per   = f"{row[3]:.0f}億円" if row[3] else "不明"
        total = f"(総{row[4]:.0f}億)" if row[4] else ""
        print(f"  [{row[0]:10s}] {name:28s} 上限:{per}{total}")

    print("\n【採択課題 テーマ別件数 上位10】")
    for row in conn.execute("""
        SELECT theme_id, COUNT(*) as cnt FROM research_tasks
        GROUP BY theme_id ORDER BY cnt DESC LIMIT 10
    """):
        print(f"  [{row[0]:10s}] {row[1]:3d}件")

    pr_count = conn.execute(
        "SELECT COUNT(*) FROM themes WHERE pr_sheet_page IS NOT NULL"
    ).fetchone()[0]
    print(f"\n【PRシート】 ページ登録: {pr_count}件")

    print(f"\n  DB: {DB_PATH}")
    print("=" * 60)
    conn.close()


# ── メイン ────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="JAXA宇宙戦略基金 データ収集")
    parser.add_argument("--force-download", action="store_true",
                        help="キャッシュを無視して再ダウンロード")
    parser.add_argument("--patch", action="store_true",
                        help="省庁情報・PRシート・実施方針PDFのパッチのみ適用（全スクレイピングはスキップ）")
    args = parser.parse_args()
    force = args.force_download

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )

    setup_dirs()
    conn = get_conn()
    init_db(conn)

    # ── パッチモード: 省庁補完・PRシートのみ ─────────────────────────────────
    if args.patch:
        logger.info("=== パッチモード: 省庁情報・PRシート・実施方針PDF補完 ===")
        fetch_ministry_pdfs(conn, force)
        fetch_pr_sheet(conn, force)
        fetch_jissihousin_pdfs(conn, force)
        conn.close()
        print_report()
        return

    # ── Step 1: テーマ一覧 ────────────────────────────────────────────────────
    logger.info("テーマ一覧取得: %s", TECHLIST_URL)
    theme_ids = fetch_techlist(conn, force)
    logger.info("発見テーマ数: %d", len(theme_ids))

    # ── Step 2: 第一期採択結果ページ（省庁・機関補完）────────────────────────
    logger.info("第一期採択結果取得: %s", TECHRESULT01)
    fetch_techresult01(conn, force)

    # ── Step 3: テーマ別詳細 + PDF ───────────────────────────────────────────
    for theme_id in theme_ids:
        row = conn.execute(
            "SELECT detail_url FROM themes WHERE theme_id=?", (theme_id,)
        ).fetchone()
        if not row or not row["detail_url"]:
            logger.warning("detail_url なし: %s — スキップ", theme_id)
            continue
        detail_url = row["detail_url"]

        logger.info("[%s] 詳細ページ: %s", theme_id, detail_url)
        pdf_links = fetch_theme_detail(conn, theme_id, detail_url, force)

        # テックリストで見つかった kekka URL を優先してセット
        if theme_id in _KEKKA_URLS_FROM_TECHLIST:
            pdf_links.setdefault("kekka_pdf", _KEKKA_URLS_FROM_TECHLIST[theme_id])

        # 3b. 公募要領 PDF
        kobo_url = pdf_links.get("koboyoryo_pdf")
        if not kobo_url:
            for candidate in _koboyoryo_urls(theme_id):
                data = fetch_pdf(candidate, force)
                if data is not None:
                    kobo_url = candidate
                    break

        if kobo_url:
            data = fetch_pdf(kobo_url, force)
            if data:
                text = extract_pdf_text(data)
                budgets, ministry = parse_koboyoryo_pdf(theme_id, text)
                for b in budgets:
                    upsert_budget(conn, **b)
                if ministry:
                    conn.execute(
                        "UPDATE themes SET ministry=? WHERE theme_id=? AND ministry IS NULL",
                        (ministry, theme_id)
                    )
                conn.commit()
                logger.info("  [%s] 公募要領: 予算%d件, 省庁:%s",
                            theme_id, len(budgets), ministry or "不明")
        else:
            logger.debug("  [%s] 公募要領PDF なし", theme_id)

        # 3c. 採択結果 PDF
        kekka_url = pdf_links.get("kekka_pdf")
        if not kekka_url:
            for candidate in _kekka_urls(theme_id):
                data = fetch_pdf(candidate, force)
                if data is not None:
                    kekka_url = candidate
                    break

        if kekka_url:
            data = fetch_pdf(kekka_url, force)
            if data:
                text = extract_pdf_text(data)
                tasks = parse_kekka_pdf(theme_id, text)
                for t in tasks:
                    upsert_research_task(conn, **t)
                    upsert_org(conn, theme_id, t["org_name"],
                               is_lead=None, org_type=_classify_org(t["org_name"]))
                conn.commit()
                logger.info("  [%s] 採択結果: %d件の研究課題", theme_id, len(tasks))
        else:
            logger.debug("  [%s] 採択結果PDF なし", theme_id)

    # ── Step 4: 省庁情報補完（第二・三期）────────────────────────────────────
    logger.info("省庁情報補完開始")
    fetch_ministry_pdfs(conn, force)

    # ── Step 5: PRシートページマッピング ────────────────────────────────────
    logger.info("PRシートページマッピング開始")
    fetch_pr_sheet(conn, force)

    # ── Step 6: 実施方針PDF（内閣府）から予算・省庁補完 ─────────────────────
    logger.info("実施方針PDF補完開始")
    fetch_jissihousin_pdfs(conn, force)

    conn.close()
    print_report()


if __name__ == "__main__":
    main()
