"""
Fill expected_cases for NULL parent rows (sub_theme='') in theme_budgets.
Strategy:
  1. Extract 採択予定件数 from overview PDFs (already downloaded)
  2. Arithmetic fallback: total / per = integer → use that, flag in raw_text
  3. Manual overrides for complex themes (A/B tracks)
"""
import io
import re
import sqlite3
import sys
import unicodedata
from pathlib import Path

from pdfminer.high_level import extract_text_to_fp
from pdfminer.layout import LAParams

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DATA_DIR = Path(__file__).parent.parent / "data"
PDF_DIR = DATA_DIR / "pdfs"
DB_PATH = DATA_DIR / "fund_jaxa.db"

OVERVIEW_PDFS = [
    PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_pdf.pdf",
    PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_2_pdf.pdf",
    PDF_DIR / "www8_cao_go_jp_space_kikin_phase3_r7hoseiyosan_pdf.pdf",
]

RE_HEADER = re.compile(r"【[^】]+】\s*(?:\d+[.．]\s*)?(.+)")
RE_SCALE = re.compile(r"支援規模[：:]\s*(\d+(?:\.\d+)?)\s*億円")
RE_CASES_COLON = re.compile(r"[：:]\s*(\d+)\s*件")       # ": N件"
RE_CASES_PAREN = re.compile(r"[）)]\s*(\d+)\s*件")        # "）N件" for A/B splits
RE_CASES_MAX = re.compile(r"最大\s*(\d+)\s*件")
RE_CASES_RANGE = re.compile(r"(\d+)\s*[〜~]\s*\d*\s*件")  # "N〜M件" or "N〜数件"


def norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s)


def fuzzy(s: str) -> str:
    s = norm(s).lower()
    for ch in " 　\t・･（）()「」『』【】。、，,．.":
        s = s.replace(ch, "")
    return s


def extract_lines(path: Path) -> list[str]:
    buf = io.StringIO()
    with open(path, "rb") as f:
        extract_text_to_fp(f, buf,
                           laparams=LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5),
                           output_type="text", codec="utf-8")
    return [norm(ln) for ln in buf.getvalue().splitlines()]


def parse_cases_block(block: str) -> int | None:
    """
    Try multiple patterns on a multi-line text block following 採択予定件数 label.
    Returns integer cases or None.
    """
    # 1. A/B split: sum of all "）N件" occurrences (≥2 means A/B tracks)
    paren_hits = RE_CASES_PAREN.findall(block)
    if len(paren_hits) >= 2:
        return sum(int(x) for x in paren_hits)

    # 2. Single colon value: ": N件"
    m = RE_CASES_COLON.search(block)
    if m:
        return int(m.group(1))

    # 3. "最大N件"
    m = RE_CASES_MAX.search(block)
    if m:
        return int(m.group(1))

    # 4. Range "N〜...件" → lower bound
    m = RE_CASES_RANGE.search(block)
    if m:
        return int(m.group(1))

    return None


def load_theme_map(conn: sqlite3.Connection) -> dict[str, str]:
    rows = conn.execute("SELECT theme_id, theme_name FROM themes").fetchall()
    result = {}
    for tid, name in rows:
        if name:
            k = fuzzy(name)
            result[k] = tid
            # also strip trailing ministry
            k2 = re.sub(r"\(?[総文経内]\w+省?\)?\s*$", "", k).rstrip()
            if k2 and k2 != k:
                result[k2] = tid
    return result


def find_theme_id(raw_name: str, theme_map: dict[str, str]) -> str | None:
    key = fuzzy(raw_name)
    k2 = re.sub(r"\(?[総文経内]\w+省?\)?\s*$", "", key).rstrip()
    for k in (k2, key):
        if k in theme_map:
            return theme_map[k]
    best, best_len = None, 0
    for k, tid in theme_map.items():
        if len(k) >= 6 and (k in (k2 or key) or (k2 or key) in k):
            if len(k) > best_len:
                best_len, best = len(k), tid
    return best


def extract_cases_from_pdfs(theme_map: dict[str, str]) -> dict[str, int]:
    """
    Parse all 3 overview PDFs and return {theme_id: cases} for parent rows.
    """
    results: dict[str, int] = {}

    for path in OVERVIEW_PDFS:
        if not path.exists():
            print(f"  MISSING: {path.name}")
            continue
        lines = extract_lines(path)
        print(f"  {path.name}: {len(lines)} lines")

        # Detect section boundaries
        sections: list[tuple[int, str]] = []
        for i, ln in enumerate(lines):
            if "【" not in ln or i < 50:
                continue
            m = RE_HEADER.match(ln.strip())
            if not m:
                continue
            raw_name = m.group(1).strip()
            if len(raw_name) < 8 or "億円" in raw_name:
                continue
            sections.append((i, raw_name))

        for idx, (sec_start, raw_name) in enumerate(sections):
            sec_end = sections[idx + 1][0] if idx + 1 < len(sections) else len(lines)
            sec_end = min(sec_end, sec_start + 100)

            tid = find_theme_id(raw_name, theme_map)
            if tid is None or tid in results:
                continue

            # Find 採択予定件数 block
            for j, ln in enumerate(lines[sec_start:sec_end]):
                if "採択予定件数" not in ln:
                    continue
                block = " ".join(lines[sec_start + j: sec_start + j + 10])
                cases = parse_cases_block(block)
                if cases is not None:
                    results[tid] = cases
                break

    return results


def arithmetic_cases(total: float | None, per: float | None) -> int | None:
    """Compute total/per if it's a clean integer."""
    if total is None or per is None or per == 0:
        return None
    ratio = total / per
    if abs(ratio - round(ratio)) < 0.01:
        return int(round(ratio))
    return None


def update_db(conn: sqlite3.Connection,
              pdf_cases: dict[str, int],
              null_rows: list[tuple]) -> None:
    """
    Apply cases to NULL parent rows.
    null_rows: [(theme_id, theme_name, ministry, period, total, per, cases), ...]
    """
    print("\n=== Updates ===")
    for tid, name, minist, period, total, per, _cases in null_rows:
        if tid == "rfp":
            print(f"  SKIP: rfp (complex RFP structure)")
            continue

        cases = None
        source = None

        # 1. PDF extraction
        if tid in pdf_cases:
            cases = pdf_cases[tid]
            source = "PDF"

        # 2. Arithmetic fallback
        if cases is None:
            cases = arithmetic_cases(total, per)
            if cases is not None:
                source = f"calc({total}÷{per})"

        if cases is None:
            print(f"  SKIP (no data): {tid} [{name[:35]}]")
            continue

        # Update expected_cases; also append note to raw_text if arithmetic
        existing_raw = conn.execute(
            "SELECT raw_text FROM theme_budgets WHERE theme_id=? AND sub_theme=''",
            (tid,)).fetchone()
        raw = (existing_raw[0] or "") if existing_raw else ""

        if source and source.startswith("calc") and "推計" not in raw:
            raw = (raw + f" [推計: {source}]").strip()

        conn.execute(
            "UPDATE theme_budgets SET expected_cases=?, raw_text=? "
            "WHERE theme_id=? AND sub_theme='' AND expected_cases IS NULL",
            (cases, raw, tid),
        )
        affected = conn.execute("SELECT changes()").fetchone()[0]
        if affected:
            print(f"  SET {tid:<12} cases={cases:<4} src={source}  [{name[:40]}]")
        else:
            print(f"  NOCHANGE {tid:<12} (already set?)")


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    theme_map = load_theme_map(conn)
    print(f"Loaded {len(theme_map)} theme name keys")

    # Fetch the 24 NULL parent rows
    null_rows = conn.execute("""
        SELECT t.theme_id, t.theme_name, t.ministry, t.period,
               tb.total_budget_oku, tb.max_per_case_oku, tb.expected_cases
        FROM themes t
        JOIN theme_budgets tb ON t.theme_id = tb.theme_id AND tb.sub_theme = ''
        WHERE tb.expected_cases IS NULL
        ORDER BY t.period, t.theme_id
    """).fetchall()
    print(f"NULL expected_cases rows: {len(null_rows)}")

    print("\n--- Parsing PDFs ---")
    pdf_cases = extract_cases_from_pdfs(theme_map)
    print(f"\nPDF extraction results: {len(pdf_cases)} themes")
    for k, v in sorted(pdf_cases.items()):
        print(f"  {k}: {v}件")

    update_db(conn, pdf_cases, null_rows)
    conn.commit()

    # Final report
    print("\n=== Remaining NULL (after update) ===")
    remaining = conn.execute("""
        SELECT t.theme_id, t.theme_name, tb.total_budget_oku, tb.max_per_case_oku
        FROM themes t
        JOIN theme_budgets tb ON t.theme_id = tb.theme_id AND tb.sub_theme = ''
        WHERE tb.expected_cases IS NULL
        ORDER BY t.theme_id
    """).fetchall()
    for r in remaining:
        print(f"  {r[0]:<12} total={r[2]} per={r[3]} [{r[1][:40]}]")
    print(f"  → {len(remaining)} still NULL")

    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()


if __name__ == "__main__":
    main()
