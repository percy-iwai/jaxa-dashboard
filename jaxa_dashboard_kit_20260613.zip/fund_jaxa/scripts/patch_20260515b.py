"""
2026-05-15 DB patch (part B):
  1. Fix org_type misclassifications (QPS研究所, 立命館, 三菱重工業)
  2. Deduplicate org names within each theme (NFKC + legal-form stripping)
  3. Add overview_pdf_url / overview_pdf_page to themes (page-by-page PDF scan)
  4. Add result_pdf_url / result_pdf_page to themes (from techlist + detail HTML)
"""
import io
import re
import sqlite3
import sys
import unicodedata
from collections import defaultdict
from pathlib import Path
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from pdfminer.high_level import extract_pages
from pdfminer.layout import LAParams, LTTextContainer

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DATA_DIR  = Path(__file__).parent.parent / "data"
PDF_DIR   = DATA_DIR / "pdfs"
CACHE_DIR = DATA_DIR / "cache"
DB_PATH   = DATA_DIR / "fund_jaxa.db"
BASE_URL  = "https://fund.jaxa.jp"

OVERVIEW_PDFS = [
    (
        PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_pdf.pdf",
        "https://www8.cao.go.jp/space/kikin/gijyutukaihatu.pdf",
        "第一期",
    ),
    (
        PDF_DIR / "www8_cao_go_jp_space_kikin_gijyutukaihatu_2_pdf.pdf",
        "https://www8.cao.go.jp/space/kikin/gijyutukaihatu_2.pdf",
        "第二期",
    ),
    (
        PDF_DIR / "www8_cao_go_jp_space_kikin_phase3_r7hoseiyosan_pdf.pdf",
        "https://www8.cao.go.jp/space/kikin/phase3_r7hoseiyosan.pdf",
        "第三期",
    ),
]

RE_HEADER = re.compile(r"【[^】]+】\s*(?:\d+[.．]\s*)?(.+)")

LAPARAMS = LAParams(line_overlap=0.5, char_margin=2.0, line_margin=0.5)


# ─── Normalization helpers ────────────────────────────────────────────────────

def norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s)


def fuzzy(s: str) -> str:
    s = norm(s).lower()
    for ch in " 　\t・･（）()「」『』【】。、，,．.":
        s = s.replace(ch, "")
    return s


LEGAL_PREFIXES = [
    "株式会社", "有限会社", "合同会社",
    "学校法人", "国立大学法人", "公立大学法人", "社会福祉法人",
    "一般社団法人", "一般財団法人", "公益財団法人", "公益社団法人",
    "国立研究開発法人", "独立行政法人", "地方独立行政法人",
]
LEGAL_SUFFIXES = ["株式会社", "有限会社", "合同会社"]


def strip_legal(name: str) -> str:
    name = norm(name).strip()
    for p in LEGAL_PREFIXES:
        if name.startswith(p):
            name = name[len(p):].strip()
            break
    for s in LEGAL_SUFFIXES:
        if name.endswith(s):
            name = name[:-len(s)].strip()
            break
    return name


# ─── Task 1: Fix org_type misclassifications ─────────────────────────────────

ORG_TYPE_PATTERNS = [
    (re.compile(r"QPS研究所"),   "民間企業"),
    (re.compile(r"立命館"),      "大学"),
    (re.compile(r"三菱重工業"),  "民間企業"),
]


def fix_org_types(conn: sqlite3.Connection) -> None:
    print("=== 1. Fix org_type ===")
    rows = conn.execute("SELECT id, org_name, org_type FROM organizations").fetchall()
    fixed = 0
    for oid, name, otype in rows:
        name_n = norm(name)
        for pat, new_type in ORG_TYPE_PATTERNS:
            if pat.search(name_n) and otype != new_type:
                conn.execute("UPDATE organizations SET org_type=? WHERE id=?", (new_type, oid))
                print(f"  {name!r}: {otype!r} → {new_type!r}")
                fixed += 1
                break
    conn.commit()
    print(f"  → {fixed} rows updated")


# ─── Task 2: Deduplicate org names ───────────────────────────────────────────

def deduplicate_orgs(conn: sqlite3.Connection) -> None:
    """
    For each theme, group orgs by (NFKC_normalized, strip_legal(name)).
    Keep the most-canonical name (prefer already-normalized, then longest),
    delete duplicates, update research_tasks references.
    """
    print("\n=== 2. Deduplicate org names ===")
    rows = conn.execute(
        "SELECT id, theme_id, org_name FROM organizations ORDER BY theme_id, org_name"
    ).fetchall()

    # Group: (theme_id, dedup_key) → [(id, name), ...]
    groups: dict[tuple, list] = defaultdict(list)
    for oid, tid, name in rows:
        # Key = NFKC normalized then legal stripped
        key = strip_legal(norm(name))
        if not key:
            key = norm(name)
        groups[(tid, key)].append((oid, name))

    merged = 0
    for (tid, key), entries in groups.items():
        if len(entries) < 2:
            continue
        # Canonical: prefer the already-NFKC-clean name; among those, prefer longest
        def score(entry):
            oid, name = entry
            n = norm(name)
            is_clean = (n == name)      # already normalized
            has_legal = any(name.startswith(p) for p in LEGAL_PREFIXES) or \
                        any(name.endswith(s) for s in LEGAL_SUFFIXES)
            return (is_clean, has_legal, len(name))

        entries_sorted = sorted(entries, key=score, reverse=True)
        canonical_id, canonical_name = entries_sorted[0]

        for oid, name in entries_sorted[1:]:
            if name == canonical_name:
                continue
            # Update research_tasks references
            rt_n = conn.execute(
                "UPDATE research_tasks SET org_name=? WHERE theme_id=? AND org_name=?",
                (canonical_name, tid, name),
            ).rowcount
            # Delete duplicate org entry
            conn.execute("DELETE FROM organizations WHERE id=?", (oid,))
            print(f"  [{tid}] {name!r} → {canonical_name!r}"
                  + (f"  (rt:{rt_n})" if rt_n else ""))
            merged += 1

    conn.commit()
    print(f"  → {merged} duplicates removed")


# ─── Task 3: Overview PDF page numbers ───────────────────────────────────────

def load_theme_map(conn: sqlite3.Connection) -> dict[str, str]:
    rows = conn.execute("SELECT theme_id, theme_name FROM themes").fetchall()
    result: dict[str, str] = {}
    for tid, name in rows:
        if name:
            k = fuzzy(name)
            result[k] = tid
            k2 = re.sub(r"\(?[総文経内]\w+省?\)?\s*$", "", k).rstrip()
            if k2 and k2 != k:
                result[k2] = tid
    return result


def find_theme_id(raw_name: str, theme_map: dict[str, str]) -> str | None:
    key = fuzzy(raw_name)
    k2 = re.sub(r"\(?[総文経内]\w+省?\)?\s*$", "", key).rstrip()
    for k in (k2, key):
        if k in theme_map:
            return theme_map[k]
    best, best_len = None, 0
    for k, tid in theme_map.items():
        if len(k) >= 6 and (k in (k2 or key) or (k2 or key) in k):
            if len(k) > best_len:
                best_len, best = len(k), tid
    return best


def extract_theme_pages(pdf_path: Path, theme_map: dict[str, str]) -> dict[str, int]:
    """Scan page-by-page; return {theme_id: first_page_number}."""
    results: dict[str, int] = {}
    with open(pdf_path, "rb") as f:
        for page_num, page_layout in enumerate(extract_pages(f, laparams=LAPARAMS), start=1):
            page_text = ""
            for element in page_layout:
                if isinstance(element, LTTextContainer):
                    page_text += element.get_text()
            page_text = norm(page_text)
            for line in page_text.splitlines():
                if "【" not in line:
                    continue
                m = RE_HEADER.match(line.strip())
                if not m:
                    continue
                raw_name = m.group(1).strip()
                if len(raw_name) < 8 or "億円" in raw_name:
                    continue
                tid = find_theme_id(raw_name, theme_map)
                if tid and tid not in results:
                    results[tid] = page_num
    return results


def fill_overview_pages(conn: sqlite3.Connection) -> None:
    print("\n=== 3. Overview PDF page numbers ===")
    # Add columns if missing
    for col in ("overview_pdf_url TEXT", "overview_pdf_page INTEGER"):
        try:
            conn.execute(f"ALTER TABLE themes ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass
    conn.commit()

    theme_map = load_theme_map(conn)

    for pdf_path, pdf_url, period in OVERVIEW_PDFS:
        if not pdf_path.exists():
            print(f"  MISSING: {pdf_path.name}")
            continue
        print(f"  Scanning {pdf_path.name} ({period}) ...", flush=True)
        pages = extract_theme_pages(pdf_path, theme_map)
        print(f"    → matched {len(pages)} themes")
        set_cnt = 0
        for tid, page in sorted(pages.items(), key=lambda x: x[1]):
            cur = conn.execute(
                "SELECT overview_pdf_page FROM themes WHERE theme_id=?", (tid,)
            ).fetchone()
            if cur and cur[0] is not None:
                continue  # already set (from earlier period PDF)
            conn.execute(
                "UPDATE themes SET overview_pdf_url=?, overview_pdf_page=? WHERE theme_id=?",
                (pdf_url, page, tid),
            )
            print(f"    p{page:3d}: {tid}")
            set_cnt += 1
        conn.commit()
        print(f"    → set {set_cnt} themes")


# ─── Task 4: Result PDF URL + page (from techlist + detail HTML) ──────────────

def _cache_path(url: str) -> Path:
    parsed = urlparse(url)
    safe = (parsed.netloc + parsed.path).replace("/", "_").replace(".", "_")
    safe = re.sub(r"[^\w\-]", "_", safe)[:180]
    return CACHE_DIR / (safe + ".html")


def fill_result_pdf_urls(conn: sqlite3.Connection) -> None:
    print("\n=== 4. Result PDF URLs ===")
    for col in ("result_pdf_url TEXT", "result_pdf_page INTEGER"):
        try:
            conn.execute(f"ALTER TABLE themes ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass
    conn.commit()

    # Source 1: techlist cached HTML (most complete)
    techlist_cache = CACHE_DIR / "fund_jaxa_jp_techlist_.html"
    if techlist_cache.exists():
        html = techlist_cache.read_text(encoding="utf-8")
        soup = BeautifulSoup(html, "lxml")
        found = 0
        for li in soup.find_all("li", class_="p-theme_item"):
            result_p = li.find("p", class_="p-theme_item_result")
            if not result_p:
                continue
            result_a = result_p.find("a", class_="p-theme_item_link")
            if not result_a:
                continue
            href = result_a.get("href", "")
            if not href:
                continue
            kekka_url = href if href.startswith("http") else urljoin(BASE_URL, href)
            if "kekka" not in kekka_url.lower():
                continue

            detail_a = li.find("a", class_="p-theme_item_detail")
            if not detail_a:
                continue
            detail_href = detail_a.get("href", "")
            m = re.search(r"/techlist/([^/]+)/?$", detail_href)
            if not m:
                continue
            tid = m.group(1)

            # Skip theme21-2 (merged into theme21; keep theme21's own kekka URL)
            if tid == "theme21-2":
                continue

            cur = conn.execute(
                "SELECT result_pdf_url FROM themes WHERE theme_id=?", (tid,)
            ).fetchone()
            if cur and cur[0]:
                continue  # already set
            if not conn.execute("SELECT 1 FROM themes WHERE theme_id=?", (tid,)).fetchone():
                continue  # not in DB (e.g. theme21-2 was deleted)

            conn.execute(
                "UPDATE themes SET result_pdf_url=?, result_pdf_page=1 WHERE theme_id=?",
                (kekka_url, tid),
            )
            print(f"  {tid}: {kekka_url}")
            found += 1
        conn.commit()
        print(f"  → {found} URLs added from techlist")

    # Source 2: individual detail pages (fallback for any missed)
    themes = conn.execute(
        "SELECT theme_id, detail_url FROM themes "
        "WHERE period IN ('第一期','第二期') AND result_pdf_url IS NULL"
    ).fetchall()
    found2 = 0
    for tid, detail_url in themes:
        if not detail_url:
            continue
        cache = _cache_path(detail_url)
        if not cache.exists():
            continue
        html = cache.read_text(encoding="utf-8", errors="replace")
        soup2 = BeautifulSoup(html, "lxml")
        for a in soup2.find_all("a", href=True):
            href = a["href"]
            if "kekka" in href.lower() and href.lower().endswith(".pdf"):
                kekka_url = href if href.startswith("http") else urljoin(BASE_URL, href)
                conn.execute(
                    "UPDATE themes SET result_pdf_url=?, result_pdf_page=1 WHERE theme_id=?",
                    (kekka_url, tid),
                )
                print(f"  {tid} (detail): {kekka_url}")
                found2 += 1
                break
    conn.commit()
    if found2:
        print(f"  → {found2} additional URLs from detail pages")


# ─── Report ───────────────────────────────────────────────────────────────────

def report(conn: sqlite3.Connection) -> None:
    print("\n=== Final Summary ===")
    orgs = conn.execute("SELECT COUNT(*) FROM organizations").fetchone()[0]
    tasks = conn.execute("SELECT COUNT(*) FROM research_tasks").fetchone()[0]
    print(f"  organizations: {orgs}")
    print(f"  research_tasks: {tasks}")

    with_ov = conn.execute(
        "SELECT COUNT(*) FROM themes WHERE overview_pdf_page IS NOT NULL"
    ).fetchone()[0]
    with_res = conn.execute(
        "SELECT COUNT(*) FROM themes WHERE result_pdf_url IS NOT NULL"
    ).fetchone()[0]
    total = conn.execute("SELECT COUNT(*) FROM themes").fetchone()[0]
    print(f"  themes with overview_pdf_page: {with_ov}/{total}")
    print(f"  themes with result_pdf_url:    {with_res}/{total}")

    print("\n  Sample overview pages:")
    for r in conn.execute(
        "SELECT theme_id, period, overview_pdf_page FROM themes "
        "WHERE overview_pdf_page IS NOT NULL ORDER BY period, overview_pdf_page LIMIT 12"
    ).fetchall():
        print(f"    {r[0]:<14} [{r[1]}] p{r[2]}")

    no_ov = conn.execute(
        "SELECT theme_id, period FROM themes WHERE overview_pdf_page IS NULL "
        "AND period IN ('第一期','第二期','第三期') ORDER BY period, theme_id"
    ).fetchall()
    if no_ov:
        print(f"\n  Themes WITHOUT overview_pdf_page ({len(no_ov)}):")
        for r in no_ov:
            print(f"    {r[0]} [{r[1]}]")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    fix_org_types(conn)
    deduplicate_orgs(conn)
    fill_overview_pages(conn)
    fill_result_pdf_urls(conn)

    report(conn)

    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
