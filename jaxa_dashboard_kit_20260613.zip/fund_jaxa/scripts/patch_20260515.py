"""
2026-05-15 DB patch:
  1. Normalize abbreviated org names in theme21 → full legal names
  2. Register theme2_22 budget details (A/B/C sub_themes)
"""
import io
import sqlite3
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DB_PATH = Path(__file__).parent.parent / "data" / "fund_jaxa.db"

# Abbreviated name → canonical full name already in organizations for theme21.
# Strategy: DELETE the abbreviated entry (full-name entry already exists).
ORG_NAME_FIXES = [
    ("NECスペーステクノロジー",          "NECスペーステクノロジー株式会社"),
    ("コンポジットテーラーズ",            "コンポジットテーラーズ株式会社"),
    ("シャープエネルギーソリューション",   "シャープエネルギーソリューション株式会社"),
    ("三菱電機",                         "三菱電機株式会社"),
    # ジーエス・ユアサ: missing the space after 株式会社
    ("株式会社ジーエス・ユアサ テクノロジー", "株式会社 ジーエス・ユアサ テクノロジー"),
    # INDUSTRIAL-X: fullwidth → halfwidth
    ("株式会社ＩＮＤＵＳＴＲＩＡＬ－Ｘ",   "株式会社INDUSTRIAL-X"),
    # NU-Rei: halfwidth short form
    ("NU-Rei",                           "ＮＵ－Ｒｅｉ株式会社"),
]


def fix_org_names(conn: sqlite3.Connection) -> None:
    print("=== 1. Normalize abbreviated org names (theme21) ===")
    for abbrev, canonical in ORG_NAME_FIXES:
        exists_abbrev = conn.execute(
            "SELECT 1 FROM organizations WHERE theme_id='theme21' AND org_name=?",
            (abbrev,),
        ).fetchone()
        if not exists_abbrev:
            print(f"  SKIP (not found): {abbrev}")
            continue

        exists_canonical = conn.execute(
            "SELECT 1 FROM organizations WHERE theme_id='theme21' AND org_name=?",
            (canonical,),
        ).fetchone()

        if exists_canonical:
            # Full-name entry already present → just delete the abbreviated one
            conn.execute(
                "DELETE FROM organizations WHERE theme_id='theme21' AND org_name=?",
                (abbrev,),
            )
            print(f"  DELETE dup: {abbrev!r}")
        else:
            # No canonical entry → rename abbreviated to canonical
            conn.execute(
                "UPDATE organizations SET org_name=? "
                "WHERE theme_id='theme21' AND org_name=?",
                (canonical, abbrev),
            )
            print(f"  RENAME: {abbrev!r} → {canonical!r}")


def patch_theme2_22(conn: sqlite3.Connection) -> None:
    """
    theme2_22: 衛星データ利用システム実装加速化事業  total=176億
    (A) 補助: 0.15〜20億円/件、30件程度
    (B) 委託（海外）: ASEAN 10億/1件、中東 6億/1件、インド 3億/1件、その他 3億/2件 → 計5〜6件
    (C) 委託（環境整備）: 10〜30億円/件、上限総額30億円、1〜3件程度
    """
    print("\n=== 2. Register theme2_22 sub_theme budgets ===")

    # Update parent '' row: raw_text summary
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_22' AND sub_theme=''",
        (
            "支援総額最大176億円程度。"
            "(A)補助:0.15〜20億円/件,30件程度; "
            "(B)委託(海外):ASEAN10億/1件,中東6億/1件,インド3億/1件,その他3億/2件,計5〜6件; "
            "(C)委託(環境整備):10〜30億円/件,上限総額30億円,1〜3件程度",
        ),
    )
    print("  UPDATE theme2_22[''] raw_text")

    sub_rows = [
        # (sub_theme, total, per_max, cases, raw_text)
        (
            "A",
            None,
            20.0,
            30,
            "(A) 補助: 1件あたり0.15億〜20億円上限、30件程度",
        ),
        (
            "B",
            None,
            10.0,   # ASEAN案件が最大10億円、全体は上限10億
            5,      # 5〜6件の下限
            "(B) 委託（海外）: ASEAN10億以下/1件、中東6億/1件、インド3億/1件、その他3億/2件、計5〜6件",
        ),
        (
            "C",
            30.0,   # 上限総額30億円
            30.0,   # 1件あたり上限30億円
            1,      # 1〜3件の下限
            "(C) 委託（環境整備）: 10〜30億円/件、上限総額30億円、1〜3件程度",
        ),
    ]

    for sub, total, per, cases, raw in sub_rows:
        existing = conn.execute(
            "SELECT 1 FROM theme_budgets WHERE theme_id='theme2_22' AND sub_theme=?",
            (sub,),
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE theme_budgets SET total_budget_oku=?, max_per_case_oku=?, "
                "expected_cases=?, raw_text=? "
                "WHERE theme_id='theme2_22' AND sub_theme=?",
                (total, per, cases, raw, sub),
            )
            print(f"  UPDATE theme2_22[{sub}]  total={total} per={per} cases={cases}")
        else:
            conn.execute(
                "INSERT INTO theme_budgets(theme_id, sub_theme, total_budget_oku, "
                "max_per_case_oku, expected_cases, raw_text) VALUES(?,?,?,?,?,?)",
                ("theme2_22", sub, total, per, cases, raw),
            )
            print(f"  INSERT theme2_22[{sub}]  total={total} per={per} cases={cases}")

    conn.commit()


def report(conn: sqlite3.Connection) -> None:
    print("\n=== Report: theme21 organizations ===")
    for (name, otype) in conn.execute(
        "SELECT org_name, org_type FROM organizations WHERE theme_id='theme21' ORDER BY org_name"
    ).fetchall():
        print(f"  {name} ({otype})")

    print("\n=== Report: theme2_22 budgets ===")
    for r in conn.execute(
        "SELECT sub_theme, total_budget_oku, max_per_case_oku, expected_cases, raw_text "
        "FROM theme_budgets WHERE theme_id='theme2_22' ORDER BY sub_theme"
    ).fetchall():
        sub, tot, per, cas, raw = r
        print(f"  [{sub}] total={tot} per={per} cases={cas}")
        if raw:
            print(f"        {raw[:80]}")


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")

    fix_org_names(conn)
    patch_theme2_22(conn)

    report(conn)

    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
