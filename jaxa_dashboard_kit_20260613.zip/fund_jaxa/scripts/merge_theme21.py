"""
Merge theme21-2 into theme21.

Actions:
  1. Add theme_budgets sub_theme='追加公募A' and '追加公募B' to theme21
  2. Re-assign organizations from theme21-2 → theme21
     (skip exact-name duplicates; keep abbreviated names as-is)
  3. Re-assign research_tasks from theme21-2 → theme21
  4. Delete theme21-2 rows from theme_budgets, organizations, research_tasks, themes
  5. Report final state of theme21
"""
import io
import sqlite3
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DB_PATH = Path(__file__).parent.parent / "data" / "fund_jaxa.db"


def add_additional_call_subthemes(conn: sqlite3.Connection) -> None:
    """Add 追加公募A / 追加公募B sub_theme rows to theme21."""
    print("=== 1. Add 追加公募 sub_themes to theme21 ===")

    rows = [
        # (sub_theme, total, per, cases, raw_text)
        (
            "追加公募A",
            None,
            30.0,
            None,
            "（追加公募）補助: 1件あたり0.5億〜30億円上限"
            "（大企業）/ 0.6億〜30億円上限（中小・SU）、5〜10件程度",
        ),
        (
            "追加公募B",
            None,
            30.0,
            2,
            "（追加公募）委託: 1件あたり1億〜30億円上限、2件程度",
        ),
    ]

    for sub, total, per, cases, raw in rows:
        existing = conn.execute(
            "SELECT 1 FROM theme_budgets WHERE theme_id='theme21' AND sub_theme=?",
            (sub,),
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE theme_budgets SET total_budget_oku=?, max_per_case_oku=?, "
                "expected_cases=?, raw_text=? "
                "WHERE theme_id='theme21' AND sub_theme=?",
                (total, per, cases, raw, sub),
            )
            print(f"  UPDATE theme21[{sub}]")
        else:
            conn.execute(
                "INSERT INTO theme_budgets(theme_id, sub_theme, total_budget_oku, "
                "max_per_case_oku, expected_cases, raw_text) VALUES(?,?,?,?,?,?)",
                ("theme21", sub, total, per, cases, raw),
            )
            print(f"  INSERT theme21[{sub}]  per={per} cases={cases}")


def migrate_organizations(conn: sqlite3.Connection) -> None:
    """Re-assign orgs from theme21-2 to theme21, skipping exact-name conflicts."""
    print("\n=== 2. Migrate organizations ===")
    orgs_21_2 = conn.execute(
        "SELECT org_name, is_lead, org_type FROM organizations WHERE theme_id='theme21-2'"
    ).fetchall()

    moved = skipped = 0
    for org_name, is_lead, org_type in orgs_21_2:
        conflict = conn.execute(
            "SELECT 1 FROM organizations WHERE theme_id='theme21' AND org_name=?",
            (org_name,),
        ).fetchone()
        if conflict:
            print(f"  SKIP (duplicate): {org_name}")
            conn.execute(
                "DELETE FROM organizations WHERE theme_id='theme21-2' AND org_name=?",
                (org_name,),
            )
            skipped += 1
        else:
            conn.execute(
                "UPDATE organizations SET theme_id='theme21' "
                "WHERE theme_id='theme21-2' AND org_name=?",
                (org_name,),
            )
            print(f"  MOVED: {org_name}")
            moved += 1

    print(f"  → moved={moved}, skipped={skipped}")


def migrate_research_tasks(conn: sqlite3.Connection) -> None:
    """Re-assign research_tasks from theme21-2 to theme21."""
    print("\n=== 3. Migrate research_tasks ===")
    tasks = conn.execute(
        "SELECT org_name, task_name FROM research_tasks WHERE theme_id='theme21-2'"
    ).fetchall()

    for org, task in tasks:
        conflict = conn.execute(
            "SELECT 1 FROM research_tasks WHERE theme_id='theme21' AND org_name=? AND task_name=?",
            (org, task),
        ).fetchone()
        if conflict:
            print(f"  SKIP (duplicate): {org}")
            conn.execute(
                "DELETE FROM research_tasks WHERE theme_id='theme21-2' AND org_name=? AND task_name=?",
                (org, task),
            )
        else:
            conn.execute(
                "UPDATE research_tasks SET theme_id='theme21' "
                "WHERE theme_id='theme21-2' AND org_name=? AND task_name=?",
                (org, task),
            )
            print(f"  MOVED: [{org}] {task[:50]}")


def delete_theme21_2(conn: sqlite3.Connection) -> None:
    """Delete all remaining theme21-2 records."""
    print("\n=== 4. Delete theme21-2 ===")
    for table in ("theme_budgets", "organizations", "research_tasks"):
        n = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE theme_id='theme21-2'").fetchone()[0]
        conn.execute(f"DELETE FROM {table} WHERE theme_id='theme21-2'")
        print(f"  DELETE {n} rows from {table}")
    conn.execute("DELETE FROM themes WHERE theme_id='theme21-2'")
    print("  DELETE themes WHERE theme_id='theme21-2'")


def report(conn: sqlite3.Connection) -> None:
    print("\n=== Final state: theme21 ===")
    print("\n  theme_budgets:")
    for r in conn.execute(
        "SELECT sub_theme, total_budget_oku, max_per_case_oku, expected_cases, raw_text "
        "FROM theme_budgets WHERE theme_id='theme21' ORDER BY sub_theme"
    ).fetchall():
        sub, tot, per, cas, raw = r
        print(f"    [{sub}] total={tot} per={per} cases={cas}")
        if raw:
            print(f"          {raw[:70]}")

    print("\n  organizations:")
    for r in conn.execute(
        "SELECT org_name, org_type FROM organizations WHERE theme_id='theme21' ORDER BY org_name"
    ).fetchall():
        print(f"    {r[0]} ({r[1]})")

    print("\n  research_tasks:")
    for r in conn.execute(
        "SELECT org_name, task_name FROM research_tasks WHERE theme_id='theme21' ORDER BY org_name"
    ).fetchall():
        print(f"    [{r[0]}] {r[1][:55]}")

    leftover = conn.execute(
        "SELECT COUNT(*) FROM themes WHERE theme_id='theme21-2'"
    ).fetchone()[0]
    print(f"\n  theme21-2 in themes: {leftover} (expect 0)")


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")

    add_additional_call_subthemes(conn)
    migrate_organizations(conn)
    migrate_research_tasks(conn)
    delete_theme21_2(conn)

    conn.commit()
    report(conn)

    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
