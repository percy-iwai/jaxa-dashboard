"""
2026-05-14 budget patch:
  1. theme17 A/B: add subtheme detail names to raw_text
  2. theme2_11: add cases & subtheme descriptions (total=165億 already set)
  3. theme21-2: add A record, update B per_case=30億
  4. theme4-2: fill total=64億 and cases=1
"""
import io
import sqlite3
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

DB_PATH = Path(__file__).parent.parent / "data" / "fund_jaxa.db"


def patch(conn: sqlite3.Connection) -> None:
    # ------------------------------------------------------------------
    # 1. theme17 A/B: store subtheme detail names in raw_text
    # ------------------------------------------------------------------
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme17' AND sub_theme='A'",
        ("複数の商業宇宙ステーションへの自在な接近を可能とする近傍通信システム技術等の物資補給システム技術 "
         "（1件あたり125億円上限、1件程度）",),
    )
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme17' AND sub_theme='B'",
        ("商業物資補給機と商業宇宙ステーションのドッキングシステムの検証技術 "
         "（1件あたり30億円上限、1件程度）",),
    )
    print("theme17 A/B raw_text updated")

    # ------------------------------------------------------------------
    # 2. theme2_11 (空間自在利用の実現に向けた技術) — 165億総額
    #    既存レコード: '' total=165, A per=50, A-1 per=50, B per=15, C per=20
    # ------------------------------------------------------------------
    # Parent row: raw_text with full breakdown
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_11' AND sub_theme=''",
        ("支援総額165億円。(A)軌道上製造・組立技術:50億円/件,A-1+A-2合計2〜3件; "
         "(B)軌道上物体除去技術:15億円/件,1〜2件; (C)宇宙状況把握技術:20億円/件,1〜2件",),
    )
    # A: subtheme label + description
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_11' AND sub_theme='A'",
        ("(A) 軌道上製造・組立技術: 1件あたり50億円上限、A-1+A-2合わせて2〜3件程度",),
    )
    # A-1: already exists (per=50 from original fetch)
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_11' AND sub_theme='A-1'",
        ("A-1: 軌道上製造・組立技術（Aサブカテゴリ）1件あたり50億円上限",),
    )
    # B: description
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_11' AND sub_theme='B'",
        ("(B) 軌道上物体除去技術: 1件あたり15億円上限、1〜2件程度",),
    )
    # C: description
    conn.execute(
        "UPDATE theme_budgets SET raw_text=? WHERE theme_id='theme2_11' AND sub_theme='C'",
        ("(C) 宇宙状況把握技術: 1件あたり20億円上限、1〜2件程度",),
    )
    print("theme2_11 raw_text updated (5 rows)")

    # ------------------------------------------------------------------
    # 3. theme21-2 (（追加公募）衛星サプライチェーン構築のための衛星部品・コンポーネント)
    #    (A) 補助: 1件あたり0.5〜30億円, 5〜10件程度
    #    (B) 委託: 1件あたり1〜30億円,    2件程度
    #    上限30億円で登録
    # ------------------------------------------------------------------
    # Parent '' row (overview information)
    exists_parent = conn.execute(
        "SELECT 1 FROM theme_budgets WHERE theme_id='theme21-2' AND sub_theme=''"
    ).fetchone()
    if not exists_parent:
        conn.execute(
            "INSERT INTO theme_budgets(theme_id,sub_theme,total_budget_oku,max_per_case_oku,"
            "expected_cases,raw_text) VALUES(?,?,?,?,?,?)",
            ("theme21-2", "", None, 30.0, None,
             "(A)補助:0.5〜30億円/件,5〜10件; (B)委託:1〜30億円/件,2件"),
        )
        print("theme21-2 '' inserted")
    else:
        conn.execute(
            "UPDATE theme_budgets SET max_per_case_oku=30.0, "
            "raw_text='(A)補助:0.5〜30億円/件,5〜10件; (B)委託:1〜30億円/件,2件' "
            "WHERE theme_id='theme21-2' AND sub_theme=''",
        )
        print("theme21-2 '' updated")

    # (A) row
    exists_a = conn.execute(
        "SELECT 1 FROM theme_budgets WHERE theme_id='theme21-2' AND sub_theme='A'"
    ).fetchone()
    if not exists_a:
        conn.execute(
            "INSERT INTO theme_budgets(theme_id,sub_theme,total_budget_oku,max_per_case_oku,"
            "expected_cases,raw_text) VALUES(?,?,?,?,?,?)",
            ("theme21-2", "A", None, 30.0, None,
             "補助: 1件あたり0.5億〜30億円（大企業/中小・SU）、5〜10件程度"),
        )
        print("theme21-2 A inserted")
    else:
        conn.execute(
            "UPDATE theme_budgets SET max_per_case_oku=30.0, "
            "raw_text='補助: 1件あたり0.5億〜30億円（大企業/中小・SU）、5〜10件程度' "
            "WHERE theme_id='theme21-2' AND sub_theme='A'",
        )
        print("theme21-2 A updated")

    # (B) row: already has cases=2, fill per_case=30
    conn.execute(
        "UPDATE theme_budgets SET max_per_case_oku=30.0, "
        "raw_text='委託: 1件あたり1億〜30億円委託総額、2件程度' "
        "WHERE theme_id='theme21-2' AND sub_theme='B'",
    )
    print("theme21-2 B updated (per=30億)")

    # ------------------------------------------------------------------
    # 4. theme4-2 (（再公募）月面の水資源探査技術（センシング技術）)
    #    1件あたり64億円上限、1件程度採択
    # ------------------------------------------------------------------
    conn.execute(
        "UPDATE theme_budgets SET total_budget_oku=64.0, expected_cases=1, "
        "raw_text='再公募: 1件あたり64億円程度上限、1件採択、最長4年（委託）' "
        "WHERE theme_id='theme4-2' AND sub_theme=''",
    )
    print("theme4-2 '' updated (total=64億, cases=1)")

    conn.commit()


def report(conn: sqlite3.Connection) -> None:
    print("\n=== Updated records ===")
    for tid in ("theme17", "theme2_11", "theme21-2", "theme4-2"):
        rows = conn.execute(
            "SELECT sub_theme, total_budget_oku, max_per_case_oku, expected_cases, raw_text "
            "FROM theme_budgets WHERE theme_id=? ORDER BY sub_theme",
            (tid,),
        ).fetchall()
        print(f"\n{tid}:")
        for r in rows:
            sub, tot, per, cas, raw = r
            print(f"  [{sub}] total={tot} per={per} cases={cas}")
            if raw:
                print(f"         raw_text={raw[:80]}")


def main() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    patch(conn)
    report(conn)
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
