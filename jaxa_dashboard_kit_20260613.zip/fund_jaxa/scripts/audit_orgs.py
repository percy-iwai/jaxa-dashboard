#!/usr/bin/env python3
"""
audit_orgs.py — JAXA宇宙戦略基金 組織・研究課題 監査・補完スクリプト

各Phase 1/2テーマのキャッシュHTMLからkekka PDFリンクを収集し、
PDFパース結果とDBを比較して不足エントリを挿入する。

Usage:
    python fund_jaxa/scripts/audit_orgs.py [--fetch-missing]

    --fetch-missing: キャッシュにないPDFをネットから取得する（デフォルト: スキップ）
"""
import argparse
import io
import sys
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urljoin

# Windows cp932コンソールでも日本語出力できるように UTF-8 に強制
if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "buffer"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# fetch_fund_jaxa のユーティリティを再利用
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))
from fetch_fund_jaxa import (
    BASE_URL,
    CACHE_DIR,
    PDF_DIR,
    DB_PATH,
    _url_to_cache_path,
    _classify_org,
    extract_pdf_text,
    parse_kekka_pdf,
    fetch_pdf,
    get_conn,
    init_db,
    upsert_org,
    upsert_research_task,
)

from bs4 import BeautifulSoup


# ── 対象テーマ（Phase 1 & 2）────────────────────────────────────────────────
PHASE1_THEMES = [
    "theme1", "theme2", "theme3", "theme4", "theme4-2",
    "theme5", "theme6", "theme7", "theme8", "theme9",
    "theme10", "theme11", "theme12", "theme13", "theme14",
    "theme15", "theme16", "theme17", "theme18", "theme19",
    "theme20", "theme21", "theme22",
]

PHASE2_THEMES = [
    "theme2_1", "theme2_2", "theme2_3", "theme2_4", "theme2_5",
    "theme2_6", "theme2_7", "theme2_8", "theme2_9", "theme2_10",
    "theme2_11", "theme2_12", "theme2_13", "theme2_14", "theme2_15",
    "theme2_16", "theme2_17", "theme2_18", "theme2_19", "theme2_20",
    "theme2_21", "theme2_22", "theme2_23", "theme2_24",
]

ALL_THEMES = PHASE1_THEMES + PHASE2_THEMES


# ── HTML キャッシュ読み込み ──────────────────────────────────────────────────
def load_html_cache(theme_id: str) -> Optional[str]:
    """theme_id に対応するキャッシュ HTML を返す"""
    url = f"{BASE_URL}/techlist/{theme_id}/"
    cache_path = _url_to_cache_path(url, ".html")
    if cache_path.exists():
        return cache_path.read_text(encoding="utf-8")
    # フォールバック: キャッシュファイル名を直接構築
    fname = f"fund_jaxa_jp_techlist_{theme_id}_.html"
    alt = CACHE_DIR / fname
    if alt.exists():
        return alt.read_text(encoding="utf-8")
    return None


# ── HTML から kekka PDF リンクを収集 ────────────────────────────────────────
def extract_kekka_links(html: str) -> List[str]:
    """HTML ページからすべての採択結果 PDF URL を返す"""
    soup = BeautifulSoup(html, "lxml")
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "kekka" in href.lower() and href.lower().endswith(".pdf"):
            full_url = urljoin(BASE_URL, href)
            if full_url not in links:
                links.append(full_url)
    return links


# ── PDF から研究課題レコードを収集 ──────────────────────────────────────────
def collect_pdf_records(
    theme_id: str,
    kekka_urls: List[str],
    fetch_missing: bool = False,
) -> List[Dict]:
    """kekka PDF をパースして研究課題レコードを返す"""
    all_records: List[Dict] = []
    for url in kekka_urls:
        pdf_path = _url_to_cache_path(url, ".pdf")
        if not pdf_path.exists():
            if fetch_missing:
                data = fetch_pdf(url)
                if not data:
                    continue
            else:
                continue  # キャッシュなし・フェッチ無効 → スキップ

        pdf_bytes = pdf_path.read_bytes()
        text = extract_pdf_text(pdf_bytes)
        if not text.strip():
            continue

        # 採択者なし
        if "採択者なし" in text or "採択なし" in text:
            # no-adoption mark — return empty sentinel so caller knows we checked
            all_records.append({"_no_adoption": True, "_url": url})
            continue

        records = parse_kekka_pdf(theme_id, text)
        all_records.extend(records)

    return all_records


# ── DB の現在カウントを取得 ──────────────────────────────────────────────────
def get_db_counts(conn) -> Dict[str, Dict]:
    """theme_id → {orgs, tasks} マップを返す"""
    result: Dict[str, Dict] = {}
    for row in conn.execute("""
        SELECT t.theme_id,
               COUNT(DISTINCT o.id)  AS orgs_count,
               COUNT(DISTINCT rt.id) AS tasks_count
        FROM themes t
        LEFT JOIN organizations  o  ON o.theme_id  = t.theme_id
        LEFT JOIN research_tasks rt ON rt.theme_id = t.theme_id
        WHERE t.period IN ('第一期', '第二期')
        GROUP BY t.theme_id
    """):
        result[row[0]] = {"orgs": row[1], "tasks": row[2]}
    return result


# ── メイン ──────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="JAXA fund org/task audit")
    parser.add_argument("--fetch-missing", action="store_true",
                        help="キャッシュにないPDFをネットから取得する")
    args = parser.parse_args()

    conn = get_conn()
    init_db(conn)

    # ── BEFORE 状態を記録 ──
    before = get_db_counts(conn)

    print("=" * 72)
    print("JAXA 宇宙戦略基金 組織・研究課題 監査")
    print("=" * 72)
    print(f"{'theme_id':14} {'期別':6} {'orgs_b':>6} {'tasks_b':>7} "
          f"{'pdf_recs':>8} {'orgs_a':>6} {'tasks_a':>7} {'status'}")
    print("-" * 72)

    added_orgs_total  = 0
    added_tasks_total = 0
    no_adoption_themes: List[str] = []
    no_html_themes: List[str] = []
    no_pdf_themes: List[str] = []
    theme_results: List[Dict] = []

    for theme_id in ALL_THEMES:
        period = "第一期" if theme_id in PHASE1_THEMES else "第二期"
        before_orgs  = before.get(theme_id, {}).get("orgs",  0)
        before_tasks = before.get(theme_id, {}).get("tasks", 0)

        # 1. HTML キャッシュ読み込み
        html = load_html_cache(theme_id)
        if not html:
            no_html_themes.append(theme_id)
            status = "NO_HTML"
            theme_results.append({
                "theme_id": theme_id, "period": period,
                "orgs_b": before_orgs, "tasks_b": before_tasks,
                "pdf_recs": 0, "orgs_a": before_orgs, "tasks_a": before_tasks,
                "status": status,
            })
            print(f"{theme_id:14} {period:6} {before_orgs:6} {before_tasks:7} "
                  f"{'':8} {'':6} {'':7} {status}")
            continue

        # 2. kekka PDF リンク収集
        kekka_urls = extract_kekka_links(html)
        if not kekka_urls:
            no_pdf_themes.append(theme_id)
            status = "NO_KEKKA_LINK"
            theme_results.append({
                "theme_id": theme_id, "period": period,
                "orgs_b": before_orgs, "tasks_b": before_tasks,
                "pdf_recs": 0, "orgs_a": before_orgs, "tasks_a": before_tasks,
                "status": status,
            })
            print(f"{theme_id:14} {period:6} {before_orgs:6} {before_tasks:7} "
                  f"{'':8} {'':6} {'':7} {status}")
            continue

        # 3. PDF パース
        records = collect_pdf_records(theme_id, kekka_urls,
                                      fetch_missing=args.fetch_missing)

        # 採択者なし？
        no_adoption_records = [r for r in records if r.get("_no_adoption")]
        task_records        = [r for r in records if not r.get("_no_adoption")]

        if not task_records and no_adoption_records:
            no_adoption_themes.append(theme_id)
            status = "NO_ADOPTION"
            theme_results.append({
                "theme_id": theme_id, "period": period,
                "orgs_b": before_orgs, "tasks_b": before_tasks,
                "pdf_recs": 0, "orgs_a": before_orgs, "tasks_a": before_tasks,
                "status": status,
            })
            print(f"{theme_id:14} {period:6} {before_orgs:6} {before_tasks:7} "
                  f"{0:8} {'':6} {'':7} {status}")
            continue

        if not task_records:
            # PDFs not cached and fetch disabled, or no '実施機関名' lines
            skipped_urls = [u for u in kekka_urls
                            if not _url_to_cache_path(u, ".pdf").exists()]
            if skipped_urls:
                status = f"PDF_NOT_CACHED({len(skipped_urls)})"
            else:
                status = "PDF_PARSE_EMPTY"
            theme_results.append({
                "theme_id": theme_id, "period": period,
                "orgs_b": before_orgs, "tasks_b": before_tasks,
                "pdf_recs": 0, "orgs_a": before_orgs, "tasks_a": before_tasks,
                "status": status,
            })
            print(f"{theme_id:14} {period:6} {before_orgs:6} {before_tasks:7} "
                  f"{0:8} {'':6} {'':7} {status}")
            continue

        # 4. DB に挿入（upsert）
        added_orgs  = 0
        added_tasks = 0
        for rec in task_records:
            org_name  = rec["org_name"]
            task_name = rec["task_name"]
            if not org_name or not task_name:
                continue

            # org upsert — check if it was new
            cur = conn.execute(
                "SELECT id FROM organizations WHERE theme_id=? AND org_name=?",
                (theme_id, org_name.strip())
            ).fetchone()
            if cur is None:
                upsert_org(conn, theme_id, org_name,
                           is_lead=None, org_type=_classify_org(org_name))
                added_orgs += 1

            # task upsert — check if it was new
            cur2 = conn.execute(
                "SELECT id FROM research_tasks WHERE theme_id=? AND org_name=? AND task_name=?",
                (theme_id, org_name.strip(), task_name.strip())
            ).fetchone()
            if cur2 is None:
                upsert_research_task(
                    conn, theme_id, org_name, task_name,
                    rec.get("task_overview"),
                    rec.get("committee_type"),
                    rec.get("subsidy_rate"),
                    rec.get("period_start"),
                    rec.get("period_end"),
                )
                added_tasks += 1

        conn.commit()

        # After counts
        after_row = conn.execute("""
            SELECT COUNT(DISTINCT o.id)  AS orgs_count,
                   COUNT(DISTINCT rt.id) AS tasks_count
            FROM themes t
            LEFT JOIN organizations  o  ON o.theme_id  = t.theme_id
            LEFT JOIN research_tasks rt ON rt.theme_id = t.theme_id
            WHERE t.theme_id = ?
        """, (theme_id,)).fetchone()
        after_orgs  = after_row[0] if after_row else before_orgs
        after_tasks = after_row[1] if after_row else before_tasks

        added_orgs_total  += added_orgs
        added_tasks_total += added_tasks

        # Status
        pdf_count = len(task_records)
        if added_orgs > 0 or added_tasks > 0:
            status = f"ADDED(orgs+{added_orgs} tasks+{added_tasks})"
        elif after_orgs == after_tasks or after_tasks > after_orgs:
            # tasks >= orgs is fine (one org can have multiple tasks)
            status = "OK"
        else:
            status = "DISCREPANCY"

        theme_results.append({
            "theme_id": theme_id, "period": period,
            "orgs_b": before_orgs, "tasks_b": before_tasks,
            "pdf_recs": pdf_count,
            "orgs_a": after_orgs, "tasks_a": after_tasks,
            "status": status,
        })
        print(f"{theme_id:14} {period:6} {before_orgs:6} {before_tasks:7} "
              f"{pdf_count:8} {after_orgs:6} {after_tasks:7} {status}")

    conn.close()

    # ── SUMMARY ─────────────────────────────────────────────────────────────
    print("=" * 72)
    print(f"合計追加: 組織 +{added_orgs_total}件  研究課題 +{added_tasks_total}件")
    print()

    if no_adoption_themes:
        print(f"採択者なし ({len(no_adoption_themes)} テーマ):")
        for t in no_adoption_themes:
            print(f"  {t}")
        print()

    if no_html_themes:
        print(f"HTMLキャッシュなし ({len(no_html_themes)} テーマ):")
        for t in no_html_themes:
            print(f"  {t}")
        print()

    if no_pdf_themes:
        print(f"kekka PDFリンクなし ({len(no_pdf_themes)} テーマ):")
        for t in no_pdf_themes:
            print(f"  {t}")
        print()

    # Remaining discrepancies
    still_discrepant = [
        r for r in theme_results
        if r["status"] not in ("OK", "NO_ADOPTION", "NO_HTML", "NO_KEKKA_LINK")
        and not r["status"].startswith("ADDED")
    ]
    if still_discrepant:
        print(f"残存不一致 ({len(still_discrepant)} テーマ):")
        for r in still_discrepant:
            print(f"  {r['theme_id']:14} orgs={r['orgs_a']} tasks={r['tasks_a']}  [{r['status']}]")
        print()

    added_themes = [r for r in theme_results if r["status"].startswith("ADDED")]
    if added_themes:
        print(f"データ追加済みテーマ ({len(added_themes)} テーマ):")
        for r in added_themes:
            print(f"  {r['theme_id']:14} {r['status']}")


if __name__ == "__main__":
    main()
