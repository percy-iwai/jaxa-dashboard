"""
汎用パーサー。
HTMLテーブルのヘッダー行から列マッピングを自動推定して解析する。
陸自・海自・航空自衛隊・統幕・その他機関のほとんどに対応。
"""
import re
from typing import List, Dict, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from loguru import logger

from collectors.html_collector import HtmlCollector
from parsers.base_parser import BaseParser

# ヘッダーテキスト → DBカラム名のマッピング候補
HEADER_COL_MAP = {
    "工事名": "contract_name",
    "業務名": "contract_name",
    "品目": "contract_name",
    "件名": "contract_name",
    "契約件名": "contract_name",
    "物件名": "contract_name",
    "役務名": "contract_name",
    "業者名": "vendor_name",
    "契約業者": "vendor_name",
    "受注者": "vendor_name",
    "契約相手方": "vendor_name",
    "落札者": "vendor_name",
    "商号又は名称": "vendor_name",
    "商号及び名称": "vendor_name",
    "商号": "vendor_name",
    "法人番号": "corporate_number",
    "契約金額": "contract_amount",
    "落札金額": "contract_amount",
    "契約金額等": "contract_amount",
    "予定価格": "estimated_price",
    "落札率": "award_rate",
    # 契約締結日（HTML形式・各局の表記ゆれに対応）
    "契約締結日": "contract_date",
    "締結日": "contract_date",
    "契約日": "contract_date",
    # PDF形式（政府調達公表様式）
    "名称及び数量": "contract_name",
    "契約を締結した日": "contract_date",
    "商号又は名称及び住所": "vendor_name",
    "競争入札": "bid_method",
    "工期始": "period_start",
    "工期終": "period_end",
    "着工": "period_start",
    "竣工": "period_end",
    "入札方式": "bid_method",
    "契約方式": "bid_method",
    "入札方法": "bid_method",
}


def _normalize_header_cell(cell: str) -> str:
    """ヘッダーセルのテキストを正規化（スペース・全角スペース・改行を除去）。"""
    return re.sub(r"[\s\u3000\u00a0]+", "", cell)


def _detect_col_map(header_row: List[str]) -> Dict[str, int]:
    """ヘッダー行からDBカラム→列インデックスのマッピングを生成。
    Excel HTML形式の '工 事 名'（スペース入り）にも対応。"""
    col_map = {}
    for idx, cell in enumerate(header_row):
        # 元テキストと正規化テキストの両方でマッチを試みる
        cell_clean = cell.strip()
        cell_norm = _normalize_header_cell(cell_clean)
        for keyword, field in HEADER_COL_MAP.items():
            if (keyword in cell_clean or keyword in cell_norm) and field not in col_map:
                col_map[field] = idx
                break
    return col_map


def _detect_contract_type(url: str, text: str = "") -> str:
    """URLや見出しから契約種別を推定。"""
    combined = url + text
    if "kouji" in combined or "kensetu" in combined or "工事" in combined:
        return "工事"
    if "gyoumu" in combined or "業務" in combined:
        return "業務"
    if "buppin" in combined or "物品" in combined:
        return "物品"
    if "ekimu" in combined or "役務" in combined:
        return "役務"
    return ""


class GenericParser(BaseParser):
    def __init__(self, agency_id: str, agency_name: str, agency_category: str):
        super().__init__(agency_id, agency_name, agency_category)
        self.collector = HtmlCollector(use_cache=True)

    def collect_year(self, top_url: str, fiscal_year: int) -> List[Dict]:
        """
        機関のトップページから年度別リンクを辿り、契約情報を収集する。
        年度別URLが見つからない場合はトップページ自体を解析する。
        """
        records = []
        soup = self.collector.get_soup(top_url)
        if soup is None:
            logger.warning(f"取得失敗: {top_url}")
            return records

        # 年度別リンクを探す
        year_urls = self._find_year_urls(soup, top_url, fiscal_year)

        if year_urls:
            for url in year_urls:
                recs = self._parse_page(url, fiscal_year)
                records.extend(recs)
        else:
            # 年度リンクが見つからない場合はそのまま解析
            recs = self._parse_page(top_url, fiscal_year)
            records.extend(recs)

        return records

    def _find_year_urls(self, soup: BeautifulSoup, base_url: str,
                         fiscal_year: int) -> List[str]:
        """年度に対応するリンクURLを探す。"""
        reiwa_year = fiscal_year - 2018  # 西暦→令和変換
        rw_pad = f"{reiwa_year:02d}"      # 零埋め2桁: 04, 05, 06 …
        patterns = [
            f"R{reiwa_year}",
            f"r{reiwa_year}",
            f"{fiscal_year}",
            f"r0{reiwa_year}" if reiwa_year < 10 else f"r{reiwa_year}",
            f"_{rw_pad}",     # kekka_05.html / tekisei_06.html など
            f"-{rw_pad}",     # result-06.html など
        ]

        found = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            # PDF/Excel等のバイナリファイルは除外
            if re.search(r"\.(pdf|xlsx?|docx?|zip)$", href, re.IGNORECASE):
                continue
            if any(p in href for p in patterns):
                full = urljoin(base_url, href)
                if full not in found:
                    found.append(full)
        return found

    def _parse_page(self, url: str, fiscal_year: int) -> List[Dict]:
        """ページのHTMLテーブルを解析してレコードリストを返す。
        ページ内に「令和N年度」見出しがある場合、テーブルごとに年度を自動判定する。"""
        soup = self.collector.get_soup(url)
        if soup is None:
            return []

        contract_type = _detect_contract_type(url)
        records = []

        # ページ内に年度見出し（令和N年度）が存在するか確認
        # 存在する場合はDOM順に走査して各テーブルの年度を決定する
        heading_years = {}  # table element → fiscal_year
        current_fy = fiscal_year
        has_year_headings = False
        for el in soup.find_all(["h1", "h2", "h3", "h4", "h5", "table"]):
            if el.name != "table":
                text = el.get_text(strip=True)
                m = re.search(r"令和\s*(\d+)\s*年度", text)
                if m:
                    current_fy = 2018 + int(m.group(1))
                    has_year_headings = True
            else:
                heading_years[id(el)] = current_fy

        for table in soup.find_all("table"):
            # 年度見出しがある場合は対応する年度を使用
            table_fy = heading_years.get(id(table), fiscal_year)
            if has_year_headings and table_fy != fiscal_year:
                continue  # 異なる年度のテーブルはスキップ

            rows = []
            for tr in table.find_all("tr"):
                cells = [td.get_text(separator=" ", strip=True)
                         for td in tr.find_all(["td", "th"])]
                if cells:
                    rows.append(cells)

            if len(rows) < 2:
                continue

            # ヘッダー行を自動検索（最大20行）
            col_map = {}
            data_start = 1
            for hi in range(min(20, len(rows))):
                cm = _detect_col_map(rows[hi])
                if "vendor_name" in cm:
                    col_map = cm
                    data_start = hi + 1
                    break

            if "contract_name" not in col_map and "vendor_name" not in col_map:
                continue  # 調達テーブルではないとみなす

            recs = self.parse_table_rows(
                rows[data_start:], col_map,
                table_fy, url, contract_type
            )
            records.extend(recs)
            logger.debug(f"  テーブル解析: {len(recs)}件 FY{table_fy} ({url})")

        return records
