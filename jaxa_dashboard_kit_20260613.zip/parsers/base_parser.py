"""
全パーサー共通の正規化ロジック。
"""
import re
from typing import Optional

# ── 入札方式正規化マッピング ──────────────────────────────
BID_METHOD_MAP = {
    # 一般競争
    "一般競争入札": "一般競争入札",
    "一般競争": "一般競争入札",
    "一般競争（価格）": "一般競争入札",
    "一般": "一般競争入札",
    "公告": "一般競争入札",
    # 総合評価
    "総合評価落札方式": "総合評価落札方式",
    "総合評価": "総合評価落札方式",
    "施工体制確認型総合評価": "総合評価落札方式",
    "簡易型総合評価": "総合評価落札方式",
    # 指名競争
    "指名競争入札": "指名競争入札",
    "指名競争": "指名競争入札",
    # 随意契約
    "随意契約": "随意契約",
    "随意": "随意契約",
    # プロポーザル
    "公募型プロポーザル": "公募型プロポーザル",
    "プロポーザル": "公募型プロポーザル",
    # 見積合わせ
    "見積合わせ": "見積合わせ",
    "相見積": "見積合わせ",
}

# 令和年号→西暦変換ベース
REIWA_BASE = 2018  # 令和1年 = 2019年 → base + year


class BaseParser:
    def __init__(self, agency_id: str, agency_name: str, agency_category: str):
        self.agency_id = agency_id
        self.agency_name = agency_name
        self.agency_category = agency_category

    def _normalize_amount(self, text: str) -> Optional[int]:
        """金額文字列を整数（円）に変換。"""
        if not text:
            return None
        text = text.replace("¥", "").replace(",", "").replace("円", "").strip()
        text = re.sub(r"[^\d]", "", text)
        if not text:
            return None
        try:
            return int(text)
        except ValueError:
            return None

    def _normalize_rate(self, text: str) -> Optional[float]:
        """落札率文字列をfloatに変換。例: '98.41%' → 98.41"""
        if not text:
            return None
        text = text.replace("%", "").strip()
        try:
            return float(text)
        except ValueError:
            return None

    def _normalize_date(self, text: str) -> Optional[str]:
        """日付文字列をYYYYMMDD形式に変換。

        対応フォーマット:
        - 'R6.7.20' / 'R6年7月20日'
        - '令和6年7月20日'
        - 'YYYYMMDD' (6桁 YYMMDD → 和暦と解釈)
        - 'YYYY/MM/DD'
        - 'YYYY年MM月DD日'
        """
        if not text:
            return None
        text = text.strip()

        # 令和X.Y.Z or RX.Y.Z
        m = re.match(r"(?:令和|R)(\d{1,2})[\.年](\d{1,2})[\.月](\d{1,2})", text)
        if m:
            year = REIWA_BASE + int(m.group(1))
            return f"{year}{int(m.group(2)):02d}{int(m.group(3)):02d}"

        # YYYY/MM/DD or YYYY-MM-DD or YYYY年MM月DD日
        m = re.match(r"(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})", text)
        if m:
            return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"

        # 6桁 YYMMDD（南関東防衛局形式）: '070329' → R7.3.29 → 2025/03/29
        m = re.match(r"^(\d{2})(\d{2})(\d{2})$", text)
        if m:
            reiwa_year = int(m.group(1))
            year = REIWA_BASE + reiwa_year
            return f"{year}{m.group(2)}{m.group(3)}"

        # 8桁 YYYYMMDD
        m = re.match(r"^(\d{8})$", text)
        if m:
            return text

        return None

    def _normalize_bid_method(self, text: str) -> str:
        """入札方式を正規化。"""
        if not text:
            return "不明"
        text = text.strip()
        for key, val in BID_METHOD_MAP.items():
            if key in text:
                return val
        return text[:20]  # 不明な場合はそのまま（最大20文字）

    def _is_jv(self, vendor_name: str, corp_number: str) -> bool:
        """JV（共同企業体）判定。"""
        if not vendor_name:
            return False
        jv_keywords = ["特定JV", "共同体", "共同企業体", "JV", "ＪＶ"]
        return any(kw in vendor_name for kw in jv_keywords) or (
            not corp_number or corp_number in ["-", ""]
        ) and any(kw in vendor_name for kw in ["特定", "共同"])

    def _make_record_base(self, fiscal_year: int, source_url: str,
                           source_type: str = "html", dept: str = "",
                           contract_type: str = "") -> dict:
        """レコードの共通フィールドを返す。"""
        return {
            "agency_id": self.agency_id,
            "agency_name": self.agency_name,
            "agency_category": self.agency_category,
            "fiscal_year": fiscal_year,
            "contract_month": None,
            "contract_type": contract_type,
            "dept": dept,
            "contract_name": None,
            "vendor_name": None,
            "corporate_number": None,
            "contract_amount": None,
            "estimated_price": None,
            "award_rate": None,
            "period_start": None,
            "period_end": None,
            "bid_method": "不明",
            "source_url": source_url,
            "source_type": source_type,
            "pdf_url": None,
            "is_jv": 0,
            "contract_date": None,
            "quantity": None,
            "unit_measure": None,
            "contract_officer": None,
            "vendor_address": None,
            "zuii_reason": None,
        }

    def parse_table_rows(self, rows: list, col_map: dict,
                          fiscal_year: int, source_url: str,
                          contract_type: str = "", dept: str = "") -> list:
        """
        汎用テーブルパーサー。
        col_map: {DBカラム名: テーブル列インデックス} のマッピング
        """
        records = []
        for row in rows:
            rec = self._make_record_base(
                fiscal_year, source_url, "html", dept, contract_type
            )
            for field, idx in col_map.items():
                if idx >= len(row):
                    continue
                cell = row[idx].strip() if row[idx] else ""
                if field == "contract_name":
                    rec["contract_name"] = cell or None
                elif field == "vendor_name":
                    rec["vendor_name"] = cell or None
                elif field == "corporate_number":
                    rec["corporate_number"] = cell or None
                elif field == "contract_amount":
                    rec["contract_amount"] = self._normalize_amount(cell)
                elif field == "estimated_price":
                    rec["estimated_price"] = self._normalize_amount(cell)
                elif field == "award_rate":
                    rec["award_rate"] = self._normalize_rate(cell)
                elif field == "contract_date":
                    rec["contract_date"] = self._normalize_date(cell)
                elif field == "period_start":
                    rec["period_start"] = self._normalize_date(cell)
                elif field == "period_end":
                    rec["period_end"] = self._normalize_date(cell)
                elif field == "bid_method":
                    rec["bid_method"] = self._normalize_bid_method(cell)
                elif field == "contract_month":
                    try:
                        rec["contract_month"] = int(cell)
                    except ValueError:
                        pass

            if rec["vendor_name"]:
                rec["is_jv"] = int(self._is_jv(
                    rec["vendor_name"], rec.get("corporate_number", "") or ""
                ))
                records.append(rec)

        return records
