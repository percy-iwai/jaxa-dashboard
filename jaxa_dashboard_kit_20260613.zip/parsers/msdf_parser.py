"""
海上自衛隊各地方総監部向けパーサー。
msdf/bukei/{code}/ の Excel4ファイル + HTML結果ページを統合収集する。

各拠点のURL構造:
  横須賀(y0): nyuusatsu/RAKUSATSU_K.xlsx, RAKUSATSU_B.xlsx, ZUIKEI_K.xlsx, ZUIKEI_B.xlsx
              nyusatsu_k.htm (HTML工事落札結果 R6)
  呉(k0):     nyuusatsu/RAKUSATSU_*.xlsx
              keiyakukeka/kk_jisseki.html (HTML工事 R4+R5)
              keiyakukeka/kg_jiseki.html  (HTML業務 R4+R5)
  佐世保(s0): RAKUSATSU_K.xls, RAKUSATSU_B.xls, ZUIKEI_K.xls, ZUIKEI_B.xls
  舞鶴(m0):   keiyakukeka/RAKUSATSU_*.xlsx
              keiyakukeka/kk_jiseki04.htm (HTML工事 R6)
  大湊(d0):   nyuusatu/RAKUSATSU_*.xlsx
              kk_jiseki.htm (HTML工事 R6+R7)
"""
from typing import List, Dict, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from loguru import logger

from collectors.html_collector import HtmlCollector
from parsers.base_parser import BaseParser
from parsers.excel_parser import ExcelParser
from parsers.generic_parser import _detect_col_map

MSDF_BASE = "https://www.mod.go.jp/msdf/bukei"

# 拠点設定: agency_id → {code, excel_dir, excel_ext, html_pages[(path, contract_type, fy_min, fy_max)]}
MSDF_CONFIG = {
    "msdf_yokosuka": {
        "code": "y0",
        "excel_dir": "nyuusatsu",
        "excel_ext": "xlsx",
        "html_pages": [
            ("nyusatsu_k.htm", "工事", 2024, 2025),
        ],
    },
    "msdf_kure": {
        "code": "k0",
        "excel_dir": "nyuusatsu",
        "excel_ext": "xlsx",
        "html_pages": [
            ("keiyakukeka/kk_jisseki.html", "工事", 2022, 2023),
            ("keiyakukeka/kg_jiseki.html",  "業務", 2022, 2023),
        ],
    },
    "msdf_sasebo": {
        "code": "s0",
        "excel_dir": "",          # ベースディレクトリ直下
        "excel_ext": "xls",
        "html_pages": [],
    },
    "msdf_maizuru": {
        "code": "m0",
        "excel_dir": "keiyakukeka",
        "excel_ext": "xlsx",
        "html_pages": [
            ("keiyakukeka/kk_jiseki04.htm", "工事", 2024, 2024),
        ],
    },
    "msdf_ominato": {
        "code": "d0",
        "excel_dir": "nyuusatu",   # スペルに注意（u が1つ）
        "excel_ext": "xlsx",
        "html_pages": [
            ("kk_jiseki.htm", "工事", 2024, 2025),
        ],
    },
}

EXCEL_FILES = [
    ("RAKUSATSU_K", "工事（競争）"),
    ("RAKUSATSU_B", "物品役務（競争）"),
    ("ZUIKEI_K",    "工事（随意）"),
    ("ZUIKEI_B",    "物品役務（随意）"),
]


class MsdfParser(BaseParser):
    """海上自衛隊各地方総監部専用パーサー。"""

    def __init__(self, agency: Dict):
        super().__init__(agency["id"], agency["name"], agency["category"])
        self.collector = HtmlCollector(use_cache=True)
        self.excel = ExcelParser(agency["id"], agency["name"], agency["category"])
        self.cfg = MSDF_CONFIG.get(agency["id"], {})

    def collect_year(self, fiscal_year: int) -> List[Dict]:
        if not self.cfg:
            return []

        records = []
        code = self.cfg["code"]
        ext = self.cfg["excel_ext"]
        excel_dir = self.cfg["excel_dir"]
        base_url = f"{MSDF_BASE}/{code}"

        # ── Excel4ファイル ────────────────────────────────────────
        # 現在のExcelは最新年度のデータのみを含む。
        # FY2024以降のみ取得し、FY2023は HTML ページに頼る。
        if fiscal_year >= 2024:
            for file_stem, ctype in EXCEL_FILES:
                if excel_dir:
                    url = f"{base_url}/{excel_dir}/{file_stem}.{ext}"
                else:
                    url = f"{base_url}/{file_stem}.{ext}"
                recs = self.excel.parse_excel_url(url, fiscal_year, ctype)
                records.extend(recs)

        # ── HTML結果ページ ────────────────────────────────────────
        for page_path, ctype, fy_min, fy_max in self.cfg.get("html_pages", []):
            if not (fy_min <= fiscal_year <= fy_max):
                continue
            url = f"{base_url}/{page_path}"
            recs = self._parse_html_page(url, fiscal_year, ctype)
            records.extend(recs)

        logger.info(
            f"[{self.agency_name}] {fiscal_year}年度: 合計 {len(records)}件"
        )
        return records

    def _parse_html_page(self, url: str, fiscal_year: int,
                         contract_type: str) -> List[Dict]:
        """HTMLテーブルから契約レコードを抽出する。"""
        soup = self.collector.get_soup(url)
        if soup is None:
            logger.warning(f"取得失敗: {url}")
            return []

        records = []
        for table in soup.find_all("table"):
            rows = []
            for tr in table.find_all("tr"):
                cells = [td.get_text(separator=" ", strip=True)
                         for td in tr.find_all(["td", "th"])]
                if cells:
                    rows.append(cells)

            if len(rows) < 2:
                continue

            # ヘッダー行を自動検索（最大10行）
            col_map = {}
            data_start = 1
            for hi in range(min(10, len(rows))):
                cm = _detect_col_map(rows[hi])
                if "vendor_name" in cm:
                    col_map = cm
                    data_start = hi + 1
                    break

            if "vendor_name" not in col_map:
                continue

            recs = self.parse_table_rows(
                rows[data_start:], col_map,
                fiscal_year, url, contract_type
            )
            records.extend(recs)
            logger.debug(
                f"  MSDF HTMLテーブル: {len(recs)}件 ({url})"
            )

        return records
