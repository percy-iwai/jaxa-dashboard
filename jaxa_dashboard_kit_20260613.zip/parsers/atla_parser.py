"""
防衛装備庁（ATLA）中央調達パーサー。
月次Excelファイル（競争・随意契約 × 基準以上・基準未満）を解析する。

URL構造:
  R05〜（月次）:
    https://www.mod.go.jp/atla/souhon/supply/jisseki/rakusatu/
      kohyo_r{YY}/{YY}_kyoso_kijunijo-{MM}.xlsx    ← 競争（基準以上）
      kohyo_r{YY}/{YY}_kyoso_kijunmiman-{MM}.xlsx  ← 競争（基準未満）
      kohyo_r{YY}/{YY}_zuikei_kijunijo-{MM}.xlsx   ← 随意契約（基準以上）
      kohyo_r{YY}/{YY}_zuikei_kijunmiman-{MM}.xlsx ← 随意契約（基準未満）
    各年度 = 4月〜翌3月（12ヶ月）

  R04（年次・WARPアーカイブから取得）:
    https://warp.ndl.go.jp/20230301/20230301002334/https://www.mod.go.jp/
      atla/souhon/supply/jisseki/rakusatu/xls/
        04kyoso_kijunijo.xlsx   / 04kyoso_kijunmiman.xlsx
        04zuikei_kijunijo.xlsx  / 04zuikei_kijunmiman.xlsx
"""
from typing import List, Dict

from loguru import logger

from parsers.excel_parser import ExcelParser

ATLA_BASE = "https://www.mod.go.jp/atla/souhon/supply/jisseki/rakusatu"

# R04年次ファイルはWARPアーカイブ（2024年4月01日スナップショット）から取得
WARP_R04_BASE = (
    "https://warp.ndl.go.jp/20240401/20240401010452"
    "/https://www.mod.go.jp/atla/souhon/supply/jisseki/rakusatu/xls"
)

R04_FILES = [
    ("04kyoso_kijunijo",   "競争（基準以上）"),
    ("04kyoso_kijunmiman", "競争（基準未満）"),
    ("04zuikei_kijunijo",  "随意契約（基準以上）"),
    ("04zuikei_kijunmiman","随意契約（基準未満）"),
]


class AtlaParser(ExcelParser):
    """防衛装備庁中央調達専用パーサー（ExcelParser継承）。"""

    def collect_year(self, fiscal_year: int) -> List[Dict]:
        """指定年度の月次Excelを全て収集して返す。"""
        reiwa = fiscal_year - 2018
        records = []

        if reiwa == 4:
            # R04は年次ファイル（WARPアーカイブ）
            for file_suffix, ctype in R04_FILES:
                url = f"{WARP_R04_BASE}/{file_suffix}.xlsx"
                recs = self.parse_excel_url(url, fiscal_year, ctype)
                records.extend(recs)
        else:
            # R05以降は月次ファイル（mod.go.jp直接）
            rr = f"{reiwa:02d}"
            base = f"{ATLA_BASE}/kohyo_r{rr}"
            months = list(range(4, 13)) + list(range(1, 4))

            for month in months:
                mm = f"{month:02d}"
                for file_suffix, ctype in [
                    ("kyoso_kijunijo",    "競争（基準以上）"),
                    ("kyoso_kijunmiman",  "競争（基準未満）"),
                    ("zuikei_kijunijo",   "随意契約（基準以上）"),
                    ("zuikei_kijunmiman", "随意契約（基準未満）"),
                ]:
                    url = f"{base}/{rr}_{file_suffix}-{mm}.xlsx"
                    recs = self.parse_excel_url(url, fiscal_year, ctype)
                    records.extend(recs)

        logger.info(
            f"[{self.agency_name}] {fiscal_year}年度: 合計 {len(records)}件"
        )
        return records
