"""
大臣官房会計課 契約結果 Excelパーサー。

ページ構造:
  https://www.mod.go.jp/j/budget/chotatsu/naikyoku/keiyaku/index.html
  → fy{year}/{MM}/{MM}_{kouji|buppin}_{k|z}[_{date}].xlsx  (FY2022-2024)
  → fy{year}/{MM}_{kouji|buppin}_{k|z}.xlsx                 (FY2025)

ファイル名から契約種別を推定:
  kouji  → "工事"
  buppin → "物品役務"
"""
import re
from urllib.parse import urljoin
from typing import List, Dict

from loguru import logger

from collectors.html_collector import HtmlCollector
from parsers.excel_parser import ExcelParser


class NaikyokuParser(ExcelParser):
    def __init__(self, agency_id: str, agency_name: str, agency_category: str):
        super().__init__(agency_id, agency_name, agency_category)
        self.html_collector = HtmlCollector(use_cache=True)

    def collect_year(self, top_url: str, fiscal_year: int) -> List[Dict]:
        """keiyaku/index.html を解析し、該当年度の全Excelを収集・解析する。"""
        soup = self.html_collector.get_soup(top_url)
        if soup is None:
            logger.warning(f"[{self.agency_name}] ページ取得失敗: {top_url}")
            return []

        records = []
        seen_urls = set()
        fy_token = f"fy{fiscal_year}"  # 例: "fy2024"

        for a in soup.find_all("a", href=True):
            href = a["href"]

            # Excelファイルのみ対象
            if not href.lower().endswith(".xlsx"):
                continue

            # 対象年度フィルタ
            if fy_token not in href:
                continue

            # 絶対URL化
            full_url = urljoin(top_url, href)
            if full_url in seen_urls:
                continue
            seen_urls.add(full_url)

            # ファイル名から契約種別を推定
            contract_type = _infer_contract_type(href)

            recs = self.parse_excel_url(full_url, fiscal_year, contract_type)
            records.extend(recs)

        # 電気一式パースエラー対策: 単価×数量の誤計算で~19兆円になる既知バグ
        # 正常上限: 防衛省全体の電気代は年間数十億円程度
        _ELEC_KEYWORDS = ["電気一式", "電力一式"]
        for rec in records:
            amt = rec.get("contract_amount") or 0
            if amt > 10_000_000_000_000:  # 10兆円超
                name = rec.get("contract_name") or ""
                if any(kw in name for kw in _ELEC_KEYWORDS):
                    logger.warning(
                        f"[{self.agency_name}] 電気一式パースエラー疑い "
                        f"({amt/1e12:.1f}兆円) → contract_amount=NULL"
                    )
                    rec["contract_amount"] = None

        logger.info(
            f"[{self.agency_name}] FY{fiscal_year}: {len(seen_urls)}ファイル "
            f"→ {len(records)}件"
        )
        return records


def _infer_contract_type(href: str) -> str:
    """ファイル名パスから契約種別文字列を推定。"""
    if "kouji" in href:
        return "工事"
    if "buppin" in href:
        return "物品役務"
    return ""
