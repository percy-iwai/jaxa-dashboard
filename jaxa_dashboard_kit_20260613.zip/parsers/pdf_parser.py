"""
PDF形式で月別契約結果を公表している機関向けパーサー。
対応機関:
  - nids  (防衛研究所)     — /procurement/keiyaku/pdf/k{YYYYMM}.pdf, z{YYYYMM}.pdf
  - dih   (情報本部)       — /dih/R{reiwa}.{month}-kyousou.pdf, -zuikei.pdf
  - js    (統合幕僚監部)   — /js/supply/sup_contract_goods.html, sup_contract_private.html
  - igo   (防衛監察本部)   — /igo/procurement/pdf/R{year}_k_*.pdf (契約結果PDF)

政府調達情報公表様式（標準PDF列構成）:
  物品役務等の名称及び数量 | 契約担当官 | 契約を締結した日 |
  契約の相手方の商号又は名称及び住所 | 法人番号 |
  一般競争入札・指名競争入札の別 | 予定価格 | 契約金額 | 落札率 | ...
"""
import re
from typing import List, Dict, Optional
from urllib.parse import urljoin

from loguru import logger

from collectors.html_collector import HtmlCollector
from collectors.pdf_collector import PdfCollector
from parsers.base_parser import BaseParser
from parsers.generic_parser import _detect_col_map


def _fy_months(fiscal_year: int) -> List[int]:
    """年度→年月リスト。FY2023 → [202304,202305,...,202403]"""
    yyyymms = []
    for m in range(4, 13):
        yyyymms.append(fiscal_year * 100 + m)
    for m in range(1, 4):
        yyyymms.append((fiscal_year + 1) * 100 + m)
    return yyyymms


def _fy_cal_months(fiscal_year: int) -> List[tuple]:
    """年度→(暦年, 月) リスト。FY2023 → [(2023,4),...,(2024,3)]"""
    result = []
    for m in range(4, 13):
        result.append((fiscal_year, m))
    for m in range(1, 4):
        result.append((fiscal_year + 1, m))
    return result


# ── ATLA サブ機関 スコープコード定義 ──────────────────────────────────────────
# agency_id → (subdir_name, scope_code, is_sequential)
# is_sequential=True: 月別でなく連番(01,02,...)で発行される機関（disti/shinsedai）
_ATLA_SUB_SPECS: dict = {
    "atla_kanbo":     ("ny_honbu",            "h",     False),
    "atla_shimokita": ("ny_shimokita",         "sh",    False),
    "atla_chitose":   ("ny_chitose",           "sa",    False),
    "atla_gifu":      ("ny_gifu",              "g",     False),
    "atla_koukuu":    ("ny_kenkyu_koukuu",     "ko",    False),
    "atla_kantei":    ("ny_kenkyu_kantei",     "ka",    False),
    "atla_riku":      ("ny_kenkyu_riku",       "r",     False),
    "atla_shinsedai": ("ny_kenkyu_shinsedai",  "shi",   True),
    "atla_disti":     ("ny_disti",             "disti", True),
}

_ATLA_BASE = "https://www.mod.go.jp/atla/data/info"


def _atla_sub_pdf_url(subdir: str, scope: str, cal_year: int, cal_month: int,
                      content_type: str, method: str) -> str:
    """ATLA サブ機関 PDFのURLを生成。
    2024年（R06）以降: r{RY}/サブフォルダあり。それ以前（R05以下）: 直下。
    ※ 注意: FY2023 Jan-Mar (cal_year=2024, months 1-3) も r06/ サブフォルダ形式。
    """
    ry = cal_year - 2018
    ry2 = f"{ry:02d}"
    mm2 = f"{cal_month:02d}"
    base = f"{_ATLA_BASE}/{subdir}/pdf_ichiran/"
    filename = f"{ry2}-{content_type}-{method}-{scope}-{mm2}.pdf"
    # 暦年2024（R06）以降は r06/ 等のサブフォルダ形式
    if cal_year >= 2024:
        filename = f"r{ry2}/{filename}"
    return base + filename


class PdfTableParser(BaseParser):
    """PDF形式で月別契約結果を公表している機関向けパーサー。"""

    def __init__(self, agency_id: str, agency_name: str, agency_category: str):
        super().__init__(agency_id, agency_name, agency_category)
        self.collector = HtmlCollector(use_cache=True)
        self.pdf = PdfCollector(use_cache=True)

    def collect_year(self, top_url: str, fiscal_year: int) -> List[Dict]:
        """機関IDに応じたPDF収集を実行。"""
        if self.agency_id == "nids":
            return self._collect_nids(fiscal_year)
        elif self.agency_id == "dih":
            return self._collect_dih(fiscal_year)
        elif self.agency_id == "js":
            return self._collect_js(fiscal_year)
        elif self.agency_id == "igo":
            return self._collect_igo(fiscal_year)
        elif self.agency_id in _ATLA_SUB_SPECS:
            return self._collect_atla_sub(fiscal_year)
        elif self.agency_id == "ndmc":
            return self._collect_ndmc(fiscal_year)
        else:
            # 汎用モード: トップページからPDFリンクを動的発見
            return self._collect_generic_pdf(top_url, fiscal_year)

    # ── ATLA サブ機関（直接URL生成）──────────────────────────────
    def _collect_atla_sub(self, fiscal_year: int) -> List[Dict]:
        """ATLA サブ機関: 月別PDF URLを直接生成して解析。
        月別機関: 4 types × 12 months = 48 URLs/FY
        連番機関（disti/shinsedai）: 連番URLをキャッシュスキャン+ライブプローブ
        """
        subdir, scope, is_sequential = _ATLA_SUB_SPECS[self.agency_id]
        records = []

        if is_sequential:
            # disti/shinsedai: FY2024（R6）以降のみ存在
            ry = fiscal_year - 2018
            if ry < 6:
                logger.info(f"[{self.agency_name}] FY{fiscal_year}: 発足前のためスキップ")
                return []
            ry2 = f"{ry:02d}"
            base = f"{_ATLA_BASE}/{subdir}/pdf_ichiran/r{ry2}/"
            # 連番: キャッシュスキャン → ライブプローブ（キャッシュ最大番号+MAX_GAP件まで）
            # ギャップ（例: 03→10）でもキャッシュ済みなら無駄なHTTPリクエストを省く
            MAX_GAP = 10
            import re as _re
            from collectors.base_collector import CACHE_DIR
            files_dir = CACHE_DIR / "files"
            for ct, bm in [("ekimu", "一般競争入札"), ("ekimu", "随意契約"),
                            ("kouji", "一般競争入札"), ("kouji", "随意契約")]:
                method = "kyousou" if bm == "一般競争入札" else "zuikei"
                # キャッシュにある連番を検出
                pattern = (f"www.mod.go.jp_atla_data_info_{subdir}_pdf_ichiran"
                           f"_r{ry2}_{ry2}-{ct}-{method}-{scope}-*.pdf.pdf")
                cached_ns = []
                for cf in files_dir.glob(pattern):
                    m = _re.search(r'-(\d{2})\.pdf\.pdf$', cf.name)
                    if m:
                        cached_ns.append(int(m.group(1)))
                cached_ns.sort()
                max_cached = max(cached_ns) if cached_ns else 0
                # キャッシュ済みURLを先に処理（miss=0, 100% cache hit）
                for n in cached_ns:
                    url = f"{base}{ry2}-{ct}-{method}-{scope}-{n:02d}.pdf"
                    recs = self._parse_procurement_pdf(url, fiscal_year, bm)
                    records.extend(recs)
                # キャッシュ最大番号の次からMAX_GAP件だけライブプローブ（新ファイル発見用）
                empty_run = 0
                for n in range(max_cached + 1, max_cached + MAX_GAP * 2 + 1):
                    if n in cached_ns:
                        continue  # 既処理
                    url = f"{base}{ry2}-{ct}-{method}-{scope}-{n:02d}.pdf"
                    recs = self._parse_procurement_pdf(url, fiscal_year, bm)
                    if recs:
                        records.extend(recs)
                        empty_run = 0
                    else:
                        empty_run += 1
                        if empty_run >= MAX_GAP:
                            break
        else:
            # 月別形式: 4 types × 12 months
            # ATLA サブ機関は FY2023（R05）以降のみ存在。FY2022（R04）はスキップ。
            if fiscal_year < 2023:
                logger.info(f"[{self.agency_name}] FY{fiscal_year}: データなし（FY2023以降のみ）")
                return []
            for cal_year, cal_month in _fy_cal_months(fiscal_year):
                for ct, bm in [("ekimu", "一般競争入札"), ("ekimu", "随意契約"),
                                ("kouji", "一般競争入札"), ("kouji", "随意契約")]:
                    method = "kyousou" if bm == "一般競争入札" else "zuikei"
                    url = _atla_sub_pdf_url(subdir, scope, cal_year, cal_month, ct, method)
                    recs = self._parse_procurement_pdf(url, fiscal_year, bm,
                                                       month=cal_month)
                    records.extend(recs)

        logger.info(f"[{self.agency_name}] FY{fiscal_year}: {len(records)}件（ATLA-sub PDF）")
        return records

    # ── NDMC（防衛医科大学校）────────────────────────────────────
    def _collect_ndmc(self, fiscal_year: int) -> List[Dict]:
        """NDMC: /wp-content/uploads/{YYYY}/{MM}/koukyou{RYYMM}-{3,4}.pdf"""
        base = "https://www.ndmc.ac.jp/wp-content/uploads"
        records = []
        for cal_year, cal_month in _fy_cal_months(fiscal_year):
            ry = cal_year - 2018
            for type_num, bm in [(3, "一般競争入札"), (4, "随意契約")]:
                url = (f"{base}/{cal_year}/{cal_month:02d}/"
                       f"koukyou{ry:02d}{cal_month:02d}-{type_num}.pdf")
                recs = self._parse_procurement_pdf(url, fiscal_year, bm,
                                                   month=cal_month)
                records.extend(recs)
        logger.info(f"[{self.agency_name}] FY{fiscal_year}: {len(records)}件（NDMC PDF）")
        return records

    # ── NIDS（防衛研究所）──────────────────────────────────────
    def _collect_nids(self, fiscal_year: int) -> List[Dict]:
        """NIDS: URL直接生成パターン。k{YYYYMM}.pdf / z{YYYYMM}.pdf"""
        base = "https://www.nids.mod.go.jp/procurement/keiyaku/pdf"
        records = []

        for yyyymm in _fy_months(fiscal_year):
            month = yyyymm % 100
            for prefix, bid_method in [("k", "一般競争入札"), ("z", "随意契約")]:
                url = f"{base}/{prefix}{yyyymm}.pdf"
                recs = self._parse_procurement_pdf(
                    url, fiscal_year, bid_method, month=month
                )
                records.extend(recs)

        logger.info(f"[{self.agency_name}] {fiscal_year}年度: {len(records)}件（PDF）")
        return records

    # ── DIH（情報本部）─────────────────────────────────────────
    def _collect_dih(self, fiscal_year: int) -> List[Dict]:
        """DIH: R{reiwa}.{month}-kyousou.pdf / -zuikei.pdf"""
        base = "https://www.mod.go.jp/dih"
        records = []

        for yyyymm in _fy_months(fiscal_year):
            year = yyyymm // 100
            month = yyyymm % 100
            reiwa = year - 2018
            for suffix, bid_method in [
                ("kyousou", "一般競争入札"),
                ("zuikei", "随意契約"),
            ]:
                url = f"{base}/R{reiwa}.{month}-{suffix}.pdf"
                recs = self._parse_procurement_pdf(
                    url, fiscal_year, bid_method, month=month
                )
                records.extend(recs)

        logger.info(f"[{self.agency_name}] {fiscal_year}年度: {len(records)}件（PDF）")
        return records

    # ── JS（統合幕僚監部）──────────────────────────────────────
    def _collect_js(self, fiscal_year: int) -> List[Dict]:
        """JS: kyou{YYMM}.pdf / zui{YYMM}.pdf パターンで直接生成。
        YY=西暦下2桁, MM=月。"""
        base = "https://www.mod.go.jp/js/pdf/supply/contract"
        records = []

        for yyyymm in _fy_months(fiscal_year):
            yy = (yyyymm // 100) % 100  # 西暦下2桁
            mm = yyyymm % 100
            month = mm
            for prefix, bid_method in [
                ("kyou", "一般競争入札"),
                ("zui", "随意契約"),
            ]:
                url = f"{base}/{prefix}{yy:02d}{mm:02d}.pdf"
                recs = self._parse_procurement_pdf(
                    url, fiscal_year, bid_method, month=month
                )
                records.extend(recs)

        logger.info(f"[{self.agency_name}] {fiscal_year}年度: {len(records)}件（PDF）")
        return records

    # ── IGO（防衛監察本部）─────────────────────────────────────
    def _collect_igo(self, fiscal_year: int) -> List[Dict]:
        """IGO: メインページの契約結果PDFと入札結果PDFを収集。"""
        base_url = "https://www.mod.go.jp/igo/procurement/index.html"
        soup = self.collector.get_soup(base_url)
        if soup is None:
            return []

        reiwa_year = fiscal_year - 2018
        records = []

        # 1) 契約に係る情報の公表PDF (R{year}_k_*.pdf)
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.endswith(".pdf"):
                continue
            # R5_k_buppin_ekimu.pdf, R6_k_sisutemu_ekimu.pdf 等
            m = re.search(r"R(\d+)_k_", href)
            if m and int(m.group(1)) == reiwa_year:
                url = urljoin(base_url, href)
                recs = self._parse_procurement_pdf(url, fiscal_year, "")
                records.extend(recs)

        # 2) 入札結果PDF (_kekka.pdf)
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.endswith(".pdf"):
                continue
            if "_kekka" not in href:
                continue
            # 年度の判定: 調達年度のテキストを探す
            tr = a.find_parent("tr")
            if tr:
                tds = tr.find_all(["td", "th"])
                if tds:
                    fy_text = tds[0].get_text(strip=True)
                    m = re.search(r"令和(\d+)年度", fy_text)
                    if m:
                        pdf_fy = 2018 + int(m.group(1))
                        if pdf_fy != fiscal_year:
                            continue
                    else:
                        continue

                url = urljoin(base_url, href)
                recs = self._parse_igo_kekka_pdf(url, fiscal_year)
                records.extend(recs)

        logger.info(f"[{self.agency_name}] {fiscal_year}年度: {len(records)}件（PDF）")
        return records

    def _parse_igo_kekka_pdf(self, url: str, fiscal_year: int) -> List[Dict]:
        """IGO入札結果PDF（個別公告結果）を解析。
        通常は落札者名と金額のみの簡素なPDF。"""
        tables = self.pdf.extract_tables_from_url(url)
        if not tables:
            return []

        records = []
        for table in tables:
            if len(table) < 2:
                continue

            # 結果PDFは簡素な形式: 落札者名、金額等
            # テーブルの中からベンダー名と金額を抽出
            rec = self._make_record_base(fiscal_year, url, "pdf", contract_type="物品役務")
            for row in table:
                row_text = " ".join(c or "" for c in row).strip()
                # 金額を探す
                amt_match = re.search(r"[\d,]+円", row_text)
                if amt_match:
                    rec["contract_amount"] = self._normalize_amount(amt_match.group())
                # 落札者/契約者を探す
                for cell in row:
                    if not cell:
                        continue
                    cell = cell.strip()
                    if "株式会社" in cell or "有限会社" in cell or "合同会社" in cell:
                        rec["vendor_name"] = cell.split("\n")[0].strip()
                        break

            if rec.get("vendor_name"):
                records.append(rec)

        return records

    # ── 汎用PDF発見モード（ASDF基地等）────────────────────────────
    def _collect_generic_pdf(self, top_url: str, fiscal_year: int) -> List[Dict]:
        """トップページのPDFリンクを動的に発見して解析する汎用モード。
        2つの方式を組み合わせる:
          1. 見出しベース: DOM順に走査し「令和N年度」見出し後のPDFを収集
          2. URLパターン: URLまたはリンクテキストに年度識別子を含むPDFを収集
        """
        soup = self.collector.get_soup(top_url)
        if soup is None:
            logger.warning(f"[{self.agency_name}] ページ取得失敗: {top_url}")
            return []

        reiwa = fiscal_year - 2018
        reiwa_next = reiwa + 1

        # ── 方式1: 見出しベース ──────────────────────────────────
        seen = set()
        heading_tags = {"h1", "h2", "h3", "h4", "h5", "h6", "dt", "th"}
        in_target_fy = False
        has_year_headings = False

        for el in soup.descendants:
            if not hasattr(el, "name") or el.name is None:
                continue
            if el.name in heading_tags or el.name in ("strong", "b"):
                text = el.get_text(strip=True)
                m = re.search(r"令和\s*(\d+)\s*年度", text)
                if m:
                    has_year_headings = True
                    el_fy = 2018 + int(m.group(1))
                    in_target_fy = (el_fy == fiscal_year)
            elif el.name == "a" and in_target_fy:
                href = el.get("href", "")
                if href.lower().endswith(".pdf"):
                    full_url = urljoin(top_url, href)
                    seen.add(full_url)

        # ── 方式2: URLパターン ────────────────────────────────────
        url_patterns = [
            f"R{reiwa}",   f"R{reiwa:02d}",
            f"r{reiwa}",   f"r{reiwa:02d}",
            f"followup{reiwa}.",
            f"tekisei{reiwa}", f"tekiseiR{reiwa}",
            f"令和{reiwa}年",
        ]
        next_patterns = [
            f"R{reiwa_next}.1", f"R{reiwa_next}.2", f"R{reiwa_next}.3",
            f"tekiseiR{reiwa_next}.1",
            f"tekiseiR{reiwa_next}.2",
            f"tekiseiR{reiwa_next}.3",
            # 那覇形式: followup{reiwa_next}.1/2/3 (次年度1〜3月分)
            f"followup{reiwa_next}.1",
            f"followup{reiwa_next}.2",
            f"followup{reiwa_next}.3",
        ]

        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.lower().endswith(".pdf"):
                continue
            combined = href + " " + a.get_text(strip=True)
            if any(p in combined for p in url_patterns + next_patterns):
                seen.add(urljoin(top_url, href))

        # ── 収集 ─────────────────────────────────────────────────
        records = []
        for full_url in seen:
            recs = self._parse_procurement_pdf(full_url, fiscal_year, "")
            records.extend(recs)

        logger.info(
            f"[{self.agency_name}] FY{fiscal_year}: {len(seen)}PDF "
            f"(見出し検出={'有' if has_year_headings else '無'}) → {len(records)}件"
        )
        return records

    # ── 共通PDF解析 ────────────────────────────────────────────
    def _parse_procurement_pdf(
        self, url: str, fiscal_year: int,
        default_bid_method: str = "", month: int = 0
    ) -> List[Dict]:
        """標準政府調達公表PDF（物品役務等）のテーブルを解析。"""
        tables = self.pdf.extract_tables_from_url(url)
        if not tables:
            logger.debug(f"  PDFテーブルなし: {url}")
            return []

        records = []
        for table in tables:
            if len(table) < 2:
                continue

            # ヘッダー行検出（最大5行）
            col_map = {}
            data_start = 1
            for hi in range(min(5, len(table))):
                row = table[hi]
                # Noneセルを空文字に変換
                clean_row = [(c or "").strip() for c in row]
                cm = _detect_col_map(clean_row)
                if "vendor_name" in cm or "contract_name" in cm:
                    col_map = cm
                    data_start = hi + 1
                    break

            # サブヘッダー行をスキップ（空セルが多い行）
            while data_start < len(table):
                row = table[data_start]
                non_empty = sum(1 for c in row if c and c.strip())
                if non_empty >= 3:
                    break
                data_start += 1

            if not col_map:
                continue

            # データ行を解析
            for row in table[data_start:]:
                cells = [(c or "").strip() for c in row]
                if not any(cells):
                    continue

                rec = self._make_record_base(
                    fiscal_year, url, "pdf",
                    contract_type="物品役務"
                )
                rec["bid_method"] = default_bid_method or "不明"
                if month:
                    rec["contract_month"] = month

                for field, idx in col_map.items():
                    if idx >= len(cells):
                        continue
                    cell = cells[idx]
                    if not cell:
                        continue

                    if field == "contract_name":
                        # "外国雑誌１８９品目\n1件" → 名称部分のみ
                        rec["contract_name"] = cell.split("\n")[0].strip() or None
                    elif field == "vendor_name":
                        # "株式会社ＯＣＳ\n東京都江東区..." → 社名+住所分割
                        rec["vendor_name"] = self._clean_vendor_name(cell)
                        lines = cell.split("\n")
                        if len(lines) > 1:
                            rec["vendor_address"] = "\n".join(l.strip() for l in lines[1:] if l.strip()) or None
                    elif field == "corporate_number":
                        rec["corporate_number"] = re.sub(r"\D", "", cell) or None
                    elif field == "contract_amount":
                        rec["contract_amount"] = self._normalize_amount(cell)
                    elif field == "estimated_price":
                        rec["estimated_price"] = self._normalize_amount(cell)
                    elif field == "award_rate":
                        rec["award_rate"] = self._normalize_rate(cell)
                    elif field == "bid_method":
                        rec["bid_method"] = self._normalize_bid_method(cell)
                    elif field == "contract_date":
                        rec["contract_date"] = self._normalize_date(cell)
                    elif field == "contract_officer":
                        rec["contract_officer"] = cell or None

                if rec.get("vendor_name"):
                    rec["is_jv"] = int(self._is_jv(
                        rec["vendor_name"],
                        rec.get("corporate_number", "") or ""
                    ))
                    records.append(rec)

            logger.debug(f"  PDFテーブル: {len(records)}件 ({url})")

        return records

    def _clean_vendor_name(self, cell: str) -> Optional[str]:
        """PDF内のベンダーセル（社名+住所）から社名のみを抽出。
        標準形式: '株式会社○○\\n東京都○○区...' → '株式会社○○'"""
        if not cell:
            return None
        # 改行で分割、1行目が社名
        name = cell.split("\n")[0].strip()
        return name or None
