"""
地方防衛局（8局）向けパーサー。
各局のHTML構造差異に対応する。

【ソース選定ルール】
「公共調達の適正化について（中略）に基づく」形式のページをソースとする。
「入札結果」「発注実績」ページは使用禁止。

URL構造:
  北海道:   /rdb/hokkaido/keiyaku/keiyakujyoho_kouhyou/pdf/r{RY}/{cal_yy}_{MM}{type}.xlsx
            type: kk=工事競争, kz=工事随意, bek=物品役務競争, bez=物品役務随意
  東北:     /rdb/tohoku/contract/result/keiyaku/{CYY}-{M}-{N}.pdf
            N: 1=工事競争, 2=工事随意, 3=物品役務競争, 4=物品役務随意
  北関東:   月次PDF /rdb/n-kanto/nyusatsu-keiyaku/tyoutatu/kekka/{prefix}-{RY}{MM}.pdf
  南関東:   月次PDF /rdb/s-kanto/contract/information/images/reiwa{N}nendo/...
  近畿中部: 月次Excel /rdb/kinchu/contract/information/files/construction_competitive_{YYYYMM}.xlsx
  中国四国: /rdb/chushi/contract/result/pdf/keiyaku-{type}{CYYMM}.pdf
            type: kk=工事競争, kz=工事随意, bk=物品役務競争, bz=物品役務随意
  九州:     PDFリンクをインデックスページから収集
            /rdb/kyushu/contract/announcement/index.html
  沖縄:     月次PDF /rdb/okinawa/contract/information/pdf/{year4}/{cat}/{cat}{M}.pdf
"""
import re
from typing import List, Dict, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from loguru import logger

from collectors.html_collector import HtmlCollector
from collectors.pdf_collector import PdfCollector
from parsers.base_parser import BaseParser
from parsers.excel_parser import ExcelParser
from parsers.generic_parser import GenericParser, _detect_col_map
from parsers.pdf_parser import PdfTableParser

MOD_RDB_BASE = "https://www.mod.go.jp"

# ── 局ごとのURL生成ルール ─────────────────────────────────

def _rdb_urls(agency_id: str, fiscal_year: int) -> List[Dict]:
    """
    局IDと年度から収集対象URLとメタ情報のリストを返す。
    [{"url": ..., "contract_type": ..., "dept": ..., "source_type": "html"|"excel"}, ...]
    """
    reiwa = fiscal_year - 2018
    year4 = fiscal_year
    rr = f"{reiwa:02d}"   # "04", "05", "06"
    urls = []

    # ── 九州防衛局 ──
    # 「契約情報の公表」インデックスページからPDFリンクを収集
    # （スペル揺れがあるため静的URL生成は行わずインデックス経由で取得）
    if agency_id == "rdb_kyushu":
        urls.append({
            "url": f"{MOD_RDB_BASE}/rdb/kyushu/contract/announcement/index.html",
            "contract_type": "",
            "dept": "",
            "source_type": "pdf_index",
            "fy_reiwa": rr,   # フィルタ用: "06" など
        })

    # ── 南関東防衛局 ──
    # contract/information/images/reiwa{N}nendo/R{Y}.{M}/{num}_{YY}{MM}type.pdf
    # フォルダ名は単桁令和年 (R6.4, R7.3)、ファイル名は2桁 (01_0604...)
    elif agency_id == "rdb_s_kanto":
        base = f"{MOD_RDB_BASE}/rdb/s-kanto/contract/information/images/reiwa{reiwa}nendo"
        cats = [
            ("01", "kyousou_kouji", "工事"),
            ("02", "zuikei_kouji", "工事（随意）"),
            ("03", "kyousou_ekimu", "業務"),
            ("04", "zuikei_ekimu", "業務（随意）"),
        ]
        for m in range(4, 13):
            mm = f"{m:02d}"
            for num, suffix, ctype in cats:
                urls.append({
                    "url": f"{base}/R{reiwa}.{m}/{num}_{rr}{mm}{suffix}.pdf",
                    "contract_type": ctype, "dept": "", "source_type": "pdf",
                })
        for m in range(1, 4):
            next_rr = f"{reiwa+1:02d}"
            mm = f"{m:02d}"
            for num, suffix, ctype in cats:
                urls.append({
                    "url": f"{base}/R{reiwa+1}.{m}/{num}_{next_rr}{mm}{suffix}.pdf",
                    "contract_type": ctype, "dept": "", "source_type": "pdf",
                })

    # ── 北海道防衛局 ──
    # 「契約に係る情報の公表」月次Excel
    # フォルダ: pdf/r{RY}/ ファイル: {cal_yy}_{MM}{type}.xlsx
    # cal_yy = RY for Apr-Dec, (RY+1) for Jan-Mar
    elif agency_id == "rdb_hokkaido":
        base = f"{MOD_RDB_BASE}/rdb/hokkaido/keiyaku/keiyakujyoho_kouhyou/pdf/r{rr}"
        types = [
            ("kk",  "工事",    "一般競争入札"),
            ("kz",  "工事",    "随意契約"),
            ("bek", "物品役務", "一般競争入札"),
            ("bez", "物品役務", "随意契約"),
        ]
        for m in range(4, 13):
            for t, ctype, bid in types:
                urls.append({
                    "url": f"{base}/{rr}_{m:02d}{t}.xlsx",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "excel",
                })
        next_rr = f"{reiwa + 1:02d}"
        for m in range(1, 4):
            for t, ctype, bid in types:
                urls.append({
                    "url": f"{base}/{next_rr}_{m:02d}{t}.xlsx",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "excel",
                })

    # ── 東北防衛局 ──
    # 「契約に係る情報の公表」月次PDF
    # URL: /rdb/tohoku/contract/result/keiyaku/{CYY}-{M}-{N}.pdf
    # N: 1=工事競争, 2=工事随意, 3=物品役務競争, 4=物品役務随意
    # CYY: 2桁カレンダー年, M: 月（ゼロ埋めなし）
    elif agency_id == "rdb_tohoku":
        base = f"{MOD_RDB_BASE}/rdb/tohoku/contract/result/keiyaku"
        cat_map = [
            (1, "工事",    "一般競争入札"),
            (2, "工事",    "随意契約"),
            (3, "物品役務", "一般競争入札"),
            (4, "物品役務", "随意契約"),
        ]
        cyy_start = str(year4)[2:]   # "24" for FY2024
        cyy_next  = str(year4 + 1)[2:]  # "25"
        for m in range(4, 13):
            for n, ctype, bid in cat_map:
                urls.append({
                    "url": f"{base}/{cyy_start}-{m}-{n}.pdf",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "pdf",
                })
        for m in range(1, 4):
            for n, ctype, bid in cat_map:
                urls.append({
                    "url": f"{base}/{cyy_next}-{m}-{n}.pdf",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "pdf",
                })

    # ── 北関東防衛局 ──
    # (1) kensetu/{YYYY}kekka/{YY}kouji.files/sheet001.htm（Excel Web保存形式・年度集計）
    # (2) nyusatsu-keiyaku/tyoutatu/kekka/{prefix}-{RY}{MM}.pdf（月次PDF）
    #     prefix: n-b=競争物品役務, n-k=競争工事, z-b=随意物品役務, z-k=随意工事
    elif agency_id == "rdb_n_kanto":
        # 年度集計 Excel HTML
        base_excel = f"{MOD_RDB_BASE}/rdb/n-kanto/nyusatsu-keiyaku/kensetu"
        for suffix, ctype in [("kouji", "工事"), ("gyoumu", "業務")]:
            urls.append({
                "url": f"{base_excel}/{year4}kekka/{rr}{suffix}.files/sheet001.htm",
                "contract_type": ctype,
                "dept": "",
                "source_type": "html",
            })
        # 月次PDF（競争・随意）
        base_pdf = f"{MOD_RDB_BASE}/rdb/n-kanto/nyusatsu-keiyaku/tyoutatu/kekka"
        next_rr = f"{reiwa+1:02d}"
        prefix_map = [
            ("n-b", "物品役務", "一般競争入札"),
            ("n-k", "工事",    "一般競争入札"),
            ("z-b", "物品役務", "随意契約"),
            ("z-k", "工事",    "随意契約"),
        ]
        for m in range(4, 13):
            mm = f"{m:02d}"
            for prefix, ctype, bid in prefix_map:
                urls.append({
                    "url": f"{base_pdf}/{prefix}-{rr}{mm}.pdf",
                    "contract_type": ctype,
                    "dept": "",
                    "source_type": "pdf",
                    "bid_method": bid,
                })
                # 4月に -2 バリアントが存在することがある
                if m == 4:
                    urls.append({
                        "url": f"{base_pdf}/{prefix}-{rr}{mm}-2.pdf",
                        "contract_type": ctype,
                        "dept": "",
                        "source_type": "pdf",
                        "bid_method": bid,
                    })
        for m in range(1, 4):
            mm = f"{m:02d}"
            for prefix, ctype, bid in prefix_map:
                urls.append({
                    "url": f"{base_pdf}/{prefix}-{next_rr}{mm}.pdf",
                    "contract_type": ctype,
                    "dept": "",
                    "source_type": "pdf",
                    "bid_method": bid,
                })

    # ── 近畿中部防衛局（月次Excel）──
    # construction_competitive_{YYYYMM}.xlsx
    elif agency_id == "rdb_kinchu":
        base = f"{MOD_RDB_BASE}/rdb/kinchu/contract/information/files"
        # 年度は4月〜翌3月の12ヶ月
        for month in range(4, 13):
            urls.append({
                "url": f"{base}/construction_competitive_{year4}{month:02d}.xlsx",
                "contract_type": "工事",
                "dept": "",
                "source_type": "excel",
            })
        for month in range(1, 4):
            urls.append({
                "url": f"{base}/construction_competitive_{year4+1}{month:02d}.xlsx",
                "contract_type": "工事",
                "dept": "",
                "source_type": "excel",
            })

    # ── 中国四国防衛局 ──
    # 「契約に係る情報の公表について」月次PDF
    # URL: /rdb/chushi/contract/result/pdf/keiyaku-{type}{CYYMM}.pdf
    # type: kk=工事競争, kz=工事随意, bk=物品役務競争, bz=物品役務随意
    # CYYMM: 2桁カレンダー年 + 2桁月
    elif agency_id == "rdb_chushi":
        base = f"{MOD_RDB_BASE}/rdb/chushi/contract/result/pdf"
        types = [
            ("kk", "工事",    "一般競争入札"),
            ("kz", "工事",    "随意契約"),
            ("bk", "物品役務", "一般競争入札"),
            ("bz", "物品役務", "随意契約"),
        ]
        cyy_start = str(year4)[2:]   # "24" for FY2024
        cyy_next  = str(year4 + 1)[2:]  # "25"
        for m in range(4, 13):
            for t, ctype, bid in types:
                urls.append({
                    "url": f"{base}/keiyaku-{t}{cyy_start}{m:02d}.pdf",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "pdf",
                })
        for m in range(1, 4):
            for t, ctype, bid in types:
                urls.append({
                    "url": f"{base}/keiyaku-{t}{cyy_next}{m:02d}.pdf",
                    "contract_type": ctype, "bid_method": bid,
                    "dept": "", "source_type": "pdf",
                })

    # ── 沖縄防衛局 ──
    # contract/information/pdf/{FY_START_YEAR}/{cat}/{cat}{calendar_month}.pdf
    # ※ フォルダはFY開始年 (例: FY2024 → pdf/2024/)
    # ※ ファイル番号はカレンダー月 (1=1月〜12=12月)
    # ※ 1〜3月(翌年1〜3月)もFYフォルダに格納。pdf/{year4+1}/は次年度分
    elif agency_id == "rdb_okinawa":
        base = f"{MOD_RDB_BASE}/rdb/okinawa/contract/information/pdf"
        cats = [("1kk", "工事"), ("2zk", "工事（随意）"), ("3kb", "業務・物品"), ("4zb", "業務・物品（随意）")]
        # 全12ヶ月をFYフォルダ内に格納（calendar month 1-12 すべて pdf/{year4}/）
        for m in range(1, 13):
            for cat, ctype in cats:
                urls.append({
                    "url": f"{base}/{year4}/{cat}/{cat}{m}.pdf",
                    "contract_type": ctype, "dept": "", "source_type": "pdf",
                })

    else:
        # URLルール未定義の局 → genericにフォールバック（空リストを返す）
        pass

    return urls


class RdbParser(BaseParser):
    """地方防衛局専用パーサー。"""

    def __init__(self, agency: Dict):
        super().__init__(
            agency["id"], agency["name"], agency["category"]
        )
        self.collector = HtmlCollector(use_cache=True)
        self.generic = GenericParser(
            agency["id"], agency["name"], agency["category"]
        )
        self.excel = ExcelParser(
            agency["id"], agency["name"], agency["category"]
        )
        self.pdf_parser = PdfTableParser(
            agency["id"], agency["name"], agency["category"]
        )

    def collect_year(self, fiscal_year: int) -> List[Dict]:
        url_defs = _rdb_urls(self.agency_id, fiscal_year)

        if not url_defs:
            # URLルール未定義の局 → genericにフォールバック
            from config.agencies import KNOWN_AGENCIES
            top = next(
                (a["top_url"] for a in KNOWN_AGENCIES if a["id"] == self.agency_id),
                None,
            )
            if top:
                return self.generic.collect_year(top, fiscal_year)
            return []

        records = []
        for ud in url_defs:
            if ud.get("source_type") == "excel":
                recs = self.excel.parse_excel_url(
                    ud["url"], fiscal_year, ud.get("contract_type", "")
                )
                for r in recs:
                    if ud.get("bid_method") and not r.get("bid_method"):
                        r["bid_method"] = ud["bid_method"]
            elif ud.get("source_type") == "pdf":
                recs = self.pdf_parser._parse_procurement_pdf(
                    ud["url"], fiscal_year,
                    default_bid_method=ud.get("bid_method", ""),
                )
                for r in recs:
                    if ud.get("contract_type"):
                        r["contract_type"] = ud["contract_type"]
                    if ud.get("bid_method") and not r.get("bid_method"):
                        r["bid_method"] = ud["bid_method"]
            elif ud.get("source_type") == "pdf_index":
                # 九州防衛局: インデックスページからPDFリンクを収集
                recs = self._collect_pdf_index(
                    ud["url"], fiscal_year, ud.get("fy_reiwa", ""),
                )
            else:
                recs = self._parse_url(
                    ud["url"], fiscal_year,
                    ud.get("contract_type", ""),
                    ud.get("dept", ""),
                )
            records.extend(recs)

        return records

    def _parse_url(self, url: str, fiscal_year: int,
                   contract_type: str, dept: str) -> List[Dict]:
        soup = self.collector.get_soup(url)
        if soup is None:
            logger.warning(f"取得失敗: {url}")
            return []

        records = []

        # 九州：月別H2見出し + 複数テーブルの構造に対応
        if self.agency_id == "rdb_kyushu":
            records = self._parse_kyushu(soup, url, fiscal_year, contract_type)
        elif self.agency_id == "rdb_hokkaido":
            records = self._parse_hokkaido(soup, url, fiscal_year)
        else:
            records = self._parse_generic_tables(
                soup, url, fiscal_year, contract_type, dept
            )

        logger.info(f"  {self.agency_name} {fiscal_year}年度: {len(records)}件 ({url})")
        return records

    def _parse_kyushu(self, soup: BeautifulSoup, url: str,
                       fiscal_year: int, contract_type: str) -> List[Dict]:
        """九州防衛局：月別H2見出し + テーブル構造。"""
        records = []
        current_month = None

        for tag in soup.find_all(["h2", "h3", "table"]):
            if tag.name in ["h2", "h3"]:
                text = tag.get_text(strip=True)
                # '8月公表（7月契約）分' などから月を抽出
                m = re.search(r"(\d+)月", text)
                if m:
                    current_month = int(m.group(1))

            elif tag.name == "table":
                rows = []
                for tr in tag.find_all("tr"):
                    cells = [td.get_text(separator=" ", strip=True)
                             for td in tr.find_all(["td", "th"])]
                    if cells:
                        rows.append(cells)

                if len(rows) < 2:
                    continue

                col_map = _detect_col_map(rows[0])
                if "vendor_name" not in col_map:
                    continue

                recs = self.parse_table_rows(
                    rows[1:], col_map, fiscal_year, url, contract_type
                )
                for r in recs:
                    r["contract_month"] = current_month
                records.extend(recs)

        return records

    def _parse_hokkaido(self, soup: BeautifulSoup, url: str,
                         fiscal_year: int) -> List[Dict]:
        """北海道防衛局：工事テーブル + 業務テーブルが同一ページ。"""
        records = []
        tables = soup.find_all("table")

        for i, table in enumerate(tables):
            rows = []
            for tr in table.find_all("tr"):
                cells = [td.get_text(separator=" ", strip=True)
                         for td in tr.find_all(["td", "th"])]
                if cells:
                    rows.append(cells)

            if len(rows) < 2:
                continue

            col_map = _detect_col_map(rows[0])
            if "vendor_name" not in col_map:
                continue

            # テーブル見出しから工事/業務を判定
            contract_type = "工事" if i == 0 else "業務"
            # テーブルの直前の見出しタグで確認
            prev = table.find_previous(["h2", "h3", "h4", "caption"])
            if prev:
                t = prev.get_text(strip=True)
                if "業務" in t:
                    contract_type = "業務"
                elif "工事" in t:
                    contract_type = "工事"

            recs = self.parse_table_rows(
                rows[1:], col_map, fiscal_year, url, contract_type
            )
            records.extend(recs)

        return records

    def _collect_pdf_index(self, index_url: str, fiscal_year: int,
                            fy_reiwa: str) -> List[Dict]:
        """
        九州防衛局「契約情報の公表」インデックスページからPDFリンクを収集。
        PDFファイル名が {fy_reiwa}{MM}... で始まるもののみ対象。
        熊本防衛支局 (k{rr}...) も同時収集。
        """
        soup = self.collector.get_soup(index_url)
        if soup is None:
            logger.warning(f"インデックス取得失敗: {index_url}")
            return []

        from urllib.parse import urljoin
        records = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.lower().endswith(".pdf"):
                continue
            fname = href.split("/")[-1]
            # 九州本局: "{rr}{MM}..." または "k{rr}{MM}..." (熊本支局)
            is_honkyoku = fname.startswith(fy_reiwa)
            is_kumamoto = fname.startswith("k" + fy_reiwa)
            if not (is_honkyoku or is_kumamoto):
                continue

            pdf_url = urljoin(index_url, href)
            dept = "熊本防衛支局" if is_kumamoto else ""

            # ファイル名からcontract_type/bid_methodを推定
            f = fname.lower()
            if "kouji" in f or "kozi" in f:
                ctype = "工事"
            elif "buppin" in f or "bupin" in f:
                ctype = "物品役務"
            else:
                ctype = ""

            if "nyuusatsu" in f or "nyusatsu" in f:
                bid = "一般競争入札"
            elif "zuikei" in f or "zikei" in f:
                bid = "随意契約"
            else:
                bid = ""

            recs = self.pdf_parser._parse_procurement_pdf(
                pdf_url, fiscal_year, default_bid_method=bid,
            )
            for r in recs:
                if ctype:
                    r["contract_type"] = ctype
                if dept:
                    r["dept"] = dept
            records.extend(recs)

        logger.info(f"  {self.agency_name} {fiscal_year}年度 (pdf_index): {len(records)}件")
        return records

    def _parse_generic_tables(self, soup: BeautifulSoup, url: str,
                               fiscal_year: int, contract_type: str,
                               dept: str) -> List[Dict]:
        """汎用テーブル解析（東北・南関東・北関東等）。
        ヘッダー行を最大10行目まで自動検索。"""
        records = []
        for table in soup.find_all("table"):
            rows = []
            for tr in table.find_all("tr"):
                cells = [td.get_text(separator=" ", strip=True)
                         for td in tr.find_all(["td", "th"])]
                if cells:
                    rows.append(cells)

            if len(rows) < 2:
                continue

            # ヘッダー行を自動検索（最大10行）
            header_idx = -1
            col_map = {}
            for i in range(min(10, len(rows))):
                cm = _detect_col_map(rows[i])
                if "vendor_name" in cm:
                    header_idx = i
                    col_map = cm
                    break

            if header_idx < 0:
                continue

            recs = self.parse_table_rows(
                rows[header_idx + 1:], col_map,
                fiscal_year, url, contract_type, dept
            )
            records.extend(recs)

        return records
