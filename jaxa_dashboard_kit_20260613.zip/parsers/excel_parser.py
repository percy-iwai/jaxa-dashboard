"""
Excelファイル形式の調達データパーサー。
近畿中部防衛局・防衛装備庁ATLA（中央調達）の月次xlsxに対応。

列構造（自動検出）:
  近畿中部: ヘッダー行2、データ行4〜
    0: 公共工事の名称  2: 契約締結日  3: 相手方  5: 入札方式  7: 契約金額
  ATLA:    ヘッダー行1、データ行3〜
    0: 物品役務等の名称  4: 契約締結日  5: 相手方  8: 契約金額  10: 入札方式
"""
import io
import re
from datetime import datetime, date
from typing import List, Dict, Optional

import pandas as pd
from loguru import logger

from collectors.base_collector import BaseCollector
from parsers.base_parser import BaseParser


# Excel列ヘッダーキーワード → DBカラム名
EXCEL_HEADER_KEYWORDS = [
    ("名称",              "contract_name"),   # 工事/業務/物品の名称
    ("件名",              "contract_name"),
    ("相手方の商号",       "vendor_name"),     # 契約の相手方の商号又は名称
    ("相手方の名称",       "vendor_name"),
    ("締結した日",         "contract_date"),   # 契約を締結した日
    ("締結日",            "contract_date"),
    ("法人番号",           "corporate_number"),
    ("予定価格",           "estimated_price"),
    ("契約金額",           "contract_amount"),
    ("落札率",            "award_rate"),
    ("入札・指名",         "bid_method"),      # 一般競争入札・指名競争入札の別
    ("入札方式",           "bid_method"),
    ("の別",              "bid_method"),       # 「...の別（総合評価...）」
    ("数量",              "quantity"),
    ("単位",              "unit_measure"),
    ("根拠条文",           "zuii_reason"),     # 随意契約の根拠条文及び理由
    ("随意契約の根拠",     "zuii_reason"),
    ("担当官",            "contract_officer"), # 契約担当官等の氏名並びにその所属
]


def _find_header_row(df: pd.DataFrame) -> int:
    """ヘッダー行インデックスを自動検出（最初の10行を走査）。"""
    for i in range(min(10, len(df))):
        row_text = " ".join(str(v) for v in df.iloc[i] if str(v) != "nan")
        if "契約金額" in row_text and ("名称" in row_text or "件名" in row_text):
            return i
    return 1  # フォールバック


def _map_excel_columns(header_series: pd.Series) -> Dict[str, int]:
    """ヘッダー行から {DBカラム名: 列インデックス} マッピングを生成。"""
    col_map: Dict[str, int] = {}
    for idx, val in enumerate(header_series):
        cell = str(val).replace("\n", "")
        for keyword, field in EXCEL_HEADER_KEYWORDS:
            if keyword in cell and field not in col_map:
                col_map[field] = idx
                break
    return col_map


def _to_date_str(val) -> Optional[str]:
    """各種日付値を YYYYMMDD 文字列に変換。"""
    if val is None:
        return None
    if isinstance(val, float) and pd.isna(val):
        return None
    # pandas Timestamp / datetime / date
    if isinstance(val, (pd.Timestamp, datetime, date)):
        return pd.Timestamp(val).strftime("%Y%m%d")
    # Excelシリアル値（整数）: 44676 → 2022-04-04
    if isinstance(val, (int, float)):
        try:
            ts = pd.Timestamp("1899-12-30") + pd.Timedelta(days=int(val))
            return ts.strftime("%Y%m%d")
        except Exception:
            return None
    # 文字列 YYYY-MM-DD / YYYY/MM/DD / YYYY年MM月DD日
    s = str(val).strip()
    m = re.match(r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})", s)
    if m:
        return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"
    # 和暦（令和）: "6.4.1" / "R6.4.1" → 令和6年4月1日 = 2024-04-01
    # 令和N年 = 2018+N年（令和1=2019）
    m_reiwa = re.match(r"^[Rr]?(\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m_reiwa:
        ry, mo, dd = int(m_reiwa.group(1)), int(m_reiwa.group(2)), int(m_reiwa.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            greg_year = 2018 + ry
            return f"{greg_year}{mo:02d}{dd:02d}"
    return None


class ExcelParser(BaseParser):
    """Excelファイル形式の調達情報パーサー（近畿中部・ATLA共通）。"""

    def __init__(self, agency_id: str, agency_name: str, agency_category: str):
        super().__init__(agency_id, agency_name, agency_category)
        self.collector = BaseCollector(use_cache=True)

    def parse_excel_url(
        self,
        url: str,
        fiscal_year: int,
        contract_type: str = "",
    ) -> List[Dict]:
        """1つのExcel URLを解析して契約レコードリストを返す。"""
        is_xls = url.lower().endswith(".xls")
        ext = ".xls" if is_xls else ".xlsx"
        data = self.collector.get_file_bytes(url, ext=ext)
        if data is None:
            return []

        try:
            if is_xls:
                df = pd.read_excel(io.BytesIO(data), header=None, engine="xlrd")
            else:
                df = pd.read_excel(io.BytesIO(data), header=None, engine="openpyxl")
        except Exception as e:
            logger.warning(f"Excel読み込みエラー: {url} - {e}")
            return []

        if df.empty or len(df) == 0:
            logger.debug(f"空のExcel（スキップ）: {url}")
            return []

        header_idx = _find_header_row(df)
        if header_idx >= len(df):
            logger.debug(f"ヘッダー行なし（スキップ）: {url}")
            return []
        col_map = _map_excel_columns(df.iloc[header_idx])

        if "contract_amount" not in col_map or "vendor_name" not in col_map:
            logger.debug(f"列マッピング不足（スキップ）: {url} → {col_map}")
            return []

        # ヘッダー行の直後の補助ヘッダー行（"応札者数"等）をスキップするため+2
        data_start = header_idx + 2

        records = []
        for i in range(data_start, len(df)):
            row = df.iloc[i]

            # 完全空行スキップ
            if all(pd.isna(v) or str(v).strip() in ("", "nan") for v in row):
                continue

            vendor_raw = row.iloc[col_map["vendor_name"]] if col_map.get("vendor_name") is not None else None
            amount_raw = row.iloc[col_map["contract_amount"]] if col_map.get("contract_amount") is not None else None
            name_raw = row.iloc[col_map["contract_name"]] if col_map.get("contract_name") is not None else None

            # 業者名も金額もない行はスキップ
            if (vendor_raw is None or pd.isna(vendor_raw)) and (amount_raw is None or pd.isna(amount_raw)):
                continue
            # 件名も金額もない行はスキップ（大臣官房系の住所続き行対策）
            if (name_raw is None or pd.isna(name_raw) or str(name_raw).strip() in ("", "nan")) and \
               (amount_raw is None or pd.isna(amount_raw)):
                continue

            rec = self._make_record_base(fiscal_year, url, "excel", "", contract_type)

            for field, idx in col_map.items():
                if idx >= len(row):
                    continue
                val = row.iloc[idx]
                if val is None or (isinstance(val, float) and pd.isna(val)):
                    continue

                if field == "contract_name":
                    rec["contract_name"] = str(val).split("\n")[0].strip()[:500] or None

                elif field == "vendor_name":
                    # "名前\n住所\n法人番号" の形式 → 1行目を名前、2行目以降を住所
                    lines = [l.strip() for l in str(val).split("\n") if l.strip()]
                    rec["vendor_name"] = lines[0] if lines else None
                    if len(lines) > 1:
                        rec["vendor_address"] = "\n".join(lines[1:])

                elif field == "corporate_number":
                    s = str(val).strip()
                    rec["corporate_number"] = s if s not in ("nan", "") else None

                elif field == "contract_date":
                    rec["contract_date"] = _to_date_str(val)

                elif field == "contract_amount":
                    try:
                        rec["contract_amount"] = int(float(str(val).replace(",", "")))
                    except (ValueError, TypeError):
                        pass

                elif field == "estimated_price":
                    try:
                        rec["estimated_price"] = int(float(str(val).replace(",", "")))
                    except (ValueError, TypeError):
                        pass

                elif field == "award_rate":
                    try:
                        rate = float(str(val))
                        # 0〜1 の小数表記なら100倍してパーセントに
                        rec["award_rate"] = round(rate * 100, 2) if rate <= 1.0 else rate
                    except (ValueError, TypeError):
                        pass

                elif field == "bid_method":
                    rec["bid_method"] = self._normalize_bid_method(str(val))

                elif field == "quantity":
                    s = str(val).strip()
                    if s and s not in ("nan", "None"):
                        rec["quantity"] = s[:100]

                elif field == "unit_measure":
                    s = str(val).strip()
                    if s and s not in ("nan", "None"):
                        rec["unit_measure"] = s[:50]

                elif field == "zuii_reason":
                    s = str(val).strip()
                    if s and s not in ("nan", "None"):
                        rec["zuii_reason"] = s[:500]

                elif field == "contract_officer":
                    s = str(val).strip()
                    if s and s not in ("nan", "None"):
                        rec["contract_officer"] = s[:300]

            # 単価契約対応: 契約金額が取れない場合、全セルから「予定調達総額X円」を抽出
            ca = rec.get("contract_amount")
            if ca is None or ca > 1_000_000_000_000:
                for v in row:
                    if v is None or (isinstance(v, float) and pd.isna(v)):
                        continue
                    m_total = re.search(r'予定調達総額[^\d]*([\d,]+)円', str(v))
                    if m_total:
                        try:
                            rec["contract_amount"] = int(m_total.group(1).replace(",", ""))
                            logger.debug(
                                f"単価契約: 予定調達総額 {rec['contract_amount']:,}円 を採用"
                                f" ({rec.get('contract_name', '')})"
                            )
                        except ValueError:
                            pass
                        break

            if rec.get("vendor_name"):
                rec["is_jv"] = int(self._is_jv(
                    rec["vendor_name"], rec.get("corporate_number", "") or ""
                ))
                records.append(rec)

        logger.info(f"  {self.agency_name}: {len(records)}件 ({url})")
        return records
